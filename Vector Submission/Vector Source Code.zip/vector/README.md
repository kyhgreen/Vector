# Vector

Learn money skills in bite-sized, game-like lessons. Built for the Congressional App Challenge.

Vector is an installable web app (PWA). It runs on iPhone, Android, and Windows, works offline,
and saves all progress on the device. There are no accounts and no server.

## Run it on your computer

You need [Node.js](https://nodejs.org) (LTS) to build or edit the app. People who just use the app don't.

```bash
npm install
npm run dev
```

Open the link it prints. To try it on your phone, connect the phone to the same Wi-Fi and open the
"Network" link it shows.

## Other commands

| Command | What it does |
| --- | --- |
| `npm test` | Runs the game-logic, finance-math, and lesson-content checks |
| `npm run build` | Builds the installable web app into `dist/` (for hosting online) |
| `npm run build:file` | Builds the whole app as ONE file, `submission/Vector.html` |
| `npm run preview` | Serves the built app locally |

## The Windows desktop app

`npm run build:desktop` builds Vector as a real Windows program (Electron) into `release/`:

- `Vector.exe`: one file. Double-click it and Vector opens in its own window. Nothing to install.
- `Vector-Setup.exe`: an installer that adds a Vector icon to the desktop and Start menu.

Progress is saved on that computer (in `%APPDATA%\Vector`). The app isn't code-signed, so the first time
Windows may say "Windows protected your PC": click **More info**, then **Run anyway**.
`npm run desktop` opens the desktop app without packaging it, for quick testing.

## The single-file version (for Canvas or email)

`submission/Vector.html` is the entire app in one file: lessons, tools, font, everything. Download it and
double-click it to open it in any browser. It needs no internet, no server, and no install. Progress is saved
in that browser on that computer. After changing any code, run `npm run build:file` again to refresh it.

## Put it online (so phones can install it)

Push this folder to a GitHub repo, then go to **Settings > Pages** and set **Source** to **GitHub Actions**.
The included workflow (`.github/workflows/deploy.yml`) tests, builds, and publishes the app every time you
push to `main`. Any static host works too (Netlify, Vercel, etc.); upload the `dist/` folder.

## Install it

- **iPhone (Safari):** Share button, then **Add to Home Screen**.
- **Android (Chrome):** menu, then **Install app**.
- **Windows (Edge or Chrome):** the install icon in the address bar.

## Where things live

- `src/content/units/`: the lessons (one file per unit)
- `src/screens/`: the app's screens
- `src/tools/`: the money tools (one folder each)
- `src/state/`: XP, streaks, hearts, coins, leagues, and badges
- `src/components/`: shared buttons, cards, charts, and pop-ups
