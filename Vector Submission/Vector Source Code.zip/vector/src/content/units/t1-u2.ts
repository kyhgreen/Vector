import type { Unit } from '../types'

const unit: Unit = {
  id: 't1-u2',
  tier: 1,
  order: 2,
  title: 'Budgeting Basics',
  tagline: 'Give every dollar a job before it wanders off.',
  color: 'blue',
  emoji: '📊',

  guidebook: {
    intro:
      'A budget is a plan for your money before it vanishes into snacks. No spreadsheets required.',
    keyIdeas: [
      {
        title: 'A budget is a plan',
        body: "Decide where your money goes before you spend it. The plan can't add up to more than you have, no matter how hard you squint.",
      },
      {
        title: '50/30/20 is a handy start',
        body: "Needs 50%, wants 30%, savings 20%. It's a guideline, so bend it if your family covers most of your needs.",
      },
      {
        title: 'Track every dollar',
        body: "Write down what you spend, even the $2 stuff. Small repeat buys (money leaks) add up faster than you'd think.",
      },
      {
        title: 'Compare plan vs. real life',
        body: 'Each week, compare your plan to what you actually spent. If one category is hogging the cash, adjust.',
      },
      {
        title: 'Big plans get their own budget',
        body: 'List the costs, including sneaky ones like tax and shipping, plus a small cushion. Over budget? Cut something, go cheaper, or save longer.',
      },
    ],
    funFacts: [
      'The word "budget" comes from the old French bougette, a little pouch, so a budget is technically a purse.',
      'The 50/30/20 rule got famous from a 2005 money book by a mom and her daughter (some families do puzzles, this one did percents).',
      'Before apps, lots of people budgeted with labeled cash envelopes, and an empty envelope meant no more spending there.',
      '$3 a day adds up to $1,095 a year, which is a lot of nothing.',
      'Alaska, Delaware, Montana, New Hampshire, and Oregon have no statewide sales tax, though some towns there (especially in Alaska) add their own.',
      "The U.S. government's budget year starts October 1, so its money New Year comes with pumpkin spice.",
    ],
    words: [
      { term: 'Budget', meaning: 'A money plan made before you spend' },
      { term: 'Income', meaning: 'Money coming in' },
      { term: 'Expense', meaning: 'Money going out' },
      { term: 'Needs', meaning: 'Must-haves, like lunch' },
      { term: 'Wants', meaning: 'Fun extras you could skip' },
      { term: 'Savings', meaning: 'Money you keep for later' },
      { term: 'Tracking', meaning: 'Writing down what you spend' },
      { term: 'Money leak', meaning: 'A small repeat buy you stop noticing' },
      { term: 'Sneaky cost', meaning: 'An extra cost not on the price tag, like tax' },
      { term: 'Cushion', meaning: 'A few extra dollars for surprises' },
    ],
  },

  lessons: [
    /* ---------- Lesson 1: What is a budget? ---------- */
    {
      id: 't1-u2-l1',
      title: 'What is a budget?',
      description: 'Meet the money plan that keeps cash from vanishing.',
      exercises: [
        {
          type: 'teach',
          id: 't1-u2-l1-e1',
          emoji: '📝',
          title: 'A budget is a plan',
          body: "A **budget** is a plan for your money, made **before** you spend it.\n\nWithout one, cash tends to wander off. You open your wallet on Friday and go, 'Wait, where did my $15 go?' A budget answers that question before it happens.",
          example: "You get $20 from Grandma. Your plan: $10 into savings, $6 for a movie, $4 for popcorn. That's a budget!",
        },
        {
          type: 'mc',
          id: 't1-u2-l1-e2',
          prompt: "What's a budget, really?",
          choices: [
            { text: 'A plan for your money before you spend it', correct: true },
            {
              text: "A rule that says you can't buy anything fun",
              why: "Fun money is totally allowed! A budget just plans for it, so the fun doesn't eat everything else.",
            },
            {
              text: 'A special bank account for grown-ups',
              why: "A budget isn't an account at all. It's a plan, and anyone can make one, at any age.",
            },
            {
              text: 'A list of everything you already bought',
              why: "Close, but that's more like tracking. A budget plans ahead, before the money's gone.",
            },
          ],
          explain: "A budget hands every dollar a job before the spending chaos starts. You're the manager now. Congrats on the promotion.",
        },
        {
          type: 'tf',
          id: 't1-u2-l1-e3',
          statement: 'Budgets are only for grown-ups with jobs and bills.',
          answer: false,
          explain: "False! Budgets don't check your ID. Even $5 of birthday cash deserves a job.",
        },
        {
          type: 'teach',
          id: 't1-u2-l1-e4',
          emoji: '🔄',
          title: 'Money in, money out',
          body: "Every budget has two sides:\n- **Income** is money coming in, like allowance, birthday cash, or pay from a small gig\n- **Expenses** are money going out, anything you spend on\n\nA good budget keeps your expenses from outrunning your income. (Expenses run fast. Track-team fast.)",
        },
        {
          type: 'sort',
          id: 't1-u2-l1-e5',
          prompt: 'Money in or money out? Sort it!',
          buckets: ['Income', 'Expenses'],
          items: [
            { text: 'Weekly allowance', bucket: 0 },
            { text: 'Birthday cash from Grandma', bucket: 0 },
            { text: 'Pay for walking a dog', bucket: 0 },
            { text: 'Buying a movie ticket', bucket: 1 },
            { text: 'Buying bubble tea', bucket: 1 },
            { text: 'Buying a phone case', bucket: 1 },
          ],
          explain: 'Income is money coming to you. Expenses are money leaving you. Easy way to remember: income comes IN.',
        },
        {
          type: 'fill',
          id: 't1-u2-l1-e6',
          sentence: 'Money that comes in is called ___, and money that goes out is called ___.',
          answers: ['income', 'expenses'],
          bank: ['income', 'expenses', 'pocket lint', 'homework'],
          explain: 'Income comes in, expenses go out. Pocket lint just sits there, being pocket lint.',
        },
        {
          type: 'number',
          id: 't1-u2-l1-e7',
          prompt: 'You get $20 of allowance and earn $15 pet sitting. Then you spend $12 on snacks. How much is left?',
          answer: 23,
          prefix: '$',
          explain: '$20 + $15 = $35 coming in. Take away the $12 going out and you have $23 left. Income minus expenses. You just did budget math.',
        },
        {
          type: 'teach',
          id: 't1-u2-l1-e8',
          emoji: '🧩',
          title: 'Your plan has to fit',
          body: "Rule number one: your plan can't add up to more money than you have.\n\nIf you have $25, you can't plan $30 of stuff. Something won't happen, and it's usually the thing you wanted most.",
          example: '$25 in: $10 to savings + $10 trampoline park + $5 snacks = $25. Snug as a sock.',
        },
        {
          type: 'mc',
          id: 't1-u2-l1-e9',
          prompt: 'You have $30. Which plan fits your money?',
          choices: [
            { text: 'Save $10, game $15, snacks $5', correct: true },
            {
              text: 'Save $10, game $20, snacks $5',
              why: "So close! That adds up to $35. You'd be $5 short, and the snack stand doesn't take IOUs.",
            },
            {
              text: 'Game $30, snacks $10',
              why: "That's $40 of plans for $30 of money. The math just doesn't add up.",
            },
          ],
          explain: "$10 + $15 + $5 = $30 on the dot. Nothing missing, nothing left wandering around. That's a plan that can actually happen.",
        },
        {
          type: 'teach',
          id: 't1-u2-l1-e10',
          emoji: '👜',
          funFact: true,
          title: 'A budget is a little bag',
          body: "The word **budget** comes from an old French word, bougette, which means a little bag or pouch.\n\nSo every time you make a budget, you're basically packing a tiny purse for your cash. Very fancy.",
        },
        {
          type: 'tf',
          id: 't1-u2-l1-e11',
          statement: 'A budget can include money for fun stuff, like movies or games.',
          answer: true,
          explain: "True! Fun gets its own line in the plan. It just doesn't get to eat everyone else's lunch money too.",
        },
        {
          type: 'scenario',
          id: 't1-u2-l1-e12',
          emoji: '🕹️',
          setup: "You just got $25 for your birthday. Your friends are hitting the arcade on Saturday (about $10), and you're also saving up for new headphones.",
          question: 'What do you do with the $25?',
          choices: [
            {
              text: 'Plan it: $10 for the arcade, $15 for headphones',
              best: true,
              outcome: 'You crush everyone at air hockey AND your headphone fund grows by $15. Big day.',
            },
            {
              text: 'Spend all $25 at the arcade',
              outcome: 'You win 400 tickets and trade them for a rubber bracelet. The headphones stay a dream.',
            },
            {
              text: 'Keep it in your pocket and decide later',
              outcome: 'By Sunday you have $4, a slushie receipt, and zero memory of where the rest went.',
            },
          ],
        },
      ],
    },

    /* ---------- Lesson 2: The 50/30/20 rule ---------- */
    {
      id: 't1-u2-l2',
      title: 'The 50/30/20 rule',
      description: 'Three numbers, one easy plan for every dollar.',
      exercises: [
        {
          type: 'teach',
          id: 't1-u2-l2-e1',
          emoji: '🥧',
          title: 'Meet 50/30/20',
          body: 'The **50/30/20 rule** is an easy way to split your money:\n- 50% for **needs** (must-haves, like lunch or bus fare)\n- 30% for wants (fun stuff, like games or concert tickets)\n- 20% for savings (money you keep for later)\n\nPicture your money as a pie with three slices. No, your little brother does not get a fourth.',
        },
        {
          type: 'match',
          id: 't1-u2-l2-e2',
          prompt: 'Match each slice to where the money goes.',
          pairs: [
            { left: '50%', right: 'Needs, the must-haves' },
            { left: '30%', right: 'Wants, the fun stuff' },
            { left: '20%', right: 'Savings, money for later' },
          ],
          explain: 'Biggest slice for needs, middle slice for wants, and 20% tucked away for later. Pie: served.',
        },
        {
          type: 'mc',
          id: 't1-u2-l2-e3',
          prompt: 'In the 50/30/20 rule, where does the 20% go?',
          choices: [
            { text: 'Savings', correct: true },
            { text: 'Wants', why: 'Close! Wants get 30%, the middle slice.' },
            { text: 'Needs', why: 'Needs get the biggest slice: 50%, which is half.' },
            {
              text: 'Exactly 20 gummy bears',
              why: 'Delicious guess! But the 20 is a percent of your money, not a snack count.',
            },
          ],
          explain: "Savings gets 20%. Smallest slice, but it stacks up quietly until one day it's a bike.",
        },
        {
          type: 'teach',
          id: 't1-u2-l2-e4',
          emoji: '🧮',
          title: 'Percent math, the easy way',
          body: '50% is just **half**.\n\nFor 10%, slide the decimal point one spot to the left: 10% of $60 is $6. Then 30% is three of those, and 20% is two of those.\n\nNo calculator needed. Your brain is the calculator, and it was free.',
          example: '$60 from chores: needs $30, wants $18, savings $12. Check: 30 + 18 + 12 = 60. Nailed it.',
        },
        {
          type: 'number',
          id: 't1-u2-l2-e5',
          prompt: 'You get $100 for your birthday and use the 50/30/20 rule. How many dollars go to wants?',
          answer: 30,
          prefix: '$',
          explain: '30% of $100 is $30. With $100, the percents turn straight into dollars. Easy mode!',
        },
        {
          type: 'number',
          id: 't1-u2-l2-e6',
          prompt: 'You earn $40 mowing lawns. Using 50/30/20, how many dollars go to savings?',
          answer: 8,
          prefix: '$',
          explain: '10% of $40 is $4, so 20% is two of those: $8. Mowing money, officially saved.',
        },
        {
          type: 'sort',
          id: 't1-u2-l2-e7',
          prompt: 'Which slice does each one go in?',
          buckets: ['Needs', 'Wants', 'Savings'],
          items: [
            { text: 'Bus fare to school', bucket: 0 },
            { text: 'School lunch', bucket: 0 },
            { text: 'Concert tickets', bucket: 1 },
            { text: 'Neon slime kit', bucket: 1 },
            { text: 'Piggy bank deposit', bucket: 2 },
            { text: 'Money set aside for later', bucket: 2 },
          ],
          explain: "Bus fare and lunch get you through the school day, so they're needs. Slime and concerts are pure fun. Savings is any money wearing a 'later' sticker.",
        },
        {
          type: 'teach',
          id: 't1-u2-l2-e8',
          emoji: '🤸',
          title: 'Bend it to fit you',
          body: "The 50/30/20 rule was built for grown-ups paying for rent and groceries. If your family covers the big needs, your needs slice might be tiny.\n\nThat's okay! It's a **guideline**, not a law. You might slide some of that slice over to savings. Having a plan matters way more than nailing the exact numbers.",
        },
        {
          type: 'tf',
          id: 't1-u2-l2-e9',
          statement: 'The 50/30/20 rule is a guideline, so you can tweak it to fit your life.',
          answer: true,
          explain: "True! Nobody hands out tickets for a 40/30/30 split. There are no 50/30/20 police. We checked.",
        },
        {
          type: 'teach',
          id: 't1-u2-l2-e10',
          emoji: '📚',
          funFact: true,
          title: 'Famous thanks to a book',
          body: "The 50/30/20 rule got famous from a 2005 money book written by a mom and her daughter.\n\nIt caught on because it's just three numbers. You could probably say them in your sleep by now.",
        },
        {
          type: 'fill',
          id: 't1-u2-l2-e11',
          sentence: 'Half your money goes to ___, and the smallest slice goes to ___.',
          answers: ['needs', 'savings'],
          bank: ['needs', 'savings', 'wants', 'candy', 'a llama'],
          explain: 'Needs get the biggest slice (50%) and savings gets the smallest (20%). Wants sit in the middle at 30%. Llamas are not part of the rule.',
        },
        {
          type: 'scenario',
          id: 't1-u2-l2-e12',
          emoji: '🎮',
          setup: "You split this month's $60 of chore money using 50/30/20. It's only the 15th, and your $18 of wants money is already gone. Then a shiny new game skin drops for $10.",
          question: "What's the best move?",
          choices: [
            {
              text: "Wait for next month's wants money",
              best: true,
              outcome: 'The skin is still there next month, and so is your savings. Future you is very smug about it.',
            },
            {
              text: 'Grab $10 from your savings slice',
              outcome: "You get the skin, but your savings takes a hit. Do that every month and 'later' never shows up.",
            },
            {
              text: 'Use your bus fare money',
              outcome: 'Cool skin. Long walk to school. Your sneakers are not thrilled about it.',
            },
          ],
        },
      ],
    },

    /* ---------- Lesson 3: Tracking your spending ---------- */
    {
      id: 't1-u2-l3',
      title: 'Tracking your spending',
      description: 'Play money detective and catch the sneaky leaks.',
      exercises: [
        {
          type: 'teach',
          id: 't1-u2-l3-e1',
          emoji: '🕵️',
          title: 'Where did my money go?!',
          body: "**Tracking** means writing down every time you spend money: what you bought and how much. That list is your **spending log**.\n\nA notebook works. So does a notes app. **Receipts** (the little paper slips you get when you pay) help you remember, too.",
          example: 'Mon: $3 slushie. Wed: $5 game coins. Fri: $8 pizza and soda. Weekly total: $16.',
        },
        {
          type: 'mc',
          id: 't1-u2-l3-e2',
          prompt: 'Why bother tracking your spending?',
          choices: [
            { text: 'To see where your money really goes', correct: true },
            {
              text: 'To make your wallet feel heavier',
              why: "Tracking doesn't add a single dollar. It just shows you where the dollars went.",
            },
            {
              text: "Because it's required by law",
              why: 'Nobody is checking your snack receipts. Tracking is just for you.',
            },
          ],
          explain: 'Tracking shows you the real story. Once you know where the money actually went, your budget can stop guessing.',
        },
        {
          type: 'tf',
          id: 't1-u2-l3-e3',
          statement: 'A $2 snack is too small to be worth tracking.',
          answer: false,
          explain: "False! A $2 snack every day adds up to about $60 a month. Tiny buys are the easiest ones to forget, which is exactly the problem.",
        },
        {
          type: 'teach',
          id: 't1-u2-l3-e4',
          emoji: '💧',
          title: 'Tiny leaks, big puddles',
          body: "A **money leak** is a small buy you make so often that you stop noticing it. A drink here, a snack there.\n\nOne leak won't sink your ship. But leaks add up fast, and tracking is how you spot them.",
          example: "A $3 smoothie every school day: $3 × 5 = $15 a week. That's about $60 a month, which is basically a brand-new video game.",
        },
        {
          type: 'number',
          id: 't1-u2-l3-e5',
          prompt: 'You buy a $4 iced drink every school day (5 days a week). How much do you spend in one week?',
          answer: 20,
          prefix: '$',
          explain: '$4 × 5 days = $20 a week. One very refreshing leak!',
        },
        {
          type: 'number',
          id: 't1-u2-l3-e6',
          prompt: 'You spend $3 on chips 4 times a week. How much is that in 2 weeks?',
          answer: 24,
          prefix: '$',
          explain: '$3 × 4 = $12 a week, so 2 weeks is $24. Chips: delicious, and also kind of pricey.',
        },
        {
          type: 'teach',
          id: 't1-u2-l3-e7',
          emoji: '⚖️',
          title: 'Plan vs. real life',
          body: 'Tracking really pays off when you **compare** it to your budget. What did you plan to spend? What did you actually spend?\n\nCheck once a week. Sort your spending into **categories** (groups like snacks, games, and hanging out) so you can see which one is quietly eating your cash.',
        },
        {
          type: 'match',
          id: 't1-u2-l3-e8',
          prompt: 'Match each detective tool to what it means.',
          pairs: [
            { left: 'Receipt', right: 'Paper proof of what you bought' },
            { left: 'Spending log', right: 'Your list of every purchase' },
            { left: 'Category', right: 'A group, like snacks or games' },
            { left: 'Money leak', right: 'A small buy that repeats a lot' },
          ],
          explain: 'Receipts are your clues, the log is your case file, and categories show you where the leaks are hiding.',
        },
        {
          type: 'sort',
          id: 't1-u2-l3-e9',
          prompt: 'Tracking win or tracking fail?',
          buckets: ['Smart habit', 'Oops habit'],
          items: [
            { text: 'Write it down right away', bucket: 0 },
            { text: 'Keep your receipts', bucket: 0 },
            { text: 'Check your log weekly', bucket: 0 },
            { text: "Guess at month's end", bucket: 1 },
            { text: 'Skip the small stuff', bucket: 1 },
            { text: 'Track only on birthdays', bucket: 1 },
          ],
          explain: 'Quick notes and saved receipts make you a top-tier money detective. Guessing at the end of the month is how $20 turns into an unsolved mystery.',
        },
        {
          type: 'fill',
          id: 't1-u2-l3-e10',
          sentence: 'Each week, compare what you ___ to spend with what you ___ spent.',
          answers: ['planned', 'actually'],
          bank: ['planned', 'actually', 'forgot', 'never'],
          explain: "Plan vs. real life. If they don't match, now you know exactly where to adjust.",
        },
        {
          type: 'teach',
          id: 't1-u2-l3-e11',
          emoji: '✉️',
          funFact: true,
          title: 'The envelope trick',
          body: 'Before budget apps, lots of people used **envelopes**. Cash for groceries in one, gas in another, fun money in a third.\n\nWhen an envelope was empty, that category was done until next payday. Some people still do it today!',
        },
        {
          type: 'scenario',
          id: 't1-u2-l3-e12',
          emoji: '🍫',
          setup: 'You planned $20 for fun this month. On the 15th you check your spending log: $17 is already gone, mostly on vending machine snacks.',
          question: 'What do you do now?',
          choices: [
            {
              text: 'Slow down and pack snacks from home',
              best: true,
              outcome: 'You make it to the end of the month with $3 to spare. The vending machine misses you, though.',
            },
            {
              text: "Stop tracking so you don't have to see it",
              outcome: "The money is still gone. Now it's just gone in secret.",
            },
            {
              text: 'Decide the log is wrong and keep buying',
              outcome: "The log was right. By the 20th you're at $0, staring at the vending machine like it owes you money.",
            },
          ],
        },
      ],
    },

    /* ---------- Lesson 4: Budgeting for a goal or event ---------- */
    {
      id: 't1-u2-l4',
      title: 'Budgeting for big plans',
      description: 'Plan a party, a trip, or a big goal without the surprise bill.',
      exercises: [
        {
          type: 'teach',
          id: 't1-u2-l4-e1',
          emoji: '🎉',
          title: 'Big plans need a money plan',
          body: 'Got something big coming up? A birthday party, a school trip, a new bike?\n\nMake a mini budget just for it:\n- Write a **cost list** with every expense\n- Add it all up\n- Compare the total to the money you have',
          example: 'Sleepover plan: pizza $20 + snacks $8 + movie rental $5 = $33. You have $40. Party on!',
        },
        {
          type: 'mc',
          id: 't1-u2-l4-e2',
          prompt: "You're planning a bowling party. What's the first step?",
          choices: [
            { text: 'List everything it will cost', correct: true },
            {
              text: 'Book the fanciest lane right away',
              why: 'Fancy lanes before a plan? Bold. You might blow the budget before the first roll.',
            },
            {
              text: 'Wait until party day and wing it',
              why: 'Winging it is how you end up with shoes for 8 people and money for 3.',
            },
            {
              text: 'Buy yourself a trophy first',
              why: "Love the confidence, but trophies aren't step one. The cost list is.",
            },
          ],
          explain: "A cost list comes first. You can't know if you can afford the party until you know what the party costs.",
        },
        {
          type: 'number',
          id: 't1-u2-l4-e3',
          prompt: "Your party cost list: pizza $24, cake $15, decorations $6. What's the total?",
          answer: 45,
          prefix: '$',
          explain: '$24 + $15 + $6 = $45. Now you know the party price tag before you buy a single balloon.',
        },
        {
          type: 'teach',
          id: 't1-u2-l4-e4',
          emoji: '👀',
          title: 'Watch for sneaky costs',
          body: "The price tag isn't always the whole story. Watch for **sneaky costs**:\n- Sales tax (extra money most states add at checkout)\n- Shipping on online orders\n- Rides, ticket fees, and gift wrap\n\nThen add a **cushion**: a few extra dollars in your plan for surprises.",
        },
        {
          type: 'tf',
          id: 't1-u2-l4-e5',
          statement: 'The price on the tag is always exactly what you pay at checkout.',
          answer: false,
          explain: 'False! In most states, sales tax gets added at the register, and online orders can add shipping. Plan a little extra.',
        },
        {
          type: 'mc',
          id: 't1-u2-l4-e6',
          prompt: "You're buying a $20 desk lamp online. Which sneaky cost should you plan for?",
          choices: [
            { text: 'Shipping and sales tax', correct: true },
            {
              text: 'The light it makes',
              why: 'The light comes with the lamp. No store has ever charged per glow.',
            },
            {
              text: 'How cool it looks on your desk',
              why: 'Looking cool is free. Enjoy it!',
            },
          ],
          explain: 'Online orders often add shipping, and most states add sales tax. Check the total before you tap Buy.',
        },
        {
          type: 'teach',
          id: 't1-u2-l4-e7',
          emoji: '✂️',
          title: 'Over budget? Trim it',
          body: "If your plan costs more than you have, you're **over budget**. You've got options:\n- Cut something you don't really need\n- Swap it for something cheaper\n- Wait and save up more\n\nEach option costs you something: the cake, the confetti, or some time. You get to pick which one stings least.",
          example: 'Party plan: $60. Money: $45. Swap the $15 bakery cake for $5 homemade cupcakes and skip the $5 confetti. New total: $45. Party saved.',
        },
        {
          type: 'number',
          id: 't1-u2-l4-e8',
          prompt: 'Your school trip plan adds up to $55, but you only have $40. How much more money do you need?',
          answer: 15,
          prefix: '$',
          explain: '$55 minus $40 is $15. Now you know the gap, so you can cut something, swap something, or save up a bit more.',
        },
        {
          type: 'fill',
          id: 't1-u2-l4-e9',
          sentence: 'If your plan costs too much, you can ___ something or swap it for something ___.',
          answers: ['cut', 'cheaper'],
          bank: ['cut', 'cheaper', 'double', 'fancier'],
          explain: 'Cut it, or swap it for something cheaper. Doubling it or going fancier would make the problem bigger!',
        },
        {
          type: 'teach',
          id: 't1-u2-l4-e10',
          emoji: '🗺️',
          funFact: true,
          title: 'No sales tax?!',
          body: "Five states don't have a statewide sales tax: Alaska, Delaware, Montana, New Hampshire, and Oregon.\n\nSome towns there (especially in Alaska) still add their own local tax, though. So your checkout surprise depends on your zip code.",
        },
        {
          type: 'match',
          id: 't1-u2-l4-e11',
          prompt: 'Match each event-planning word to its meaning.',
          pairs: [
            { left: 'Cost list', right: 'Every expense, written down' },
            { left: 'Cushion', right: 'Extra cash for surprises' },
            { left: 'Sales tax', right: 'Added to the price at checkout' },
            { left: 'Over budget', right: 'Costs more than you have' },
          ],
          explain: 'You now speak fluent party planner. All you need is a clipboard and a headset.',
        },
        {
          type: 'scenario',
          id: 't1-u2-l4-e12',
          emoji: '🍿',
          setup: "Your friends are coming over for movie night. You have $30. Your cost list: pizza $20, snacks $12, movie rental $6. That's $38.",
          question: 'How do you fix the plan?',
          choices: [
            {
              text: 'Swap the pizza for homemade nachos ($8)',
              best: true,
              outcome: 'New total: $26, with $4 left as a cushion. The nachos are a hit. Nobody even mentions pizza.',
            },
            {
              text: 'Buy it all and figure out the $8 later',
              outcome: "The pizza place does not accept 'later.' Movie night starts with an awkward call home.",
            },
            {
              text: 'Order a second pizza, just to be safe',
              outcome: 'Now it costs $58 and you have $30. That is the opposite of safe.',
            },
            {
              text: 'Cancel movie night forever',
              outcome: 'Dramatic! An $8 trim would have saved the whole night.',
            },
          ],
        },
      ],
    },
  ],

  /* ---------- Unit quiz ---------- */
  quiz: {
    passPercent: 70,
    exercises: [
      {
        type: 'mc',
        id: 't1-u2-q-e1',
        prompt: 'You have $25. Which one is actually a budget?',
        choices: [
          { text: '$10 for snacks, $15 into savings', correct: true },
          {
            text: "I'll just see what happens",
            why: "That's not a plan, that's a coin flip. A budget decides before you spend.",
          },
          {
            text: 'A list of games you wish you had',
            why: "That's a wishlist. A budget gives each dollar an actual job.",
          },
          {
            text: 'The amount of cash in your wallet',
            why: "That's how much you have. A budget is the plan for it.",
          },
        ],
        explain: '$10 + $15 = $25, and every dollar has a job. Real numbers, decided ahead of time. That is a budget.',
      },
      {
        type: 'match',
        id: 't1-u2-q-e2',
        prompt: 'Match each money word to its meaning.',
        pairs: [
          { left: 'Income', right: 'Money that comes in' },
          { left: 'Expense', right: 'Money that goes out' },
          { left: 'Budget', right: 'A plan for your money' },
          { left: 'Savings', right: 'Money kept for later' },
        ],
        explain: 'Income in, expenses out, savings for later, and a budget to boss them all around.',
      },
      {
        type: 'number',
        id: 't1-u2-q-e3',
        prompt: 'You earn $80 babysitting and split it 50/30/20. How many dollars go to savings?',
        answer: 16,
        prefix: '$',
        explain: '10% of $80 is $8, so 20% is $16. You watched a kid AND grew your savings. Multitasking pro.',
      },
      {
        type: 'mc',
        id: 't1-u2-q-e4',
        prompt: 'You get $200 and use the 50/30/20 rule. How much goes to wants?',
        choices: [
          { text: '$60', correct: true },
          {
            text: '$30',
            why: "That's 30% of $100, but you have $200. 10% of $200 is $20, so 30% is $60.",
          },
          { text: '$100', why: "That's the needs slice: half of $200." },
          { text: '$40', why: "That's the savings slice, 20% of $200." },
        ],
        explain: '10% of $200 is $20. Wants get 30%, which is three of those: $60.',
      },
      {
        type: 'sort',
        id: 't1-u2-q-e5',
        prompt: 'Needs, wants, or savings? Drop each one in.',
        buckets: ['Needs', 'Wants', 'Savings'],
        items: [
          { text: 'Toothpaste', bucket: 0 },
          { text: 'Bus pass for school', bucket: 0 },
          { text: 'Limited-edition sneakers', bucket: 1 },
          { text: 'Movie night tickets', bucket: 1 },
          { text: 'Cash tucked away for later', bucket: 2 },
          { text: 'Savings jar deposit', bucket: 2 },
        ],
        explain: 'Toothpaste and getting to school are must-haves. Fancy sneakers and movies are fun extras. Anything set aside for later is savings.',
      },
      {
        type: 'tf',
        id: 't1-u2-q-e6',
        statement: 'Checking your spending once a week can help you catch money leaks early.',
        answer: true,
        explain: 'Totally true. A quick weekly check shows which tiny buys are piling up, before they eat your whole month.',
      },
      {
        type: 'number',
        id: 't1-u2-q-e7',
        prompt: 'You buy a $2 candy bar every school day (5 days a week). How much is that in 4 weeks?',
        answer: 40,
        prefix: '$',
        explain: '$2 × 5 = $10 a week, and $10 × 4 weeks = $40. That is one sweet leak.',
      },
      {
        type: 'fill',
        id: 't1-u2-q-e8',
        sentence: 'Writing down every purchase you make is called ___ your spending.',
        answers: ['tracking'],
        bank: ['tracking', 'hiding', 'ignoring', 'juggling'],
        explain: 'Tracking is how you find out where your money really goes. Hiding or ignoring it just turns it into a mystery.',
      },
      {
        type: 'mc',
        id: 't1-u2-q-e9',
        prompt: "You're budgeting for a $90 bike. What else belongs on your cost list?",
        choices: [
          { text: 'Sales tax, plus a helmet and a lock', correct: true },
          {
            text: 'Nothing, $90 covers it all',
            why: 'The $90 is just the tag. Most states add tax at checkout, and a bike with no helmet or lock is a risky (and pricey) idea.',
          },
          {
            text: 'A second bike, just in case',
            why: 'One bike is plenty, unless you have two sets of legs. A helmet is a way better use of that cash.',
          },
          {
            text: 'A trophy for buying a bike',
            why: 'Cute idea, but bragging rights are free.',
          },
        ],
        explain: "Big goals bring sidekicks, like tax and safety gear. Put them all on the list so the total doesn't ambush you.",
      },
      {
        type: 'scenario',
        id: 't1-u2-q-e10',
        emoji: '🎁',
        setup: 'You have $40 to buy holiday gifts for 4 family members. At the very first store, you spot a perfect $25 sweater for your mom.',
        question: 'What do you do?',
        choices: [
          {
            text: 'Plan all 4 gifts before buying anything',
            best: true,
            outcome: 'You give each person about $10, find Mom a cozy $10 scarf, and nobody gets left out. Holiday hero.',
          },
          {
            text: 'Grab the sweater and figure out the rest later',
            outcome: 'Now you have $15 for three people. Grandpa gets a single sock. He looks very confused.',
          },
          {
            text: 'Buy whatever looks fun and hope it adds up',
            outcome: 'It adds up to $52. You have $40. The cashier gives you a very sympathetic look.',
          },
        ],
      },
    ],
  },
}

export default unit
