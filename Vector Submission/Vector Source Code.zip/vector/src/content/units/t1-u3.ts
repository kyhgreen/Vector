import type { Unit } from "../types"

const unit: Unit = {
  id: "t1-u3",
  tier: 1,
  order: 3,
  title: "Saving Up",
  tagline: "Future you called. They'd like a few dollars.",
  color: "teal",
  emoji: "🐷",

  guidebook: {
    intro:
      "Saving is just spending later, on purpose. It's also how you survive the day your earbuds go through the wash.",
    keyIdeas: [
      {
        title: "Saving is spending later",
        body: "Saving covers things your weekly money can't, and keeps a surprise cost a hiccup instead of a meltdown.",
      },
      {
        title: "Short-term vs. long-term",
        body: "Short-term goals are less than a year away, like a game. Long-term goals are a year or more out, like a car or college. Bigger goal, longer runway.",
      },
      {
        title: "Pay yourself first",
        body: "Move your savings somewhere separate the moment money comes in, then spend the rest. Saving \"whatever's left\" usually means saving a gum wrapper.",
      },
      {
        title: "Goal math",
        body: "Price ÷ weekly savings = weeks. Subtract any head start first, and round up. On a deadline, flip it: price ÷ weeks = weekly savings.",
      },
      {
        title: "Emergency funds",
        body: "Money only for surprise costs you have to pay. Teens can aim for $100 to $500 (grown-ups aim for 3 to 6 months of expenses). Use it, then refill it.",
      },
    ],
    funFacts: [
      "Gray squirrels never dig up some of their buried acorns, which can grow into trees: bad savings plan, great tree-planting plan.",
      "A camel's hump stores fat (not water) for when food runs low, like a lumpy emergency fund.",
      "In later versions of the famous marshmallow test, kids waited longer for treat number two when they trusted the grown-up to actually bring it.",
      "A 1920s book, \"The Richest Man in Babylon,\" said to keep at least one of every ten coins you earn: pay yourself first, silent-movie style.",
      "The German verb \"hamstern\" means to stockpile, after hamsters, who stuff food in their cheeks to save for later.",
    ],
    words: [
      { term: "Saving", meaning: "Keeping money now to use later." },
      { term: "Goal", meaning: "What you're saving for." },
      { term: "Short-term goal", meaning: "A goal less than a year away." },
      { term: "Long-term goal", meaning: "A goal a year or more away." },
      { term: "Pay yourself first", meaning: "Saving before you spend any." },
      { term: "Percent (%)", meaning: "Out of every 100, so 10% of $20 is $2." },
      { term: "Surprise expense", meaning: "A cost you didn't see coming." },
      { term: "Emergency fund", meaning: "Money saved just for surprise costs." },
    ],
  },

  lessons: [
    /* ---------------- Lesson 1: Why save? ---------------- */
    {
      id: "t1-u3-l1",
      title: "Why Save?",
      description: "Some goals are days away. Some are years away. Both need a plan.",
      exercises: [
        {
          type: "teach",
          id: "t1-u3-l1-e1",
          emoji: "🐷",
          title: "Saving = spending later",
          body: "**Saving** means keeping some money now so you can use it later.\n\nIt's not \"never buy anything.\" It's how you get bigger stuff your weekly money can't cover, and how a surprise cost turns into a shrug instead of a panic.",
          example: "You get $10 a week. A $50 skateboard feels like a fantasy. Save that $10 for 5 weeks and suddenly it's yours. Wheels: acquired.",
        },
        {
          type: "mc",
          id: "t1-u3-l1-e2",
          prompt: "Why do people save instead of spending everything right away?",
          choices: [
            {
              text: "Because cash grows if you leave it in a drawer",
              why: "Sadly, drawer money just sits there. $20 goes in, $20 comes out, plus maybe some lint.",
            },
            { text: "To afford bigger things later and handle surprises", correct: true },
            {
              text: "Because spending money is basically bad",
              why: "Spending isn't evil! Saving just means some of your money waits its turn.",
            },
            {
              text: "So they can roll around in a giant pile of cash",
              why: "Coins are lumpy and paper cuts are real. Savers want a goal, not a cash bed.",
            },
          ],
          explain: "Saving turns small, boring amounts into real options. That $10 a week can become a skateboard, or a bike fix that doesn't wreck your month.",
        },
        {
          type: "tf",
          id: "t1-u3-l1-e3",
          statement: "Once you save money, you're never allowed to spend it.",
          answer: false,
          explain: "Totally false. Savings aren't locked in a vault forever. Hit your goal, buy the thing, enjoy every second. That's the payoff for waiting.",
        },
        {
          type: "teach",
          id: "t1-u3-l1-e4",
          emoji: "🎯",
          title: "Short-term vs. long-term goals",
          body: "A **goal** is the thing you're saving up for. Goals come in two flavors:\n\n- **Short-term:** less than a year away, like a new game or a friend's gift\n- **Long-term:** a year or more away, like a car or college\n\nBigger goals need more time, so the earlier you start, the less it hurts.",
          example: "Concert tickets next month? Short-term. Your first car, years from now? Long-term (and the price tag shows it).",
        },
        {
          type: "sort",
          id: "t1-u3-l1-e5",
          prompt: "Short-term or long-term? Sort these goals.",
          buckets: ["Short-term", "Long-term"],
          items: [
            { text: "Pizza night this Friday", bucket: 0 },
            { text: "A car in four years", bucket: 1 },
            { text: "A new game next month", bucket: 0 },
            { text: "College after high school", bucket: 1 },
            { text: "Summer camp in 3 months", bucket: 0 },
            { text: "A trip in two years", bucket: 1 },
          ],
          explain: "Less than a year away? Short-term. A year or more? Long-term. Pizza is always short-term. Pizza does not wait.",
        },
        {
          type: "mc",
          id: "t1-u3-l1-e6",
          prompt: "Maya saves $5 a week for a laptop she wants in 2 years. What kind of goal is that?",
          choices: [
            {
              text: "Short-term",
              why: "So close! But 2 years is more than a year off, and that makes it long-term.",
            },
            { text: "Long-term", correct: true },
            {
              text: "Not a goal, just a daydream",
              why: "It has a price tag and a deadline. That's a goal with a plan, not a daydream.",
            },
          ],
          explain: "Anything a year or more away is a long-term goal. Maya's future laptop is lucky to have her.",
        },
        {
          type: "teach",
          id: "t1-u3-l1-e7",
          emoji: "🍬",
          funFact: true,
          title: "The famous marshmallow test",
          body: "Decades ago, Stanford researchers gave kids a choice: one treat (like a marshmallow) right now, or two if they could wait a while.\n\nWaiting was HARD. Some kids covered their eyes or sang songs to distract themselves.\n\nLater studies found kids waited longer when they **trusted** the grown-up to actually bring treat number two. Turns out a plan you believe in makes waiting way easier.",
        },
        {
          type: "fill",
          id: "t1-u3-l1-e8",
          prompt: "Finish the sentences.",
          sentence: "Saving for pizza this weekend is a ___ goal. Saving for college is a ___ goal.",
          answers: ["short-term", "long-term"],
          bank: ["long-term", "part-time", "short-term", "overtime"],
          explain: "Pizza is days away (short-term). College is years away (long-term). Both are worth saving for. One is just cheesier.",
        },
        {
          type: "match",
          id: "t1-u3-l1-e9",
          prompt: "Match each word to what it means.",
          pairs: [
            { left: "Saving", right: "Keeping money to use later" },
            { left: "Goal", right: "The thing you're saving up for" },
            { left: "Short-term", right: "Less than a year away" },
            { left: "Long-term", right: "A year or more away" },
          ],
          explain: "Look at you, speaking fluent saver.",
        },
        {
          type: "tf",
          id: "t1-u3-l1-e10",
          statement: "Saving $5 for something you want next week still counts as saving.",
          answer: true,
          explain: "Totally true. A $5 goal is still a goal. Think of it as the tutorial level before the boss fight (the car).",
        },
        {
          type: "scenario",
          id: "t1-u3-l1-e11",
          emoji: "🎂",
          setup: "You just got $25 in birthday money. You've been eyeing a $60 game for weeks. Then your friend texts: \"Arcade today? Bring ALL the money.\"",
          question: "What's the smartest move?",
          choices: [
            {
              text: "Spend all $25 at the arcade today",
              outcome: "Great afternoon, 400 prize tickets (enough for one eraser), and the game is still a full $60 away.",
            },
            {
              text: "Put $20 toward the game and bring $5 to the arcade",
              best: true,
              outcome: "You still get your arcade fix, and you're a third of the way to the game. Fun AND a plan.",
            },
            {
              text: "Spend it all on the first shiny thing you see",
              outcome: "You now own a light-up keychain shaped like a taco. The game is still $60 away.",
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 2: Pay yourself first ---------------- */
    {
      id: "t1-u3-l2",
      title: "Pay Yourself First",
      description: "The money move that works even when you only have, like, $4.",
      exercises: [
        {
          type: "teach",
          id: "t1-u3-l2-e1",
          emoji: "🫙",
          title: "Pay yourself first",
          body: "Lots of people spend first and save whatever's left. Spoiler: usually nothing's left.\n\n**Pay yourself first** flips it. The moment money comes in, move your savings out of reach. THEN spend the rest, guilt-free.\n\n\"Yourself\" here means future you. Future you is already writing a thank-you note.",
          example: "You earn $20 walking dogs. Before anything else, $4 goes in your savings jar. The other $16 is yours, no guilt attached.",
        },
        {
          type: "mc",
          id: "t1-u3-l2-e2",
          prompt: "What does \"pay yourself first\" mean?",
          choices: [
            {
              text: "Buy yourself a treat before anything else",
              why: "Tempting way to read it! But you're paying FUTURE you, into savings, not present you with snacks.",
            },
            {
              text: "Save whatever's left at the end of the week",
              why: "That's pay yourself LAST, and last place usually wins $0.",
            },
            { text: "Save a chunk the moment money comes in", correct: true },
            {
              text: "Charge your family for doing chores",
              why: "Bold business plan. But pay yourself first is about what you do with money once you have it.",
            },
          ],
          explain: "Savings go first, spending goes second. Same money, way better results.",
        },
        {
          type: "tf",
          id: "t1-u3-l2-e3",
          statement: "With pay yourself first, you save whatever is left after spending.",
          answer: false,
          explain: "That's backward, so it's false. Save FIRST, then spend what's left. Leftovers belong in the fridge, not in your savings plan.",
        },
        {
          type: "teach",
          id: "t1-u3-l2-e4",
          emoji: "📜",
          funFact: true,
          title: "A century-old money trick",
          body: "This trick is OLD. Like, silent-movie old. A popular book from the 1920s, \"The Richest Man in Babylon,\" told readers to keep at least one out of every ten coins they earned.\n\nOne out of ten is **10%**. About 100 years later, people still swear by it.",
        },
        {
          type: "teach",
          id: "t1-u3-l2-e5",
          emoji: "🍕",
          title: "Pick your slice",
          body: "Pay yourself first works with any amount. Pick a **percent** (that means \"out of every 100\") and save that slice every time.\n\n- 10% = divide by 10\n- 20% = double the 10%\n- 25% = one quarter\n- 50% = half",
          example: "You earn $30. 10% is $3. 20% is $6. 50% is $15. Pick a slice you can actually stick with. Small every time beats huge once.",
        },
        {
          type: "number",
          id: "t1-u3-l2-e6",
          prompt: "You earn $40 mowing a lawn. You pay yourself first with 10%. How many dollars go into savings?",
          answer: 4,
          prefix: "$",
          explain: "10% of $40 is $40 ÷ 10 = $4. Four bucks for future you, $36 for present you.",
        },
        {
          type: "teach",
          id: "t1-u3-l2-e7",
          emoji: "🙈",
          title: "Out of sight, out of mind",
          body: "Money that hangs out with your spending cash gets spent. It's peer pressure, but for dollars.\n\nSo give your savings its own home:\n- A jar or envelope with your goal written on it\n- A grown-up who holds it for you\n- A savings account (until 18, most need a parent or guardian on them)\n\nSave on the same day every time, so it becomes **automatic**.",
        },
        {
          type: "mc",
          id: "t1-u3-l2-e8",
          prompt: "Why give your savings its own jar, envelope, or account?",
          choices: [
            { text: "So you don't spend it by accident", correct: true },
            {
              text: "Because jars make money multiply",
              why: "Jars are great at holding pickles. Making money multiply? Not their thing.",
            },
            {
              text: "Because mixing your money is against the law",
              why: "No money police are coming, promise. It's just way too easy to spend savings that hang out with snack money.",
            },
          ],
          explain: "Separate money is safer money. When savings live somewhere else, impulse buys can't grab them.",
        },
        {
          type: "sort",
          id: "t1-u3-l2-e9",
          prompt: "Pay yourself first or pay yourself last? Sort these habits.",
          buckets: ["Pays first", "Pays last"],
          items: [
            { text: "Saves $3 right when paid", bucket: 0 },
            { text: "Saves Sunday's leftovers", bucket: 1 },
            { text: "Stashes $5 before shopping", bucket: 0 },
            { text: "Spends, then checks what's left", bucket: 1 },
            { text: "Auto-saves when money arrives", bucket: 0 },
            { text: "Hopes some money survives", bucket: 1 },
          ],
          explain: "Pay-first savers move money before they spend. Pay-last savers hope for leftovers, and hope is not a plan.",
        },
        {
          type: "fill",
          id: "t1-u3-l2-e10",
          prompt: "Fill in the money motto.",
          sentence: "Pay yourself ___, then spend what's ___.",
          answers: ["first", "left"],
          bank: ["last", "first", "borrowed", "left", "never"],
          explain: "Savings first, spending second. Write it on your hand if you have to (washable marker, please).",
        },
        {
          type: "number",
          id: "t1-u3-l2-e11",
          prompt: "Your allowance is $20. You save 25% first. How many dollars do you have left to spend?",
          answer: 15,
          prefix: "$",
          explain: "25% is one quarter, and a quarter of $20 is $5 (way better than an actual quarter). That leaves $15 to spend.",
        },
        {
          type: "scenario",
          id: "t1-u3-l2-e12",
          emoji: "🐱",
          setup: "You just got paid $20 for pet sitting a very dramatic cat. You're saving for $80 headphones. Your friends want to hit the mall in an hour.",
          question: "What do you do with the $20?",
          choices: [
            {
              text: "Bring all $20 and save whatever's left after",
              outcome: "You come home with 75 cents and a pretzel. Pay yourself last strikes again.",
            },
            {
              text: "Borrow $20 from a friend so yours stays untouched",
              outcome: "Now you owe your friend $20. That's not saving, that's just owing with extra steps.",
            },
            {
              text: "Put $5 in your savings jar, then take $15 to the mall",
              best: true,
              outcome: "Mall trip: fun. Headphones: $5 closer. The cat: still dramatic, but you're winning.",
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 3: Goal math ---------------- */
    {
      id: "t1-u3-l3",
      title: "Goal Math",
      description: "How many weeks until it's yours? Division knows.",
      exercises: [
        {
          type: "teach",
          id: "t1-u3-l3-e1",
          emoji: "🧮",
          title: "The weeks-to-goal formula",
          body: "Want to know how long until something is yours? Use this:\n\n**Price ÷ savings per week = weeks**\n\nThat's it. No calculator, no crystal ball.",
          example: "A $60 game. You save $10 a week. $60 ÷ $10 = 6 weeks. Mark your calendar.",
        },
        {
          type: "number",
          id: "t1-u3-l3-e2",
          prompt: "A skateboard deck costs $45. You save $5 a week. How many weeks until you can buy it?",
          answer: 9,
          suffix: "weeks",
          explain: "$45 ÷ $5 = 9 weeks. Just over two months and you're rolling.",
        },
        {
          type: "mc",
          id: "t1-u3-l3-e3",
          prompt: "You want $100 sneakers and save $20 a week. How long will it take?",
          choices: [
            {
              text: "20 weeks",
              why: "That's how much you save each week, not how long. Divide $100 by $20.",
            },
            {
              text: "80 weeks",
              why: "That's $100 minus $20. Goal math divides, it doesn't subtract.",
            },
            { text: "5 weeks", correct: true },
            {
              text: "2 weeks",
              why: "Two weeks only gets you $40. Those sneakers are still sitting on the shelf.",
            },
          ],
          explain: "$100 ÷ $20 = 5 weeks. Your feet are going to be so happy.",
        },
        {
          type: "teach",
          id: "t1-u3-l3-e4",
          emoji: "🏁",
          title: "Head starts and rounding up",
          body: "Two tricks:\n\n- **Already saved some?** Subtract it from the price first.\n- **Got a decimal?** Round UP. If the math says 4.5 weeks, plan on 5, because after 4 weeks you'll still be a little short.",
          example: "A $50 hoodie. You have $14 already, so you need $36 more. Saving $8 a week: $36 ÷ $8 = 4.5, so 5 weeks.",
        },
        {
          type: "number",
          id: "t1-u3-l3-e5",
          prompt: "You want a $70 jacket. You already have $30 saved and add $10 a week. How many more weeks do you need?",
          answer: 4,
          suffix: "weeks",
          explain: "$70 minus your $30 head start leaves $40. Then $40 ÷ $10 = 4 weeks. Jacket weather, here you come.",
        },
        {
          type: "tf",
          id: "t1-u3-l3-e6",
          statement: "If the goal math says 4.5 weeks, you need to save for 5 weeks.",
          answer: true,
          explain: "True. Week 4 leaves you a few bucks short, and cashiers don't accept \"almost.\"",
        },
        {
          type: "teach",
          id: "t1-u3-l3-e7",
          emoji: "🔙",
          title: "Work it backward",
          body: "Got a deadline? Flip the formula:\n\n**Price ÷ weeks = savings per week**\n\nNow you know exactly how much to save each week to make it in time.",
          example: "The school trip costs $36 and it's 6 weeks away. $36 ÷ 6 = $6 a week. Done.",
        },
        {
          type: "number",
          id: "t1-u3-l3-e8",
          prompt: "A concert ticket costs $48 and the show is 8 weeks away. How many dollars do you need to save each week?",
          answer: 6,
          prefix: "$",
          suffix: "per week",
          explain: "$48 ÷ 8 weeks = $6 a week. Big concert, tiny weekly budget.",
        },
        {
          type: "teach",
          id: "t1-u3-l3-e9",
          emoji: "🪙",
          funFact: true,
          title: "Spare change, big results",
          body: "Save just $1 a day and you'll have $365 after a year (366 in a leap year, bonus dollar!).\n\nEven a quarter a day turns into **$91.25** by the end of the year. Pocket change looks puny, but after a year of daily reps it's kind of buff.",
        },
        {
          type: "fill",
          id: "t1-u3-l3-e10",
          prompt: "Finish the goal math rule.",
          sentence: "To find how many weeks you need, ___ the price by what you save each week. If you get a decimal, round ___.",
          answers: ["divide", "up"],
          bank: ["multiply", "divide", "down", "up", "sideways"],
          explain: "Divide to find the weeks, then round up so you're never a few bucks short at the register.",
        },
        {
          type: "match",
          id: "t1-u3-l3-e11",
          prompt: "Match each goal to how long it takes.",
          pairs: [
            { left: "$30 at $5/week", right: "6 weeks" },
            { left: "$40 at $10/week", right: "4 weeks" },
            { left: "$90 at $10/week", right: "9 weeks" },
            { left: "$24 at $3/week", right: "8 weeks" },
          ],
          explain: "Price ÷ weekly savings, every time. You're basically a walking goal calculator now.",
        },
        {
          type: "scenario",
          id: "t1-u3-l3-e12",
          emoji: "🪴",
          setup: "You save $5 a week for a $60 game. That's 12 whole weeks. Then your neighbor offers you $5 a week to water her plants.",
          question: "What gets you the game fastest?",
          choices: [
            {
              text: "Take the gig and spend the extra on snacks",
              outcome: "Tasty, but you're still waiting the full 12 weeks. The snacks say thanks.",
            },
            {
              text: "Take the gig and save that $5 too",
              best: true,
              outcome: "Now you're saving $10 a week, so 12 weeks shrinks to 6. And the plants are thriving.",
            },
            {
              text: "Skip saving this week to celebrate the new gig",
              outcome: "Fun party, but a week off means the game shows up a week later.",
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 4: Surprise expenses & emergency funds ---------------- */
    {
      id: "t1-u3-l4",
      title: "Surprise Expenses",
      description: "Stuff breaks. Here's how to be ready when it does.",
      exercises: [
        {
          type: "teach",
          id: "t1-u3-l4-e1",
          emoji: "🌪️",
          title: "Life loves a plot twist",
          body: "A **surprise expense** is a cost you didn't see coming. Your bike tire pops. Your earbuds go for a spin in the washing machine.\n\nEveryone gets them, and they never check your schedule first.",
          example: "Monday: zero problems. Tuesday: your library book takes a bath and you owe a $15 fee. Thanks, Tuesday.",
        },
        {
          type: "mc",
          id: "t1-u3-l4-e2",
          prompt: "Which one is a surprise expense?",
          choices: [
            {
              text: "Lunch money you pay every week",
              why: "That happens every week, so you can plan for it. No surprise there.",
            },
            {
              text: "A game you've been saving up for",
              why: "You saw that one coming for weeks. That's a goal, not a surprise.",
            },
            {
              text: "A gift for a party next month",
              why: "You know about it ahead of time, so you can plan for it.",
            },
            { text: "Your bike tire pops on the way to school", correct: true },
          ],
          explain: "Surprise expenses pop up out of nowhere. Kind of like that bike tire did.",
        },
        {
          type: "teach",
          id: "t1-u3-l4-e3",
          emoji: "🛟",
          title: "Meet your emergency fund",
          body: "An **emergency fund** is money you save ONLY for surprise costs you actually need to pay.\n\n- For teens, $100 to $500 is a solid first goal\n- Grown-ups aim for 3 to 6 months of expenses (rent, food, bills)\n\nIt's for \"uh oh,\" not \"ooh, shiny.\"",
          example: "You keep $100 in an envelope labeled UH OH ONLY. Your calculator vanishes the night before a math test? Covered. No panic.",
        },
        {
          type: "tf",
          id: "t1-u3-l4-e4",
          statement: "An emergency fund is for surprise costs, not for stuff that's on sale.",
          answer: true,
          explain: "True. A sale is pure \"ooh, shiny,\" even at 50% off. The emergency fund only answers to \"uh oh.\"",
        },
        {
          type: "fill",
          id: "t1-u3-l4-e5",
          prompt: "Fill in the blanks.",
          sentence: "An emergency fund is for ___ costs. Grown-ups aim for 3 to 6 ___ of expenses.",
          answers: ["surprise", "months"],
          bank: ["shopping", "surprise", "minutes", "months", "birthday"],
          explain: "Emergency funds cover surprises. Grown-ups aim for 3 to 6 months of expenses, and teens can start with $100 to $500. (Six minutes of expenses is just a snack.)",
        },
        {
          type: "teach",
          id: "t1-u3-l4-e6",
          emoji: "🐪",
          funFact: true,
          title: "Camels have emergency funds",
          body: "A camel's hump isn't full of water. It's mostly **fat**.\n\nWhen food is hard to find, a camel can use that fat for energy. The hump is basically a built-in emergency fund, just way lumpier.",
        },
        {
          type: "sort",
          id: "t1-u3-l4-e7",
          prompt: "Should your emergency fund pay? Sort each cost into \"uh oh\" (use the fund) or \"ooh, shiny\" (hands off).",
          buckets: ["Uh oh", "Ooh, shiny"],
          items: [
            { text: "Fixing your bike's flat tire", bucket: 0 },
            { text: "Limited-edition game skin", bucket: 1 },
            { text: "Replacing a lost calculator", bucket: 0 },
            { text: "Sneakers on sale", bucket: 1 },
            { text: "Lost library book fee", bucket: 0 },
            { text: "Bubble tea craving", bucket: 1 },
          ],
          explain: "Uh oh = surprise costs you need to pay. Ooh, shiny = wants. Wants are great, they just come from fun money or goal savings.",
        },
        {
          type: "teach",
          id: "t1-u3-l4-e8",
          emoji: "🔁",
          title: "Use it, then refill it",
          body: "Emergency funds are meant to be used. That's their whole job!\n\nAfter you use some, refill it the same way you built it: **pay yourself first**, a little at a time, until it's full again.\n\nKeep it apart from your goal money so the two don't get mixed up.",
        },
        {
          type: "mc",
          id: "t1-u3-l4-e9",
          prompt: "You just used $30 of your emergency fund to fix your bike. What now?",
          choices: [
            {
              text: "Spend what's left, it's already dented",
              why: "A dented fund still works! Spending the rest just leaves future you with nothing.",
            },
            { text: "Refill it a little at a time", correct: true },
            {
              text: "Never touch it again, even for emergencies",
              why: "A fund you never use is just a very sad envelope. Fixing the bike was the right call.",
            },
            {
              text: "Relax, surprises only happen once",
              why: "If only! Surprises love a sequel. Refill it so you're ready.",
            },
          ],
          explain: "Use it, then refill it. A few bucks off the top of each payday and your safety net is back to full strength before the next plot twist.",
        },
        {
          type: "tf",
          id: "t1-u3-l4-e10",
          statement: "A new game coming out is a good reason to use your emergency fund.",
          answer: false,
          explain: "False. You knew that game was coming (there were trailers!). That's a job for goal savings, not the uh-oh envelope.",
        },
        {
          type: "number",
          id: "t1-u3-l4-e11",
          prompt: "You want a $100 emergency fund. You save $5 a week. How many weeks will it take?",
          answer: 20,
          suffix: "weeks",
          explain: "$100 ÷ $5 = 20 weeks. That's under five months to a real safety net. Goal math, back for a cameo.",
        },
        {
          type: "scenario",
          id: "t1-u3-l4-e12",
          emoji: "🚲",
          setup: "You have $120 in your emergency fund and $40 saved for a game. Your bike chain snaps, and you ride that bike to your dog-walking gig. The fix costs $25.",
          question: "How do you pay for it?",
          choices: [
            {
              text: "Use the emergency fund, then refill it",
              best: true,
              outcome: "Bike fixed, game money untouched, and the dogs get their walks. Textbook uh-oh handling.",
            },
            {
              text: "Use your game money instead",
              outcome: "Bike's fixed, but your game just got pushed back weeks. Meanwhile, the emergency fund sat there, unemployed.",
            },
            {
              text: "Skip the repair and stop dog walking for a while",
              outcome: "You kept your $25, but lost your dog-walking money. The dogs miss you. Ouch.",
            },
          ],
        },
      ],
    },
  ],

  quiz: {
    passPercent: 70,
    exercises: [
      {
        type: "mc",
        id: "t1-u3-q-e1",
        prompt: "Which of these is a long-term goal?",
        choices: [
          {
            text: "Pizza with friends this Friday",
            why: "That's days away. Short-term, and delicious.",
          },
          { text: "Saving for college after high school", correct: true },
          {
            text: "A $10 book next week",
            why: "Next week is way less than a year away. Short-term!",
          },
          {
            text: "Movie snacks tonight",
            why: "Tonight is about as short-term as it gets.",
          },
        ],
        explain: "Long-term means a year or more away. College is years off, and it costs a bit more than pizza.",
      },
      {
        type: "tf",
        id: "t1-u3-q-e2",
        statement: "Saving for concert tickets next month is a short-term goal.",
        answer: true,
        explain: "Yep, true. Next month is way under a year away, so it's short-term.",
      },
      {
        type: "match",
        id: "t1-u3-q-e3",
        prompt: "Match each money word to its meaning.",
        pairs: [
          { left: "Saving", right: "Money you keep for later" },
          { left: "Pay yourself first", right: "Save before you spend anything" },
          { left: "Surprise expense", right: "A cost you didn't see coming" },
          { left: "Emergency fund", right: "Money set aside for surprises" },
        ],
        explain: "Vocab: nailed. You could teach this unit to your cat now.",
      },
      {
        type: "mc",
        id: "t1-u3-q-e4",
        prompt: "You earn $20 raking leaves. Which move is pay yourself first?",
        choices: [
          {
            text: "Spend it, then save any change",
            why: "That's pay yourself last. The change usually turns into gum.",
          },
          {
            text: "Buy yourself a treat as a reward",
            why: "Treats are fine, but \"yourself\" means future you. Savings go first.",
          },
          { text: "Put $4 in savings, then spend the rest", correct: true },
          {
            text: "Wait until Sunday to see what's left",
            why: "By Sunday, the money has usually wandered off. Save it first.",
          },
        ],
        explain: "Four bucks to future you before anything else. The other $16 is yours, zero guilt.",
      },
      {
        type: "number",
        id: "t1-u3-q-e5",
        prompt: "You earn $25 washing your neighbor's car. You save 20% first. How many dollars go to savings?",
        answer: 5,
        prefix: "$",
        explain: "10% of $25 is $2.50. Double it for 20% and you get $5. That leaves $20 for you.",
      },
      {
        type: "fill",
        id: "t1-u3-q-e6",
        prompt: "Fill in the blanks.",
        sentence: "Keep your savings in a ___ place so it's ___ to spend by accident.",
        answers: ["separate", "harder"],
        bank: ["easier", "separate", "shared", "harder", "faster"],
        explain: "Separate savings are harder to spend on a whim. Out of sight, out of mind (and out of the snack aisle).",
      },
      {
        type: "number",
        id: "t1-u3-q-e7",
        prompt: "A speaker costs $72. You save $8 a week. How many weeks until you can buy it?",
        answer: 9,
        suffix: "weeks",
        explain: "$72 ÷ $8 = 9 weeks. In about two months, you can turn it up.",
      },
      {
        type: "mc",
        id: "t1-u3-q-e8",
        prompt: "You need $50 and save $8 a week. What's the fewest number of weeks it'll take?",
        choices: [
          {
            text: "6 weeks",
            why: "Six weeks gets you $48. So close, but $2 short at the register!",
          },
          { text: "7 weeks", correct: true },
          {
            text: "42 weeks",
            why: "Oops, you subtracted ($50 minus $8). Divide instead, then round up.",
          },
          {
            text: "58 weeks",
            why: "You added $8 to $50. That's over a year of waiting for something 7 weeks away.",
          },
        ],
        explain: "$50 ÷ $8 = 6.25, so round up to 7 weeks. After week 7 you'll have $56. Enough, with $6 to spare.",
      },
      {
        type: "sort",
        id: "t1-u3-q-e9",
        prompt: "Sort each cost into \"uh oh\" (the emergency fund pays) or \"ooh, shiny\" (hands off).",
        buckets: ["Uh oh", "Ooh, shiny"],
        items: [
          { text: "A trendy new hoodie", bucket: 1 },
          { text: "Your school ID went missing", bucket: 0 },
          { text: "A flash sale on headphones", bucket: 1 },
          { text: "Fixing broken bike brakes", bucket: 0 },
          { text: "Extra snacks for movie night", bucket: 1 },
          { text: "Replacing a lost house key", bucket: 0 },
        ],
        explain: "You can't skip fixing your brakes or getting back into your house. Those are uh-ohs. The hoodie can wait for fun money (it'll still be trendy-ish).",
      },
      {
        type: "scenario",
        id: "t1-u3-q-e10",
        emoji: "👵",
        setup: "You just used your whole $50 emergency fund to replace a lost calculator (oops). Then Grandma mails you $40. You're also saving for a $60 game.",
        question: "What's the best plan for Grandma's $40?",
        choices: [
          {
            text: "Spend it all on a giant candy haul",
            outcome: "Sugar rush: amazing. Emergency fund: still $0. Game: still $60 away.",
          },
          {
            text: "Split it between refilling the fund and the game",
            best: true,
            outcome: "Your safety net starts rebuilding AND the game gets closer. Grandma's $40 just did two jobs at once.",
          },
          {
            text: "Put it all toward the game and hope nothing breaks",
            outcome: "The game gets closer, but with $0 in your fund, the next surprise is going to sting.",
          },
        ],
      },
    ],
  },
}

export default unit
