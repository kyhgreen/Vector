import type { Unit } from "../types"

const unit: Unit = {
  id: "t2-u5",
  tier: 2,
  order: 5,
  title: "Investing for Real",
  tagline: "Boring investing for a very not-boring future.",
  color: "pink",
  emoji: "📊",

  guidebook: {
    intro:
      "This unit covers index funds, retirement accounts, crashes, and hype. Spoiler: the boring move usually wins.",
    keyIdeas: [
      {
        title: "Buy the whole haystack",
        body: "An index fund copies a market list, like the S&P 500, so you own a little of everything on it. ETFs and mutual funds can both be index funds.",
      },
      {
        title: "Spread it out",
        body: "Diversification means owning lots of companies across industries and countries, so one flop can't wreck you.",
      },
      {
        title: "Your timeline picks the spot",
        body: "Money you need in a few years belongs in savings. Money for decades from now can ride out crashes, unless you panic and sell.",
      },
      {
        title: "Grab the match",
        body: "A 401(k) is a retirement plan through a job, and a match is extra money your employer adds when you contribute. Skipping it leaves pay on the table.",
      },
      {
        title: "Roth IRAs love young earners",
        body: "You put in money that's already taxed, and qualified withdrawals in retirement are tax-free. You need earned income, and under 18 an adult runs it as a custodial Roth IRA.",
      },
      {
        title: "Hype is not a plan",
        body: "Crypto and meme stocks can soar and crash fast, and guaranteed huge returns are a red flag. Fees matter too: 1% a year eats far more than 0.1%.",
      },
    ],
    funFacts: [
      "The first index fund for everyday investors, launched in 1976, was mocked as \"Bogle's Folly,\" and index funds now hold trillions of dollars.",
      "The first US ETF launched in 1993 and tracked the S&P 500.",
      "The name \"401(k)\" is just the section of the US tax code that created it, which is exactly as thrilling as it sounds.",
      "In 2010, a programmer paid 10,000 bitcoin for two pizzas, and their \"value\" has since swung by hundreds of millions of dollars.",
      "Bitcoin's creator used the name Satoshi Nakamoto, and nobody has proven who that really is.",
      "In 1920, Charles Ponzi promised 50% returns in 45 days, and now a whole type of fraud carries his name.",
    ],
    words: [
      { term: "Index fund", meaning: "A fund that copies a market list, like the S&P 500." },
      { term: "ETF", meaning: "Exchange-traded fund. It trades all day, like a stock." },
      { term: "Expense ratio", meaning: "A fund's yearly fee, as a percent." },
      { term: "Diversification", meaning: "Spreading money out so one flop can't sink you." },
      { term: "Risk tolerance", meaning: "How much up-and-down you can stomach." },
      { term: "Time horizon", meaning: "How long until you need the money." },
      { term: "401(k)", meaning: "A retirement plan through your job." },
      { term: "Employer match", meaning: "Extra 401(k) money your job adds when you contribute." },
      { term: "Roth IRA", meaning: "A retirement account taxed now, with qualified withdrawals tax-free later." },
      { term: "Custodial Roth IRA", meaning: "A Roth IRA for someone under 18, run by an adult." },
    ],
  },

  lessons: [
    /* ---------------- Lesson 1: Index funds & ETFs ---------------- */
    {
      id: "t2-u5-l1",
      title: "Index Funds & ETFs",
      description: "Buy the whole haystack instead of hunting for the needle.",
      exercises: [
        {
          type: "teach",
          id: "t2-u5-l1-e1",
          emoji: "🧺",
          title: "Meet the fund",
          body: "A **fund** pools money from tons of people and buys a big pile of investments. When you buy in, you own a tiny slice of the whole pile.\n\nSo instead of betting on one company, your money gets sprinkled across many. It's the sampler platter, not one mystery appetizer.",
          example: "You put $50 into a fund that owns 500 companies. Your $50 now owns a crumb of every single one of them.",
        },
        {
          type: "mc",
          id: "t2-u5-l1-e2",
          prompt: "You put $100 into a fund. What do you actually own?",
          choices: [
            { text: "A tiny slice of everything the fund holds", correct: true },
            {
              text: "One whole share of the fund's favorite company",
              why: "No favorites here. Your money is spread across the whole pile, not parked in one stock.",
            },
            {
              text: "A $100 IOU from the fund manager",
              why: "That's closer to a loan. A fund gives you ownership of its investments, not a promise to pay you back.",
            },
            {
              text: "Nothing until the fund makes a profit",
              why: "You own your slice from day one. Its value just moves up and down with what's inside.",
            },
          ],
          explain: "A fund is a group project that actually works. Everyone chips in, and everyone owns a piece of the whole thing.",
        },
        {
          type: "teach",
          id: "t2-u5-l1-e3",
          emoji: "📋",
          title: "Index funds copy the list",
          body: "An **index** is a list that tracks a chunk of the market. The famous one, the **S&P 500**, follows about 500 large US companies.\n\nAn **index fund** just buys what's on the list. No genius stock-picker, no crystal ball. It's copy-paste investing, and that's exactly why it's cheap.",
        },
        {
          type: "tf",
          id: "t2-u5-l1-e4",
          statement: "An index fund tries to beat the market by picking only the hottest stocks.",
          answer: false,
          explain: "False! An index fund doesn't pick favorites. It matches its index, hot stocks and boring ones alike. Matching the market is the whole plan.",
        },
        {
          type: "fill",
          id: "t2-u5-l1-e5",
          prompt: "Finish the sentence.",
          sentence: "An index fund tries to ___ the market, which helps keep its fees ___.",
          answers: ["match", "low"],
          bank: ["match", "low", "beat", "high", "outsmart", "spicy"],
          explain: "Index funds follow a list instead of paying a team to hunt for winners. Less work means lower fees, and lower fees mean more money stays yours.",
        },
        {
          type: "teach",
          id: "t2-u5-l1-e6",
          emoji: "🛒",
          title: "ETFs vs. mutual funds",
          body: "Funds come in two main flavors:\n\n- **ETF** (exchange-traded fund): buy and sell it on the stock market any time it's open, just like a stock.\n- **Mutual fund**: its price gets set once a day, after the market closes.\n\nPlot twist: lots of both are index funds. The label is about how you buy it, not what's inside.",
        },
        {
          type: "match",
          id: "t2-u5-l1-e7",
          prompt: "Match each fund word to what it means.",
          pairs: [
            { left: "Fund", right: "A shared pile of investments" },
            { left: "Index fund", right: "Copies a list like the S&P 500" },
            { left: "ETF", right: "Trades all day, just like a stock" },
            { left: "Mutual fund", right: "Priced once a day after close" },
          ],
          explain: "Same basic idea, different packaging. All of them let you own lots of investments in one move.",
        },
        {
          type: "teach",
          id: "t2-u5-l1-e8",
          emoji: "🏆",
          funFact: true,
          title: "The 'folly' that won",
          body: "The first index fund for everyday investors launched in 1976. Critics laughed and nicknamed it **'Bogle's Folly,'** after its founder, John Bogle. Why would anyone settle for just matching the market?\n\nWell. Today index funds hold trillions of dollars. Turns out 'boring and cheap' was a pretty great plan.",
        },
        {
          type: "sort",
          id: "t2-u5-l1-e9",
          prompt: "One company or a whole crowd? Sort each investment.",
          buckets: ["One company", "Many companies"],
          items: [
            { text: "Snack Attack Inc. stock", bucket: 0 },
            { text: "An S&P 500 index fund", bucket: 1 },
            { text: "A total stock market ETF", bucket: 1 },
            { text: "Llama Rides Co. stock", bucket: 0 },
            { text: "A worldwide stock index fund", bucket: 1 },
            { text: "Rocket Tacos Inc. stock", bucket: 0 },
          ],
          explain: "A single stock rides on one company. A fund spreads your money across hundreds or thousands, so a bad day for Llama Rides Co. isn't a bad day for you.",
        },
        {
          type: "mc",
          id: "t2-u5-l1-e10",
          prompt: "Why do index funds usually charge lower fees than funds run by stock-pickers?",
          choices: [
            { text: "They follow a list instead of paying experts to pick", correct: true },
            {
              text: "The government pays their fees for you",
              why: "Sadly, no. Uncle Sam isn't covering your fund fees. They're low because the fund just copies an index.",
            },
            {
              text: "They only buy stocks with cheap prices",
              why: "A stock's price has nothing to do with the fund's fee. An S&P 500 fund owns pricey stocks too.",
            },
            {
              text: "They're secretly a charity",
              why: "Ha, no. They're businesses. They just have lower costs, since nobody's paid to research and pick stocks.",
            },
          ],
          explain: "Picking stocks takes researchers and big salaries, and investors pay for all of it in fees. Index funds skip that, so more of the return stays with you.",
        },
        {
          type: "tf",
          id: "t2-u5-l1-e11",
          statement: "Over long periods, most fund managers who try to beat the market end up doing worse than it after fees.",
          answer: true,
          explain: "True. Beating the market year after year is really hard, even for pros. Add fees on top, and most fall behind a plain index fund over the long run.",
        },
        {
          type: "scenario",
          id: "t2-u5-l1-e12",
          emoji: "🧃",
          setup: "You're 16 and saved $200 from your juice bar job. Your parent helps you open a custodial investing account, and this money is for the long haul. A friend swears his cousin's favorite stock 'can't lose.'",
          question: "What's your move?",
          choices: [
            {
              text: "Put all $200 into the cousin's 'can't lose' stock",
              outcome: "It drops 40% in a month. Turns out 'can't lose' was just the cousin's wishful thinking, not a fact.",
            },
            {
              text: "Buy a broad index fund that owns hundreds of companies",
              best: true,
              outcome: "Your $200 now owns a sliver of hundreds of companies, so one flop can't sink you. Boring? Yes. Smart? Also yes.",
            },
            {
              text: "Split it between three stocks from random videos",
              outcome: "Three beats one, but random videos aren't research. One tanks and you're down big on a hunch.",
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 2: Diversification, risk & crashes ---------------- */
    {
      id: "t2-u5-l2",
      title: "Riding the Roller Coaster",
      description: "Crashes happen. Panic is optional.",
      exercises: [
        {
          type: "teach",
          id: "t2-u5-l2-e1",
          emoji: "🏴‍☠️",
          title: "Don't bury all the gold",
          body: "**Diversification** means spreading your money across lots of different investments, so one flop can't sink you. Mix up companies, industries, even countries.\n\nPicture a pirate who buried all his treasure on one tiny island. One volcano later, he's just a guy with a very sad map.",
          example: "Own one company and it drops 50%? Half your money, gone. Own 500 companies and one drops 50%? You might not even notice.",
        },
        {
          type: "mc",
          id: "t2-u5-l2-e2",
          prompt: "Which of these is the MOST diversified?",
          choices: [
            { text: "A fund holding thousands of companies worldwide", correct: true },
            {
              text: "Ten shares of one sneaker company",
              why: "Ten shares is still one company. If those sneakers flop, so does all your money.",
            },
            {
              text: "Three different social media stocks",
              why: "Three beats one, but they're all in the same industry. Bad news for social media can sink all three together.",
            },
            {
              text: "Everything in your favorite game studio",
              why: "Loving a company doesn't make it safe. One delayed game and your whole account feels it.",
            },
          ],
          explain: "Real diversification means lots of companies in lots of industries and places. A big, broad fund does that in one move.",
        },
        {
          type: "teach",
          id: "t2-u5-l2-e3",
          emoji: "🎢",
          title: "How much wobble can you take?",
          body: "**Risk tolerance** is how much up-and-down you can handle without panicking. It's part stomach, part timing.\n\nThe timing piece is your **time horizon**: when you'll need the money. Need it next year? Keep it safe in savings. Need it in 40 years? You've got time to ride out the dips.",
        },
        {
          type: "sort",
          id: "t2-u5-l2-e4",
          prompt: "Where should this money live?",
          buckets: ["Savings", "Investing"],
          items: [
            { text: "Prom money for next month", bucket: 0 },
            { text: "Retirement in 45 years", bucket: 1 },
            { text: "Emergency fund", bucket: 0 },
            { text: "Untouched for 20+ years", bucket: 1 },
            { text: "Next semester's textbooks", bucket: 0 },
            { text: "Money for age-60 you", bucket: 1 },
          ],
          explain: "Short-term money has to be there when you need it, so it lives in savings. Long-term money can handle the market's mood swings, because it has years to recover.",
        },
        {
          type: "tf",
          id: "t2-u5-l2-e5",
          statement: "If you'll need some cash in six months, the stock market is a great place to park it.",
          answer: false,
          explain: "False. Stocks can drop a lot in six months, and you might have to sell at a loss right when you need the cash. Short-term money belongs in savings.",
        },
        {
          type: "teach",
          id: "t2-u5-l2-e6",
          emoji: "🐻",
          title: "Crashes are part of the ride",
          body: "Sometimes the market drops hard. When prices fall 20% or more from a peak, it's called a **bear market**.\n\nScary? Yep. But a drop is only a loss on paper until you sell. People who **panic-sell** lock in the loss, then often miss the bounce back. Long-term investors mostly just hold on. And breathe.",
        },
        {
          type: "number",
          id: "t2-u5-l2-e7",
          prompt: "You invested $1,000. A bear market knocks it down 20%. What's it worth now?",
          answer: 800,
          prefix: "$",
          explain: "20% of $1,000 is $200, so you're at $800. Ouch, but it only becomes a real loss if you sell.",
        },
        {
          type: "number",
          id: "t2-u5-l2-e8",
          prompt: "Now it's $800. What percent gain does it need to climb back to $1,000?",
          answer: 25,
          suffix: "%",
          explain: "It needs to gain $200, and $200 is 25% of $800. Drops sting more than they look, because the comeback has to be bigger than the fall.",
        },
        {
          type: "teach",
          id: "t2-u5-l2-e9",
          emoji: "🐂",
          funFact: true,
          title: "Why bulls and bears?",
          body: "Rising markets are **bull markets** and falling ones are **bear markets**. Nobody knows for sure where the names came from.\n\nThe favorite theory: a bull attacks by thrusting its horns up, and a bear swipes its paws down. Either way, Wall Street is basically a zoo with spreadsheets.",
        },
        {
          type: "tf",
          id: "t2-u5-l2-e10",
          statement: "The US stock market has bounced back from every past crash, so it's guaranteed to bounce back from the next one.",
          answer: false,
          explain: "False, because of one word: guaranteed. The market has recovered from every crash so far, but some comebacks took years, and the past never promises the future.",
        },
        {
          type: "fill",
          id: "t2-u5-l2-e11",
          prompt: "Pick the right word.",
          sentence: "Your time ___ is how long until you'll need the money.",
          answers: ["horizon"],
          bank: ["horizon", "machine", "zone", "out"],
          explain: "Your time horizon calls a lot of the shots. Long horizon? You can handle bumps. Short horizon? Keep that money safe and steady.",
        },
        {
          type: "scenario",
          id: "t2-u5-l2-e12",
          emoji: "😬",
          setup: "You've been putting paycheck money into a broad index fund for retirement. Then the market tanks and your $1,500 drops to $1,050. Your group chat is panicking. You won't need this money for decades.",
          question: "What do you do?",
          choices: [
            {
              text: "Sell everything before it drops more",
              outcome: "You lock in a $450 loss. Then the market recovers without you, and you watch from the sidelines.",
            },
            {
              text: "Keep holding and keep investing as planned",
              best: true,
              outcome: "You ride it out. It takes a while, but your fund climbs back, and the shares you bought on sale grow too.",
            },
            {
              text: "Dump it all into a meme stock to win it back fast",
              outcome: "You swapped a dip for a hype rocket. It fizzles, and now you're down even more.",
            },
            {
              text: "Check the app 40 times a day",
              outcome: "The number doesn't care how often you look. You're stressed, the fund is the same, and your battery is crying.",
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 3: Retirement accounts ---------------- */
    {
      id: "t2-u5-l3",
      title: "Retirement Accounts (Already?)",
      description: "Future you is rich in time. Send them a gift.",
      exercises: [
        {
          type: "teach",
          id: "t2-u5-l3-e1",
          emoji: "👵",
          title: "Why think about retirement now?",
          body: "Retirement feels a million years away. That's the superpower. Money invested as a teen gets decades to compound.\n\n**Retirement accounts** come with tax perks that help your money grow. The catch: they're built for the long haul, so pulling money out early can mean taxes and penalties.",
          example: "If money grows about 8% a year, it doubles roughly every 9 years (Rule of 72). From 18 to 63, that's about five doublings: $1,000 could become about $32,000.",
        },
        {
          type: "tf",
          id: "t2-u5-l3-e2",
          statement: "Retirement is decades away, so it makes zero sense to think about it as a teen.",
          answer: false,
          explain: "False! Decades away is the whole advantage, because every year is another year of growth. No money to invest yet? Totally fine. Knowing how it works is step one.",
        },
        {
          type: "teach",
          id: "t2-u5-l3-e3",
          emoji: "🏢",
          title: "The 401(k) and its sidekick",
          body: "A **401(k)** is a retirement plan you get through a job. Money comes straight out of your paycheck and gets invested, often before income tax (you pay that tax later, when you take it out).\n\nThe star of the show is the **employer match**. When you contribute, your company adds extra money on top. It's basically a bonus for saving.",
        },
        {
          type: "number",
          id: "t2-u5-l3-e4",
          prompt: "You earn $20,000 a year. Your job matches 100% of what you put in, up to 5% of your pay. You put in 5%. How much does your job add?",
          answer: 1000,
          prefix: "$",
          explain: "5% of $20,000 is $1,000. You put in $1,000, and your job matches it dollar for dollar. That's $2,000 headed to future you.",
        },
        {
          type: "mc",
          id: "t2-u5-l3-e5",
          prompt: "Your job offers a 401(k) match, but you never sign up. What happens to the match?",
          choices: [
            { text: "You miss out on it completely", correct: true },
            {
              text: "It's saved for you until you join",
              why: "Matches don't pile up waiting for you. They only show up when you contribute.",
            },
            {
              text: "You get it as a cash bonus instead",
              why: "If only. The match is tied to your contributions. No contributions, no match, no bonus.",
            },
            {
              text: "Your coworkers split it",
              why: "Ha, that'd be a wild office. The money just never gets added for anyone.",
            },
          ],
          explain: "An employer match only happens when you put money in. Skipping it means leaving part of your total pay on the table.",
        },
        {
          type: "teach",
          id: "t2-u5-l3-e6",
          emoji: "🌱",
          title: "The Roth IRA",
          body: "A **Roth IRA** is a retirement account you open on your own, not through a job. You put in money you've already paid tax on. It grows, and qualified withdrawals in retirement are **tax-free**.\n\nThe rule: you need **earned income**, like a paycheck or gig money. You can put in up to what you earned or the yearly IRS limit, whichever is lower.",
        },
        {
          type: "sort",
          id: "t2-u5-l3-e7",
          prompt: "Does it count as earned income for a Roth IRA?",
          buckets: ["Earned income", "Not earned"],
          items: [
            { text: "Smoothie shop paycheck", bucket: 0 },
            { text: "Babysitting money", bucket: 0 },
            { text: "Tips from waiting tables", bucket: 0 },
            { text: "Lawn-mowing gig cash", bucket: 0 },
            { text: "Birthday cash from Grandma", bucket: 1 },
            { text: "Interest from savings", bucket: 1 },
            { text: "Money found in the couch", bucket: 1 },
          ],
          explain: "Earned income is money you get paid for working: jobs, tips, and gigs like babysitting. Gifts, interest, and couch treasure don't count, no matter how hard you searched.",
        },
        {
          type: "number",
          id: "t2-u5-l3-e8",
          prompt: "You earned $3,000 at a summer job this year, and the IRS limit is higher than that. What's the most you can put in a Roth IRA this year?",
          answer: 3000,
          prefix: "$",
          explain: "Your cap is whichever is lower: what you earned or the IRS limit. You earned $3,000, so $3,000 is your max.",
        },
        {
          type: "teach",
          id: "t2-u5-l3-e9",
          emoji: "🤝",
          title: "Under 18? Bring an adult",
          body: "Most investing accounts won't let you sign up solo before 18. Enter the **custodial Roth IRA**: an adult, like a parent, opens and manages it for you.\n\nThe money is yours, and you take over the account once you're an adult under your state's rules. You still need your own earned income, though. No earned income, no Roth.",
        },
        {
          type: "fill",
          id: "t2-u5-l3-e10",
          prompt: "Fill in both blanks.",
          sentence: "A ___ Roth IRA lets a teen invest with an adult's help, as long as the teen has ___ income.",
          answers: ["custodial", "earned"],
          bank: ["custodial", "earned", "secret", "birthday", "gifted", "imaginary"],
          explain: "Custodial means an adult runs it for you until you're grown. Earned means you worked for it. Birthday money doesn't count, sadly.",
        },
        {
          type: "match",
          id: "t2-u5-l3-e11",
          prompt: "Match each retirement word to its meaning.",
          pairs: [
            { left: "401(k)", right: "Retirement plan through your job" },
            { left: "Employer match", right: "Extra money your job adds" },
            { left: "Roth IRA", right: "Taxed now, tax-free in retirement" },
            { left: "Earned income", right: "Money you get paid to work" },
            { left: "Custodian", right: "Adult who manages your account" },
          ],
          explain: "These five words cover most of what you need to get started. Future you is already proud.",
        },
        {
          type: "scenario",
          id: "t2-u5-l3-e12",
          emoji: "🍿",
          setup: "You're 17 and earned $4,000 working at a movie theater this year. Your parent offers to help you open a custodial Roth IRA. You'd also like to keep some cash for fun.",
          question: "What's the smart play?",
          choices: [
            {
              text: "Skip it. Retirement is for old people.",
              outcome: "Future you sighs loudly from a beach chair. You just skipped a year of money that could've grown for decades.",
            },
            {
              text: "Put part of your pay in and keep some for fun",
              best: true,
              outcome: "Nice balance. Part of your pay starts growing for decades, and you still have popcorn money. Win-win.",
            },
            {
              text: "Have your parent put in $10,000 'for you'",
              outcome: "Not allowed. Your contributions can't top what you earned, so $4,000 is the most for this year.",
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 4: Hype vs. reality ---------------- */
    {
      id: "t2-u5-l4",
      title: "Hype vs. Reality",
      description: "Spot the hype before it spots your wallet.",
      exercises: [
        {
          type: "teach",
          id: "t2-u5-l4-e1",
          emoji: "📣",
          title: "The hype machine",
          body: "Every so often, something gets massively **hyped**: a coin, a stock, a 'secret' trading trick. Your feed fills with screenshots of people who got rich.\n\nWhat you don't see? Everyone who bought late and lost. That 'everyone's getting rich but me' feeling is **FOMO** (fear of missing out). FOMO is a terrible financial advisor.",
        },
        {
          type: "mc",
          id: "t2-u5-l4-e2",
          prompt: "Your feed is full of 'I made $50K in a week!' posts. Why are those misleading?",
          choices: [
            { text: "You mostly see winners. People who lost rarely post.", correct: true },
            {
              text: "They prove it's easy money for everyone",
              why: "A few big wins don't mean the odds are good. If it were easy for everyone, nobody would need to brag.",
            },
            {
              text: "They prove the price will keep going up",
              why: "Past gains don't promise future ones. Lots of hyped stuff crashes right after the screenshots.",
            },
            {
              text: "Every single one of them is fake",
              why: "Some are real, which is what makes them tricky. Real but rare wins still don't mean you'll get one.",
            },
          ],
          explain: "This is called survivorship bias: you only hear from the people who won. The ones who lost are just as real, just way quieter.",
        },
        {
          type: "teach",
          id: "t2-u5-l4-e3",
          emoji: "🚀",
          title: "Crypto and meme stocks",
          body: "**Crypto** is digital money that runs on a computer network instead of a government or bank. Prices can soar or crash by huge amounts, sometimes in days, and it isn't FDIC insured.\n\n**Meme stocks** are stocks that rocket up because of online hype, not because the company got better. Both are **speculation**: very risky bets on price moves, not steady long-term plans.",
        },
        {
          type: "tf",
          id: "t2-u5-l4-e4",
          statement: "Crypto you hold on an app is protected by FDIC insurance, just like money in a bank account.",
          answer: false,
          explain: "False. FDIC insurance covers bank deposits, not crypto. If the price crashes or the platform goes under, there's no FDIC safety net.",
        },
        {
          type: "teach",
          id: "t2-u5-l4-e5",
          emoji: "🕳️",
          funFact: true,
          title: "The original too-good-to-be-true",
          body: "In 1920, Charles Ponzi promised investors **50% returns in 45 days**. He paid early investors with money from newer investors, not real profits. Once new money slowed down, the whole thing collapsed.\n\nNow any scam that works this way is called a **Ponzi scheme**. Red flags: guaranteed huge returns, pressure to hurry, and 'bring your friends.'",
        },
        {
          type: "sort",
          id: "t2-u5-l4-e6",
          prompt: "Red flag or seems legit? Sort these investing pitches.",
          buckets: ["Red flag", "Seems legit"],
          items: [
            { text: "Guaranteed 50% returns!", bucket: 0 },
            { text: "Act now, 2 hours left!", bucket: 0 },
            { text: "Recruit friends for bonuses", bucket: 0 },
            { text: "Influencer's secret coin", bucket: 0 },
            { text: "Returns vary year to year", bucket: 1 },
            { text: "Low-fee index fund", bucket: 1 },
            { text: "Past returns aren't guaranteed", bucket: 1 },
          ],
          explain: "Honest investing sounds a little boring: risk, fees, no promises. Scams sound thrilling: guarantees, countdown clocks, and 'tell your friends.' Boring wins.",
        },
        {
          type: "fill",
          id: "t2-u5-l4-e7",
          prompt: "Finish the warning.",
          sentence: "Promises of ___ returns with ___ risk are a classic red flag.",
          answers: ["huge", "zero"],
          bank: ["huge", "zero", "slow", "some", "boring"],
          explain: "Real investments with big possible rewards come with real risk. When someone promises huge returns and zero risk, they're selling a story, not an investment.",
        },
        {
          type: "teach",
          id: "t2-u5-l4-e8",
          emoji: "🐜",
          title: "Fees: the tiny money munchers",
          body: "Every fund charges a yearly fee called the **expense ratio**, shown as a percent of your money. 1% sounds tiny. But it comes out every year, good year or bad, and shrinks the pile that's compounding.\n\nMany broad index funds charge just a small fraction of 1%. Over decades, that gap can add up to thousands of dollars.",
        },
        {
          type: "number",
          id: "t2-u5-l4-e9",
          prompt: "You have $10,000 in a fund with a 1% expense ratio. How much do you pay in fees this year?",
          answer: 100,
          prefix: "$",
          explain: "1% of $10,000 is $100. Every year. A fund charging 0.1% would cost just $10. Same money, way less munching.",
        },
        {
          type: "mc",
          id: "t2-u5-l4-e10",
          prompt: "Two funds hold the exact same stocks. Fund A charges 0.05% a year. Fund B charges 1%. Which likely leaves you with more money?",
          choices: [
            { text: "Fund A, the cheaper one", correct: true },
            {
              text: "Fund B, because pricier means better",
              why: "Not when the stocks inside are identical. The extra fee just comes out of your returns.",
            },
            {
              text: "They'll end up exactly the same",
              why: "Same stocks, different fees. Fund B skims more off every year, so it falls behind.",
            },
            {
              text: "Whichever one has the cooler logo",
              why: "Logos earn exactly 0%. Check the fee instead.",
            },
          ],
          explain: "With identical investments, the lower fee wins. Fees are one of the few things in investing you actually control.",
        },
        {
          type: "match",
          id: "t2-u5-l4-e11",
          prompt: "Match each word to its meaning.",
          pairs: [
            { left: "FOMO", right: "Fear of missing out" },
            { left: "Meme stock", right: "Stock pumped up by online hype" },
            { left: "Ponzi scheme", right: "Pays old investors with new money" },
            { left: "Expense ratio", right: "A fund's yearly fee" },
            { left: "Speculation", right: "Risky bet on price moves" },
          ],
          explain: "Know these words and you can smell hype from a mile away.",
        },
        {
          type: "scenario",
          id: "t2-u5-l4-e12",
          emoji: "📱",
          setup: "Your group chat is buzzing: 'Put $300 in this new coin. It's guaranteed to 10x by Friday! You get a bonus for every friend you bring in.' You have $300 saved toward a used bike.",
          question: "What do you do?",
          choices: [
            {
              text: "Go all in before Friday",
              outcome: "By Friday the coin is down 90%, and the guy who started the hype has gone very quiet. RIP, bike fund.",
            },
            {
              text: "Ask for screenshots of people's profits first",
              outcome: "You get a dozen screenshots. They're easy to fake, and they still don't explain the 'bring your friends' part.",
            },
            {
              text: "Pass. Guarantees plus recruiting bonuses are red flags.",
              best: true,
              outcome: "The coin fizzles by next week. Your $300 is safe, and you're cruising on that bike soon.",
            },
          ],
        },
      ],
    },
  ],

  quiz: {
    passPercent: 70,
    exercises: [
      {
        type: "mc",
        id: "t2-u5-q-e1",
        prompt: "What does an S&P 500 index fund do?",
        choices: [
          { text: "Owns the companies in the S&P 500 to match it", correct: true },
          {
            text: "Picks the 500 hottest stocks each week",
            why: "No weekly picking. It just follows the index, which tracks about 500 large US companies.",
          },
          {
            text: "Guarantees a 10% return every year",
            why: "Nothing guarantees that. The S&P 500 has averaged roughly 10% a year long-term, with big drops along the way.",
          },
          {
            text: "Lends money to 500 companies for interest",
            why: "That sounds like bonds. A stock index fund owns slices of companies, not loans to them.",
          },
        ],
        explain: "An index fund is copy-paste investing: own what's on the list, match the market, keep fees low.",
      },
      {
        type: "tf",
        id: "t2-u5-q-e2",
        statement: "An ETF can be bought and sold throughout the day while the market is open, just like a stock.",
        answer: true,
        explain: "True. That's what 'exchange-traded' means. Mutual funds, on the other hand, get priced once a day after the market closes.",
      },
      {
        type: "number",
        id: "t2-u5-q-e3",
        prompt: "Your $2,000 investment drops 25% in a bear market. What's it worth now?",
        answer: 1500,
        prefix: "$",
        explain: "25% of $2,000 is $500, so you're at $1,500. Painful, but it's only locked in if you sell.",
      },
      {
        type: "mc",
        id: "t2-u5-q-e4",
        prompt: "Which money belongs in savings instead of the stock market?",
        choices: [
          { text: "Cash for a car you're buying in 6 months", correct: true },
          {
            text: "Retirement money for 45 years from now",
            why: "That money has decades to recover from drops, which makes it a good fit for investing.",
          },
          {
            text: "Money you won't touch for decades",
            why: "A long time horizon means you can ride out the dips. Investing fits here.",
          },
          {
            text: "Money for your future yacht in 2070",
            why: "Ha, 2070 is a long way off. That's long-term money, so investing works for it.",
          },
        ],
        explain: "If you'll need it soon, keep it safe. Stocks can drop right when you need to sell.",
      },
      {
        type: "tf",
        id: "t2-u5-q-e5",
        statement: "Diversifying means buying lots of shares of the one company you trust most.",
        answer: false,
        explain: "False. Lots of shares of one company is still one company. Diversifying means spreading money across many companies and industries.",
      },
      {
        type: "number",
        id: "t2-u5-q-e6",
        prompt: "You earn $30,000 a year. Your job matches 50% of what you put in, up to 6% of pay. You put in $1,800. How much does your job add?",
        answer: 900,
        prefix: "$",
        explain: "$1,800 is exactly 6% of your pay, so all of it gets matched at 50%. Half of $1,800 is $900 of extra money, just for saving.",
      },
      {
        type: "mc",
        id: "t2-u5-q-e7",
        prompt: "What makes a Roth IRA special?",
        choices: [
          { text: "Qualified withdrawals in retirement are tax-free", correct: true },
          {
            text: "Your employer has to match it",
            why: "That's a 401(k) thing. A Roth IRA is an account you open yourself, so there's no employer match.",
          },
          {
            text: "You can contribute without any earned income",
            why: "Nope, you need earned income, like a paycheck or gig money, to contribute.",
          },
          {
            text: "It can never lose money",
            why: "The investments inside can still go up and down. The Roth part is about taxes, not safety.",
          },
        ],
        explain: "You pay tax on the money now, then it grows and comes out tax-free in retirement. For young earners, that's a sweet deal.",
      },
      {
        type: "fill",
        id: "t2-u5-q-e8",
        prompt: "Finish the sentence.",
        sentence: "Taking money out of a 401(k) way before retirement can mean taxes plus a ___.",
        answers: ["penalty"],
        bank: ["penalty", "high five", "refund", "parade"],
        explain: "Retirement accounts reward patience. Before about age 59½, early withdrawals usually mean income tax plus a 10% penalty, with some exceptions.",
      },
      {
        type: "match",
        id: "t2-u5-q-e9",
        prompt: "Match each word to its meaning.",
        pairs: [
          { left: "ETF", right: "Fund that trades like a stock" },
          { left: "Bear market", right: "Prices down 20%+ from a peak" },
          { left: "Employer match", right: "Extra 401(k) money from your job" },
          { left: "Expense ratio", right: "Yearly fee for owning a fund" },
          { left: "FOMO", right: "Panic that everyone's getting rich but you" },
        ],
        explain: "One word from every lesson. If you nailed these, you're officially fluent in investing.",
      },
      {
        type: "scenario",
        id: "t2-u5-q-e10",
        emoji: "💻",
        setup: "An influencer swears a meme stock is 'going to the moon' this week. You have $400 saved for a used laptop you need for school next month.",
        question: "What's the move?",
        choices: [
          {
            text: "Put the laptop money in. To the moon!",
            outcome: "The stock rockets... then crashes back to Earth. Now you have $150 and no laptop.",
          },
          {
            text: "Keep the laptop money in savings and skip the hype",
            best: true,
            outcome: "Next month you buy the laptop. The meme stock? Down 60%. Boring wins again.",
          },
          {
            text: "Borrow from your sibling to buy even more",
            outcome: "Now you're down money AND you owe your sibling. Family dinners just got awkward.",
          },
        ],
      },
    ],
  },
}

export default unit
