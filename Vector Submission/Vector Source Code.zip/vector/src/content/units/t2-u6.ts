import type { Unit } from '../types'

const unit: Unit = {
  id: 't2-u6',
  tier: 2,
  order: 6,
  title: 'College & Big Choices',
  tagline: "Huge price tags, tiny print, and one very free form.",
  color: 'teal',
  emoji: '🎓',

  guidebook: {
    intro:
      "College, trade school, and a first apartment all cost a lot. Here's where the free money hides, and why the security deposit is not a tip.",
    keyIdeas: [
      {
        title: "Free money first",
        body: "Grants, scholarships, and work-study come before any loan. Grants and scholarships don't need to be paid back.",
      },
      {
        title: "File the FAFSA every year",
        body: "The FAFSA at studentaid.gov is free and unlocks federal, state, and college aid. There's no income limit, so file it anyway.",
      },
      {
        title: "Federal loans before private",
        body: "Federal loans have fixed rates and more protections. Subsidized ones don't build interest while you're in school at least half-time.",
      },
      {
        title: "Judge by net price and payoff",
        body: "Net price is the cost after grants and scholarships. Weigh it against what the path will likely pay, whether that's college, trade school, or an apprenticeship.",
      },
      {
        title: "Moving out costs more than rent",
        body: "Budget for first month's rent, a security deposit, fees, and utilities. A common guideline keeps rent at 30% of your gross income or less.",
      },
    ],
    funFacts: [
      "The first F in FAFSA stands for Free, so never pay anyone to file it.",
      "The Pell Grant is named after Claiborne Pell, a Rhode Island senator who pushed for college aid.",
      "One long-running contest has handed out scholarships for prom outfits made of duct tape.",
      "\"Tuition\" comes from a Latin word about looking after someone, and it's related to \"tutor.\"",
      "The \"board\" in \"room and board\" is an old word for a dining table, so it means a bed plus meals.",
      "Many states cap security deposits, set a deadline to return them, or both.",
    ],
    words: [
      { term: "FAFSA", meaning: "The free federal form for college aid" },
      { term: "Grant", meaning: "School money you usually don't repay, often need-based" },
      { term: "Scholarship", meaning: "Free school money, often for grades, talent, or need" },
      { term: "Work-study", meaning: "A part-time job that helps pay for school" },
      { term: "Subsidized loan", meaning: "A federal loan where the government covers interest during school" },
      { term: "Unsubsidized loan", meaning: "A federal loan that builds interest from day one" },
      { term: "Net price", meaning: "College cost after grants and scholarships" },
      { term: "Security deposit", meaning: "Refundable money a landlord holds against damage" },
      { term: "Lease", meaning: "A contract to rent a place for a set time" },
    ],
  },

  lessons: [
    /* ---------------- Lesson 1: Paying for college ---------------- */
    {
      id: 't2-u6-l1',
      title: 'Free Money First',
      description: 'FAFSA, grants, scholarships, and work-study.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u6-l1-e1',
          emoji: '🎓',
          title: 'Four ways to pay for school',
          body: "College money comes in a few flavors:\n\n- **Grants** and **scholarships**: free money you usually don't pay back\n- **Work-study**: a part-time job that helps cover costs\n- **Loans**: borrowed money you pay back, plus interest\n\nThe move: scoop up all the free stuff before you borrow anything.",
          example: "Your school costs $20,000 a year. A $6,000 grant and a $2,000 scholarship mean you only have to figure out $12,000. That's $8,000 you never pay back.",
        },
        {
          type: 'sort',
          id: 't2-u6-l1-e2',
          prompt: 'Free money or pay it back? Sort them.',
          buckets: ['Free money', 'Pay it back'],
          items: [
            { text: 'Federal Pell Grant', bucket: 0 },
            { text: 'Local club scholarship', bucket: 0 },
            { text: 'State grant', bucket: 0 },
            { text: 'Merit scholarship', bucket: 0 },
            { text: 'Federal student loan', bucket: 1 },
            { text: 'Private bank loan', bucket: 1 },
          ],
          explain:
            'Grants and scholarships are gifts. Loans are borrowed, so they come back around with interest. Same word "aid" on the paperwork, very different future.',
        },
        {
          type: 'mc',
          id: 't2-u6-l1-e3',
          prompt: 'Which type of aid is basically a job?',
          choices: [
            { text: 'Work-study', correct: true },
            { text: 'Pell Grant', why: 'Grants are free money for students with financial need. No shifts, no name tag.' },
            { text: 'Scholarship', why: "Scholarships reward things like grades, talents, or need. You already earned it, no clocking in." },
            { text: 'Unsubsidized loan', why: "That's borrowed money you'll repay. A job pays you; a loan bills you later." },
          ],
          explain:
            'Work-study gives students with financial need a part-time job, often on campus. You get paid as you work, like any other paycheck.',
        },
        {
          type: 'teach',
          id: 't2-u6-l1-e4',
          emoji: '📝',
          title: 'Meet the FAFSA',
          body: "The **FAFSA** (Free Application for Federal Student Aid) is the form that opens the door to grants, work-study, and federal loans.\n\n- It's free at studentaid.gov\n- It opens in the **fall** before the school year\n- You fill it out **every year** you want aid\n\nMost high schoolers need a parent's info on it too, so grab a grown-up and some snacks.",
        },
        {
          type: 'tf',
          id: 't2-u6-l1-e5',
          statement: 'You have to pay a fee to file the FAFSA.',
          answer: false,
          explain:
            'False! The first F literally stands for Free. If a website asks for money to file it, close the tab and head to studentaid.gov.',
        },
        {
          type: 'fill',
          id: 't2-u6-l1-e6',
          prompt: 'Fill in the FAFSA facts.',
          sentence: 'The FAFSA is ___ to file, and it opens in the ___ before the school year.',
          answers: ['free', 'fall'],
          bank: ['free', 'fall', '$50', 'spring', '$100', 'summer'],
          explain:
            'Free and fall. File early, because some state and college aid is handed out until the money runs out.',
        },
        {
          type: 'mc',
          id: 't2-u6-l1-e7',
          prompt: 'Who actually uses the info from your FAFSA?',
          choices: [
            { text: 'The federal government, many states, and lots of colleges', correct: true },
            { text: 'Only the one college you like most', why: 'You can send it to several schools at once. Your dream school is not the only one reading.' },
            { text: 'The IRS, to check your taxes', why: "Tempting, since the form asks about money, but it's for student aid, not tax season." },
            { text: "Nobody, it's a practice form", why: 'Very real form, very real money. Skipping it can mean leaving free cash on the table.' },
          ],
          explain:
            'One form, lots of doors. The federal government, many states, and lots of colleges use your FAFSA to decide what aid to offer you.',
        },
        {
          type: 'teach',
          id: 't2-u6-l1-e8',
          emoji: '🏆',
          title: 'Scholarships: the side quest',
          body: "**Scholarships** come from colleges, companies, clubs, and community groups. Some are for grades, some for talents, some for need, and some for oddly specific stuff.\n\nLocal ones often have fewer applicants, so your odds can be way better.\n\nOne hard rule: real scholarships don't make you **pay** to get paid.",
          example: "A $500 scholarship from a local club might take one essay. If it takes you 3 hours, that's like earning about $167 an hour.",
        },
        {
          type: 'match',
          id: 't2-u6-l1-e9',
          prompt: 'Match each kind of aid to what it means.',
          pairs: [
            { left: 'Grant', right: 'Free money, often based on need' },
            { left: 'Scholarship', right: 'Free money for grades, talents, or more' },
            { left: 'Work-study', right: 'A part-time job to help pay' },
            { left: 'Loan', right: 'Borrowed money you repay with interest' },
          ],
          explain:
            'Grants and scholarships are gifts, work-study is earned, and loans are borrowed. Only one of these sends you a bill later.',
        },
        {
          type: 'tf',
          id: 't2-u6-l1-e10',
          statement: 'A real scholarship might ask you to pay a $99 "processing fee" before you get the money.',
          answer: false,
          explain:
            "False. Paying money to get money is a classic scam move. Legit scholarships don't charge you to apply or to collect, and the FTC warns about this exact trick.",
        },
        {
          type: 'number',
          id: 't2-u6-l1-e11',
          prompt: 'Your work-study job pays $12 an hour, and you work 10 hours a week. How much do you earn each week before taxes?',
          answer: 120,
          prefix: '$',
          explain:
            '$12 × 10 hours = $120 a week. Work-study pays like a normal job: you get paychecks as you work, not one big lump.',
        },
        {
          type: 'teach',
          id: 't2-u6-l1-e12',
          emoji: '🎀',
          funFact: true,
          title: 'Duct tape goes to prom',
          body: 'Some scholarships get delightfully weird. One long-running contest has handed out scholarship money for prom outfits made out of **duct tape**.\n\nAnd the federal **Pell Grant** is named after Claiborne Pell, a senator from Rhode Island who pushed for college aid.',
        },
        {
          type: 'scenario',
          id: 't2-u6-l1-e13',
          emoji: '🤷',
          setup:
            'Your friend Maya says she\'s skipping the FAFSA. "My parents make decent money, so I won\'t get anything anyway." Applications are due soon.',
          question: 'What do you tell her?',
          choices: [
            {
              text: '"Fair, the FAFSA is only for low-income families."',
              outcome: "She skips it and misses aid she might have gotten. Plot twist: there's no income limit to apply.",
            },
            {
              text: "\"File it anyway. It's free, and there's no income limit.\"",
              best: true,
              outcome: 'She files it in one evening, and her college offers her a grant she never would have seen. Free money, unlocked.',
            },
            {
              text: '"Just get a private loan instead, it\'s faster."',
              outcome: 'Faster to borrow, slower to pay back. She skipped free money and protections for a loan with fewer safety nets.',
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 2: Student loans ---------------- */
    {
      id: 't2-u6-l2',
      title: 'Student Loans 101',
      description: 'Federal vs. private, subsidized vs. unsubsidized.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u6-l2-e1',
          emoji: '🏦',
          title: 'Two kinds of lenders',
          body: 'A student loan is borrowed money you pay back with **interest** (the fee for borrowing).\n\n- **Federal loans** come from the US government through the FAFSA. Fixed rates, no credit check for most undergrad loans, and more protections.\n- **Private loans** come from banks, credit unions, or online lenders. They often need good credit or a **cosigner**, and they have fewer safety nets.',
        },
        {
          type: 'sort',
          id: 't2-u6-l2-e2',
          prompt: 'Federal or private? Sort each feature.',
          buckets: ['Federal', 'Private'],
          items: [
            { text: 'You apply through the FAFSA', bucket: 0 },
            { text: 'Fixed rate set by law', bucket: 0 },
            { text: 'Usually no credit check', bucket: 0 },
            { text: 'Rate depends on your credit', bucket: 1 },
            { text: 'Often needs a cosigner', bucket: 1 },
            { text: 'From a bank or credit union', bucket: 1 },
          ],
          explain:
            "Federal undergrad loans have a fixed rate set by law (everyone borrowing that year gets the same one), plus more protections. Private loans are priced on your credit (or your cosigner's), so the deal can swing a lot.",
        },
        {
          type: 'mc',
          id: 't2-u6-l2-e3',
          prompt: 'Why is it usually smart to use federal loans before private ones?',
          choices: [
            { text: 'More protections, and most undergrads skip the credit check', correct: true },
            { text: "Federal loans don't charge any interest", why: "They do charge interest. It's a fixed rate. With subsidized loans, the government just covers it while you're in school." },
            { text: 'Private loans are illegal for students', why: "Totally legal. They're just usually a last resort because they have fewer safety nets." },
            { text: 'Federal loans never have to be paid back', why: 'Oh, they come back. A loan is a loan, federal or not.' },
          ],
          explain:
            "Federal loans have fixed rates, don't need a credit history for most undergrads, and come with options if paying gets tough. Private loans usually can't match that.",
        },
        {
          type: 'teach',
          id: 't2-u6-l2-e4',
          emoji: '⏳',
          title: 'Subsidized vs. unsubsidized',
          body: "Two flavors of federal loans:\n\n- **Subsidized**: the government pays the interest while you're in school at least half-time. Only for undergrads with financial need.\n- **Unsubsidized**: interest starts building from **day one**, even while you're in class. Not based on need.\n\nSame amount borrowed, very different bill later.",
          example:
            "Borrow $3,000 subsidized and you owe about $3,000 when school ends. Borrow $3,000 unsubsidized and skip interest payments, and you owe $3,000 plus all the interest that piled up.",
        },
        {
          type: 'tf',
          id: 't2-u6-l2-e5',
          statement: "With an unsubsidized loan, interest builds up while you're still in school.",
          answer: true,
          explain:
            'True. Interest starts from day one. Paying some of it during school keeps the balance from growing behind your back.',
        },
        {
          type: 'match',
          id: 't2-u6-l2-e6',
          prompt: 'Match the loan words.',
          pairs: [
            { left: 'Subsidized', right: 'Government pays interest during school' },
            { left: 'Unsubsidized', right: 'Interest builds from day one' },
            { left: 'Private loan', right: 'From a lender, based on credit' },
            { left: 'Cosigner', right: "Someone who must pay if you don't" },
          ],
          explain:
            "A cosigner isn't just a reference. If you miss payments, they're on the hook, and it can hurt their credit too.",
        },
        {
          type: 'fill',
          id: 't2-u6-l2-e7',
          sentence: "With a ___ loan, the government pays the interest while you're in school at least half-time.",
          answers: ['subsidized'],
          bank: ['subsidized', 'unsubsidized', 'private', 'payday'],
          explain:
            "Subsidized means the government chips in on the interest while you're in school. Unsubsidized means it's all on you from day one.",
        },
        {
          type: 'number',
          id: 't2-u6-l2-e8',
          prompt: 'Imagine an unsubsidized loan of $4,000 at a made-up 5% interest rate. About how much interest builds up in one year?',
          answer: 200,
          prefix: '$',
          explain:
            "5% of $4,000 is $200. Four years of school with no payments? That's about $800 in interest before you even graduate.",
        },
        {
          type: 'teach',
          id: 't2-u6-l2-e9',
          emoji: '🧮',
          title: 'Borrow like a pro',
          body: '- Use free money first, then federal loans, then private loans only if you must\n- You can accept **less** than the loan amount you\'re offered\n- A popular rule of thumb: keep total loans under what you expect to earn your **first year** working\n\nFederal loans usually give you a 6-month **grace period** after you leave school before payments start.',
        },
        {
          type: 'tf',
          id: 't2-u6-l2-e10',
          statement: "If you leave school before finishing, you don't have to repay your student loans.",
          answer: false,
          explain:
            "False, unfortunately. The loan doesn't care if you got the diploma. That's why borrowing a lot and not finishing is the roughest combo.",
        },
        {
          type: 'mc',
          id: 't2-u6-l2-e11',
          prompt: 'Your aid offer includes $4,000 in loans, but you only need $2,500. What can you do?',
          choices: [
            { text: 'Accept just $2,500 of the loan', correct: true },
            { text: 'Take all $4,000 or nothing', why: 'Nope. You can accept part of a loan offer. Less borrowed means less interest.' },
            { text: 'Take $4,000 and buy a gaming PC with the extra', why: 'Fun for a week, expensive for years. That extra $1,500 racks up interest the whole time.' },
            { text: 'Turn down all aid just to be safe', why: 'If you really need $2,500, turning it all down just leaves a hole in your budget.' },
          ],
          explain:
            'Loan offers are a menu, not a mandatory combo meal. Borrow what you need, not what you\'re offered.',
        },
        {
          type: 'scenario',
          id: 't2-u6-l2-e12',
          emoji: '💸',
          setup:
            'You\'re $2,000 short for your first year after grants and scholarships. An online ad screams: "Instant private student loans! Approved in 5 minutes!" Your FAFSA is already filed.',
          question: "What's your first move?",
          choices: [
            {
              text: 'Tap the ad and borrow before the deal disappears',
              outcome: 'You lock in a rate based on your very thin credit history. Fast money, slow regret.',
            },
            {
              text: 'Ask the financial aid office about federal loan options',
              best: true,
              outcome: 'Turns out you can still accept a federal loan from your aid offer. Fixed rate, more protections, zero sketchy ads.',
            },
            {
              text: 'Put tuition on a credit card',
              outcome: 'Card rates are often above 20%. Your tuition just became the most expensive thing you have ever bought.',
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 3: Is it worth it? ---------------- */
    {
      id: 't2-u6-l3',
      title: 'Is It Worth It?',
      description: 'Sticker price, net price, and paths that pay off.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u6-l3-e1',
          emoji: '🏷️',
          title: 'Sticker price vs. net price',
          body: "A college's **cost of attendance** is the full yearly bill: tuition, fees, housing, food, books, and getting around.\n\nDon't judge by that alone. **Net price** = cost of attendance minus grants and scholarships. That's what you actually have to cover.\n\nMost colleges have a **net price calculator** on their website. Use it before you fall in love with a campus.",
        },
        {
          type: 'number',
          id: 't2-u6-l3-e2',
          prompt: "Cost of attendance: $28,000. You get a $10,000 grant and a $2,000 scholarship. What's your net price for the year?",
          answer: 16000,
          prefix: '$',
          explain:
            "$28,000 minus $12,000 in free money = $16,000. That's the number to plan around with savings, work, or loans.",
        },
        {
          type: 'tf',
          id: 't2-u6-l3-e3',
          statement: 'A college with a $60,000 sticker price always costs more than one with a $25,000 sticker price.',
          answer: false,
          explain:
            'False. Schools with big sticker prices sometimes hand out big grants, so their net price can end up lower. Compare net prices, not price tags.',
        },
        {
          type: 'teach',
          id: 't2-u6-l3-e4',
          emoji: '📈',
          title: 'The payoff part',
          body: 'On average, people with a **bachelor\'s degree** earn more and are unemployed less often than people with only a high school diploma.\n\nBut "on average" is doing a lot of work there. The payoff depends on what you study, what it costs, and if you actually **finish**.\n\nThe roughest combo: lots of debt and no degree.',
        },
        {
          type: 'mc',
          id: 't2-u6-l3-e5',
          prompt: 'Which plan is usually the riskiest money move?',
          choices: [
            { text: 'Borrowing a lot, then not finishing the degree', correct: true },
            { text: 'Starting at community college to save money', why: "That's a classic money-saving move, as long as your credits transfer." },
            { text: 'Comparing net prices before choosing a school', why: "That's the opposite of risky. That's homework that pays." },
            { text: 'Applying for scholarships every year', why: 'Zero risk, possible free money. Worst case, you get really good at essays.' },
          ],
          explain:
            'Debt without the degree means you pay the cost but miss most of the payoff. Picking a path you can actually finish matters as much as the price.',
        },
        {
          type: 'teach',
          id: 't2-u6-l3-e6',
          emoji: '🔧',
          title: "College isn't the only road",
          body: '- **Community college**: usually much cheaper, most accept anyone with a diploma or GED, and you can earn a 2-year associate degree or transfer to a 4-year school\n- **Trade school**: training for jobs like electrician, welder, or HVAC tech, often in 2 years or less\n- **Apprenticeship**: a real job where you get **paid** while you learn the skill',
        },
        {
          type: 'match',
          id: 't2-u6-l3-e7',
          prompt: "Match each path to what it's about.",
          pairs: [
            { left: 'Community college', right: 'Cheaper start, transfer or associate degree' },
            { left: 'Trade school', right: 'Hands-on training for a skilled job' },
            { left: 'Apprenticeship', right: 'Get paid while you learn' },
            { left: "Bachelor's degree", right: 'Usually about four years full-time' },
          ],
          explain:
            'No path is the "right" one for everyone. The smart move is matching the path to the career you want and the price you can handle.',
        },
        {
          type: 'number',
          id: 't2-u6-l3-e8',
          prompt: 'Imagine university tuition is $11,000 a year and community college is $4,000 a year. How much tuition do you save by doing your first 2 years at community college?',
          answer: 14000,
          prefix: '$',
          explain:
            'You save $7,000 a year, times 2 years = $14,000. Just make sure your credits will transfer first.',
        },
        {
          type: 'sort',
          id: 't2-u6-l3-e9',
          prompt: 'Is it a cost or a payoff of going to school?',
          buckets: ['Cost', 'Payoff'],
          items: [
            { text: 'Tuition and fees', bucket: 0 },
            { text: 'Textbooks and supplies', bucket: 0 },
            { text: 'Less time for paid work', bucket: 0 },
            { text: 'Higher average earnings', bucket: 1 },
            { text: 'Lower odds of unemployment', bucket: 1 },
            { text: 'Skills for a career', bucket: 1 },
          ],
          explain:
            "Time counts as a cost too. Hours in class are hours you're not earning, which is called opportunity cost. A path is worth it when the payoff beats all of it.",
        },
        {
          type: 'fill',
          id: 't2-u6-l3-e10',
          sentence: 'Before you transfer, make sure your community college ___ will count at the four-year school.',
          answers: ['credits'],
          bank: ['credits', 'selfies', 'parking tickets', 'mascot'],
          explain:
            'Credits that don\'t transfer are classes you pay for twice. Ask both schools, or look for a transfer agreement between them.',
        },
        {
          type: 'teach',
          id: 't2-u6-l3-e11',
          emoji: '📜',
          funFact: true,
          title: "Tuition's secret meaning",
          body: 'The word **tuition** comes from a Latin word about guarding or looking after someone. It\'s a cousin of the word "tutor."\n\nSo technically, tuition is the price of being looked after. Somebody tell the dining hall.',
        },
        {
          type: 'scenario',
          id: 't2-u6-l3-e12',
          emoji: '🚗',
          setup:
            'You love fixing cars and kind of dread sitting through lectures. Your friends are all applying to four-year schools, and you feel the pressure to do the same.',
          question: "What's the smartest next step?",
          choices: [
            {
              text: "Apply wherever your friends go so you don't feel left out",
              outcome: 'You might pay big money for a path you never wanted. Your friends would understand. Probably.',
            },
            {
              text: 'Compare an auto tech program or apprenticeship with other options',
              best: true,
              outcome: "You check the cost, training time, and pay for each path. Now you're choosing with real numbers instead of peer pressure.",
            },
            {
              text: 'Skip all training and hope a job finds you',
              outcome: 'Jobs rarely knock on the garage door. Skills and training are what get you hired.',
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 4: Moving out ---------------- */
    {
      id: 't2-u6-l4',
      title: 'Moving Out',
      description: 'Rent, deposits, roommates, and the bills nobody mentions.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u6-l4-e1',
          emoji: '🔑',
          title: 'Move-in money',
          body: "Getting the keys costs more than one month's rent. Usually you'll need:\n\n- **First month's rent**\n- A **security deposit** (often about one month's rent) that you can get back if you don't damage the place\n- An application fee\n\nThen add a mattress, some furniture, and roughly 400 trips to the store for a shower curtain.",
        },
        {
          type: 'number',
          id: 't2-u6-l4-e2',
          prompt: "Rent is $1,100 a month. The landlord wants first month's rent, a deposit equal to one month's rent, and a $40 application fee. What's your total move-in cost?",
          answer: 2240,
          prefix: '$',
          explain:
            "$1,100 + $1,100 + $40 = $2,240. That's before you buy a single fork. Save for move-in day, not just the rent.",
        },
        {
          type: 'tf',
          id: 't2-u6-l4-e3',
          statement: 'A security deposit is a fee you never get back.',
          answer: false,
          explain:
            'False. It\'s refundable. The landlord can keep part of it for unpaid rent or damage beyond normal wear and tear, but the rest comes back to you.',
        },
        {
          type: 'teach',
          id: 't2-u6-l4-e4',
          emoji: '🧾',
          title: 'How much rent is too much?',
          body: 'A common guideline: keep rent at about **30%** of your gross (before-tax) income or less.\n\nMany landlords look for income around **3 times** the rent, and they may run a credit check.\n\nAlso, a **lease** is a real contract. Break it early and you might owe fees or even the rest of the rent.',
        },
        {
          type: 'number',
          id: 't2-u6-l4-e5',
          prompt: "You earn $2,500 a month before taxes. Using the 30% guideline, what's the most you'd want to spend on rent?",
          answer: 750,
          prefix: '$',
          explain:
            '30% of $2,500 is $750. Go much higher and rent starts eating the money you need for food, gas, and fun.',
        },
        {
          type: 'mc',
          id: 't2-u6-l4-e6',
          prompt: "You're moving in. What's the best way to protect your security deposit?",
          choices: [
            { text: 'Take photos and video of every room on day one', correct: true },
            { text: 'Trust that the landlord remembers how it looked', why: 'Memories get fuzzy, especially a year later. Dated photos don\'t argue.' },
            { text: 'Hide the carpet stain under a rug forever', why: 'The rug moves out with you. The stain stays. So does the bill.' },
            { text: "Just skip paying the last month's rent", why: "That usually breaks the lease and can get you in real trouble. The deposit and the rent are separate things." },
          ],
          explain:
            'Do a walkthrough with photos before you unpack. If the landlord later blames you for old scratches, you\'ve got proof.',
        },
        {
          type: 'teach',
          id: 't2-u6-l4-e7',
          emoji: '💡',
          title: 'Roommates and utilities',
          body: "**Utilities** are the bills that keep a place running: electricity, water, gas, trash. Some apartments include a few in the rent, so ask. Bills can jump in summer or winter.\n\nA **roommate** can cut your costs a lot. Put the deal in writing: who pays what, when, and who takes out the trash. Good intentions are not a payment plan.",
        },
        {
          type: 'sort',
          id: 't2-u6-l4-e8',
          prompt: 'Utility or not? Sort these monthly costs.',
          buckets: ['Utility', 'Not a utility'],
          items: [
            { text: 'Electricity', bucket: 0 },
            { text: 'Water and sewer', bucket: 0 },
            { text: 'Natural gas', bucket: 0 },
            { text: 'Trash pickup', bucket: 0 },
            { text: 'Streaming subscription', bucket: 1 },
            { text: 'Groceries', bucket: 1 },
            { text: 'Concert tickets', bucket: 1 },
          ],
          explain:
            'Utilities keep the lights on and the water running. Groceries are a need and streaming is a want, but neither one is a utility.',
        },
        {
          type: 'match',
          id: 't2-u6-l4-e9',
          prompt: 'Match the apartment words.',
          pairs: [
            { left: 'Lease', right: 'The rental contract you sign' },
            { left: 'Security deposit', right: 'Refundable money held in case of damage' },
            { left: 'Utilities', right: 'Bills like power and water' },
            { left: 'Walkthrough', right: 'Inspecting the place at move-in' },
            { left: 'Roommate agreement', right: 'Written deal on who pays what' },
          ],
          explain:
            "Learn these before you sign anything. Especially the lease, since it's a legal contract with your name on it.",
        },
        {
          type: 'fill',
          id: 't2-u6-l4-e10',
          sentence: 'If you and a roommate are both on the ___, the landlord can still ask for the ___ rent if one of you bails.',
          answers: ['lease', 'full'],
          bank: ['lease', 'full', 'group chat', 'half', 'fridge'],
          explain:
            "Shared leases often make each roommate responsible for the whole rent. If your roommate vanishes, the rent doesn't. Pick roommates you trust.",
        },
        {
          type: 'teach',
          id: 't2-u6-l4-e11',
          emoji: '🍽️',
          funFact: true,
          title: 'Room and... a plank?',
          body: 'Ever heard of **room and board**? The "board" part comes from an old meaning of the word: a table, where meals were served.\n\nSo room and board just means a place to sleep plus food on the table. Colleges still use the phrase for dorms and meal plans.',
        },
        {
          type: 'scenario',
          id: 't2-u6-l4-e12',
          emoji: '🏠',
          setup:
            'You earn $2,800 a month before taxes. Option A: a solo studio for $1,250. Option B: a two-bedroom for $1,600, split evenly with your reliable friend Jordan.',
          question: 'Which plan makes the most money sense?',
          choices: [
            {
              text: 'Solo studio. Privacy is priceless, right?',
              outcome: "Privacy costs $1,250, about 45% of your income. You get your own space and a very close relationship with instant noodles.",
            },
            {
              text: 'Split the two-bedroom with a written roommate agreement',
              best: true,
              outcome: 'Your share is $800, under 30% of your income. The agreement means nobody fights over the electric bill.',
            },
            {
              text: "Split it, but skip the agreement. You're friends!",
              outcome: 'Month three: Jordan thinks utilities are "included in friendship." They are not. Awkward.',
            },
          ],
        },
      ],
    },
  ],

  quiz: {
    passPercent: 70,
    exercises: [
      {
        type: 'mc',
        id: 't2-u6-q-e1',
        prompt: 'Which of these do you NOT have to pay back?',
        choices: [
          { text: 'A federal Pell Grant', correct: true },
          { text: 'A federal unsubsidized loan', why: 'Any loan, federal or not, gets paid back with interest.' },
          { text: 'A private student loan', why: 'Private loans come back with interest, sometimes with a cosigner on the hook too.' },
          { text: 'A credit card charge for tuition', why: "That's debt, often at a high interest rate. Very much payback territory." },
        ],
        explain: 'Grants like the Pell Grant are free money. Loans and credit cards always come back around.',
      },
      {
        type: 'tf',
        id: 't2-u6-q-e2',
        statement: "If your family earns above a certain income, you're not allowed to file the FAFSA.",
        answer: false,
        explain:
          "False. There's no income limit to apply, and some aid, like unsubsidized loans, isn't based on need at all. File it anyway.",
      },
      {
        type: 'match',
        id: 't2-u6-q-e3',
        prompt: 'Match the college money words.',
        pairs: [
          { left: 'Work-study', right: 'Part-time job for school costs' },
          { left: 'Subsidized loan', right: 'Government pays interest during school' },
          { left: 'Unsubsidized loan', right: 'Interest grows from day one' },
          { left: 'Net price', right: 'Cost after grants and scholarships' },
        ],
        explain: 'Four words that can save you thousands. Not bad for one quiz question.',
      },
      {
        type: 'fill',
        id: 't2-u6-q-e4',
        sentence: 'Use free money first, then ___ loans, and save ___ loans for last.',
        answers: ['federal', 'private'],
        bank: ['federal', 'private', 'payday', 'pizza'],
        explain:
          'Grants and scholarships first, federal loans next (fixed rates, more protections), and private loans only if you still need them.',
      },
      {
        type: 'number',
        id: 't2-u6-q-e5',
        prompt: 'You borrow $6,000 in unsubsidized loans at a made-up 5% rate. About how much interest builds up in the first year?',
        answer: 300,
        prefix: '$',
        explain:
          "5% of $6,000 is $300. With an unsubsidized loan, that interest starts building while you're still in class.",
      },
      {
        type: 'mc',
        id: 't2-u6-q-e6',
        prompt: "What is a college's net price?",
        choices: [
          { text: 'Cost of attendance minus grants and scholarships', correct: true },
          { text: 'The tuition number on the homepage', why: "That's closer to the sticker price. Net price subtracts the free money you get." },
          { text: 'The price after you take out loans', why: "Loans don't lower your cost, they just delay it. You still pay them back with interest." },
          { text: 'What the college pays its professors', why: 'Interesting, but nope. Net price is about what you pay.' },
        ],
        explain:
          'Net price is what you actually have to cover with savings, work, or loans. A college\'s net price calculator can estimate it for you.',
      },
      {
        type: 'sort',
        id: 't2-u6-q-e7',
        prompt: 'One-time move-in cost or monthly bill?',
        buckets: ['One-time', 'Every month'],
        items: [
          { text: 'Security deposit', bucket: 0 },
          { text: 'Application fee', bucket: 0 },
          { text: 'Moving truck rental', bucket: 0 },
          { text: 'Rent', bucket: 1 },
          { text: 'Electric bill', bucket: 1 },
          { text: 'Water bill', bucket: 1 },
        ],
        explain:
          'Move-in costs hit all at once, then the monthly bills keep coming. Budget for both, or move-in day gets real stressful.',
      },
      {
        type: 'tf',
        id: 't2-u6-q-e8',
        statement: "On average, people with a bachelor's degree earn more than people with only a high school diploma.",
        answer: true,
        explain: "True. But it's an average. Your payoff depends on your field, your costs, and if you finish.",
      },
      {
        type: 'number',
        id: 't2-u6-q-e9',
        prompt: "You earn $3,000 a month before taxes. Using the 30% guideline, what's the most you'd want to spend on rent?",
        answer: 900,
        prefix: '$',
        explain: '30% of $3,000 is $900. Splitting a place with a roommate is one way to get under that line.',
      },
      {
        type: 'scenario',
        id: 't2-u6-q-e10',
        emoji: '📧',
        setup:
          'An email lands in your inbox: "Congrats! You\'ve been picked for a guaranteed $10,000 scholarship. Just pay a $49 processing fee to claim it." You never applied.',
        question: 'What do you do?',
        choices: [
          {
            text: 'Pay the $49. Ten grand is ten grand!',
            outcome: 'The $49 vanishes, and so does the "scholarship." Real scholarships don\'t charge you to collect.',
          },
          {
            text: 'Delete it and report it at ReportFraud.ftc.gov',
            best: true,
            outcome: 'Scam blocked. You keep your $49 and spend that energy on scholarships you can actually win.',
          },
          {
            text: 'Reply with your Social Security number to verify',
            outcome: 'Now a scammer has your identity info, and the $10,000 was never real. Never send that to a stranger.',
          },
        ],
      },
    ],
  },
}

export default unit
