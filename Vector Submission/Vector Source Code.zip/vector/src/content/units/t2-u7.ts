import type { Unit } from '../types'

const unit: Unit = {
  id: 't2-u7',
  tier: 2,
  order: 7,
  title: 'Protect Your Money',
  tagline: "Your money needs a bodyguard. You're hired.",
  color: 'orange',
  emoji: '🛡️',

  guidebook: {
    intro:
      "You know how to earn, budget, and grow money. Now let's make sure nothing, and nobody, takes it.",
    keyIdeas: [
      {
        title: "Insurance spreads out risk",
        body: "You pay a small, predictable premium so one big disaster doesn't wipe you out. The deductible is your share of a claim before insurance pays.",
      },
      {
        title: "Premiums and deductibles seesaw",
        body: "A higher deductible usually means a lower premium. Pick a deductible you could actually pay tomorrow.",
      },
      {
        title: "Freeze your credit, not your fun",
        body: "A credit freeze is free at Equifax, Experian, and TransUnion. It blocks new accounts in your name, doesn't hurt your score, and thaws whenever you need credit.",
      },
      {
        title: "Your info is basically money",
        body: "Your SSN, passwords, and 2-factor codes unlock your accounts. Share your SSN only when truly needed, and never share passwords or codes.",
      },
      {
        title: "Scams all wear the same outfit",
        body: "Rushing, secrecy, and payment by gift card, crypto, or wire are red flags. Real jobs don't charge you to work, and real prizes don't cost money to claim.",
      },
      {
        title: "Net worth = own minus owe",
        body: "It's your assets (what you own) minus your liabilities (what you owe). It's a snapshot, not a grade, and starting small or negative is normal.",
      },
    ],
    funFacts: [
      "Modern insurance got a big boost in Edward Lloyd's London coffee house in the late 1600s, where ship owners found people to insure their voyages.",
      "Before 2011, the first three digits of a Social Security number were tied to the state on the application, but now they're assigned randomly.",
      "The \"ph\" in phishing is usually traced to \"phone phreaks,\" early hackers who messed around with phone systems.",
      "IdentityTheft.gov, run by the FTC, builds you a step-by-step recovery plan if someone steals your identity.",
      "Scammers love gift cards because once you share the numbers on the back, the money is fast to drain and hard to get back.",
      "Plenty of people start adult life with a negative net worth, thanks to student or car loans.",
    ],
    words: [
      { term: "Premium", meaning: "What you pay regularly for insurance" },
      { term: "Deductible", meaning: "Your share of a claim before insurance pays" },
      { term: "Claim", meaning: "Asking your insurer to pay for a loss" },
      { term: "Liability coverage", meaning: "Pays for damage or injuries you cause others" },
      { term: "Identity theft", meaning: "Someone using your info to pretend to be you" },
      { term: "Credit freeze", meaning: "A free lock on new accounts in your name" },
      { term: "Phishing", meaning: "Fake messages fishing for your info" },
      { term: "Money mule", meaning: "Someone who moves stolen money for scammers, often unknowingly" },
      { term: "Asset", meaning: "Something you own that has value" },
      { term: "Net worth", meaning: "What you own minus what you owe" },
    ],
  },

  lessons: [
    /* ---------------- Lesson 1: Insurance basics ---------------- */
    {
      id: 't2-u7-l1',
      title: "Insurance: Your Money's Airbag",
      description: 'Premiums, deductibles, and why car, health, and renters insurance exist.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u7-l1-e1',
          emoji: '☂️',
          title: 'Insurance is a group umbrella',
          body: "**Insurance** is a deal: you pay a small, regular amount so one giant surprise cost doesn't flatten you.\n\nLots of people pay in. Only a few have a disaster in any given year. The pooled money covers them. It's like a group project where everyone chips in so nobody fails alone.",
          example: "You crash into a fence. The fence plus your car costs $6,000 to fix. No insurance? That's all on you. With insurance, you pay your share and the policy covers the rest.",
        },
        {
          type: 'mc',
          id: 't2-u7-l1-e2',
          prompt: 'Why do people buy insurance in the first place?',
          choices: [
            { text: 'To swap a giant surprise cost for small, planned payments', correct: true },
            {
              text: 'To make money every month',
              why: "Insurance isn't an investment. Most months you pay and get nothing back, and honestly, that's the good outcome.",
            },
            {
              text: 'Because it pays for literally everything',
              why: 'Every policy has limits and things it skips. It covers specific risks, not your whole life.',
            },
          ],
          explain: 'Insurance trades a small, certain cost for protection from a big, uncertain one. Boring on purpose, and boring is beautiful here.',
        },
        {
          type: 'teach',
          id: 't2-u7-l1-e3',
          emoji: '💵',
          title: 'Premium vs. deductible',
          body: "Two words run the whole show:\n\n- **Premium**: what you pay to keep coverage, like $100 a month. You pay it even when nothing happens.\n- **Deductible**: what you pay out of pocket before insurance starts paying.\n\nAsking your insurance company to pay for something is called filing a **claim**.",
          example: 'Your car repair costs $2,000 and your deductible is $500. You pay $500, insurance pays $1,500, and you drive away without crying in the parking lot.',
        },
        {
          type: 'match',
          id: 't2-u7-l1-e4',
          prompt: 'Match each insurance word to what it means.',
          pairs: [
            { left: 'Premium', right: 'Your regular payment for coverage' },
            { left: 'Deductible', right: 'Your share before insurance pays' },
            { left: 'Claim', right: 'Asking insurance to cover a loss' },
            { left: 'Policy', right: 'The contract listing what you get' },
          ],
          explain: 'The premium is basically a subscription fee. The deductible is your share when something goes wrong. The policy is the rulebook for the whole deal.',
        },
        {
          type: 'number',
          id: 't2-u7-l1-e5',
          prompt: 'Your car insurance deductible is $500. A fender bender costs $1,800 to fix. How much does insurance pay?',
          answer: 1300,
          prefix: '$',
          explain: '$1,800 minus your $500 deductible = $1,300. You cover the first $500, and insurance handles the rest.',
        },
        {
          type: 'teach',
          id: 't2-u7-l1-e6',
          emoji: '⚖️',
          title: 'The premium seesaw',
          body: "Premiums and deductibles sit on a seesaw:\n\n- **Higher deductible**: lower premium, but a bigger bill when something happens.\n- Lower deductible: higher premium, smaller surprise bill.\n\nThe trick is to never pick a deductible bigger than what you could actually pay tomorrow. That's where an emergency fund earns its keep.",
        },
        {
          type: 'tf',
          id: 't2-u7-l1-e7',
          statement: 'Choosing a higher deductible usually lowers your premium.',
          answer: true,
          explain: "True! You're agreeing to cover more yourself, so the insurance company charges you less. Just make sure you could really pay that deductible if you needed to.",
        },
        {
          type: 'teach',
          id: 't2-u7-l1-e8',
          emoji: '🚗',
          title: 'The three you meet first',
          body: "- Car: nearly every state requires **liability** insurance, which pays for damage or injuries you cause to other people.\n- Health: helps pay for doctor visits and hospital bills. If a parent has a plan, you can usually stay on it until 26.\n- Renters: covers your stuff in a rental. The landlord's policy covers the building, not your hoodie collection.",
        },
        {
          type: 'sort',
          id: 't2-u7-l1-e9',
          prompt: 'Which insurance would cover it?',
          buckets: ['Car', 'Health', 'Renters'],
          items: [
            { text: "You dent someone's car", bucket: 0 },
            { text: 'You back into a mailbox', bucket: 0 },
            { text: 'Broken arm at the ER', bucket: 1 },
            { text: 'Your yearly checkup', bucket: 1 },
            { text: 'Laptop stolen from your apartment', bucket: 2 },
            { text: 'Apartment fire ruins your hoodies', bucket: 2 },
          ],
          explain: 'Car insurance handles crashes (sorry, mailbox), health insurance handles your body, and renters insurance handles your stuff.',
        },
        {
          type: 'fill',
          id: 't2-u7-l1-e10',
          sentence: 'You pay your ___ to keep coverage, even in a quiet month. Your ___ is your share when something actually goes wrong.',
          answers: ['premium', 'deductible'],
          bank: ['premium', 'deductible', 'allowance', 'refund', 'tip'],
          explain: 'Premium = the ongoing price of being covered. Deductible = what comes out of your pocket first when you use it.',
        },
        {
          type: 'tf',
          id: 't2-u7-l1-e11',
          statement: "If your apartment catches fire, your landlord's insurance replaces all your stuff.",
          answer: false,
          explain: "False! The landlord's policy usually covers the building. Your stuff needs renters insurance, which often runs around $15 to $30 a month.",
        },
        {
          type: 'scenario',
          id: 't2-u7-l1-e12',
          emoji: '🚙',
          setup: 'You just bought your first used car and have $600 saved. Insurance quote A has a $1,000 deductible and a cheaper premium. Quote B has a $500 deductible and costs a bit more each month.',
          question: 'Which quote fits you right now?',
          choices: [
            {
              text: 'Quote A. Cheaper is cheaper!',
              outcome: 'You save a little each month. Then a fender bender leaves a $1,500 repair bill. Your share is $1,000, and you have $600. Oof.',
            },
            {
              text: 'Quote B, since I could actually pay $500',
              best: true,
              outcome: 'A bit more each month, but when something happens, you can cover your share without panicking. Very grown-up of you.',
            },
            {
              text: "Skip insurance. I'm a careful driver.",
              outcome: 'Driving without required insurance is illegal in nearly every state. Also, careful drivers still get hit by other people.',
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 2: Identity theft & credit freezes ---------------- */
    {
      id: 't2-u7-l2',
      title: 'Guard Your Identity',
      description: 'How identity theft works, how to spot it, and the free lock that stops it.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u7-l2-e1',
          emoji: '🔑',
          title: 'Your info is a key',
          body: "**Identity theft** is when someone uses your personal info to pretend to be you. They might open credit cards, take out loans, or even file a tax return in your name.\n\nThe jackpot for thieves is your **Social Security number** (SSN). Paired with your name and birthday, it opens a lot of doors you'd rather keep shut.",
        },
        {
          type: 'mc',
          id: 't2-u7-l2-e2',
          prompt: "Which piece of info is an identity thief's favorite?",
          choices: [
            { text: 'Your Social Security number', correct: true },
            {
              text: 'Your favorite pizza topping',
              why: "Pineapple opinions are spicy, but they can't open a credit card. Your SSN can.",
            },
            {
              text: 'Your shoe size',
              why: 'Nobody ever got a loan with a size 10. Thieves want ID numbers, not foot facts.',
            },
          ],
          explain: 'Your SSN is like a master key for credit and taxes. Give it only when it is truly needed, like for a job, a bank account, or tax forms.',
        },
        {
          type: 'teach',
          id: 't2-u7-l2-e3',
          emoji: '🎯',
          title: 'Why teens are targets',
          body: "Thieves love teen info because your credit history is a blank slate and nobody's watching it. A stolen teen SSN can get used for years before anyone notices.\n\nWarning signs: bills, collection calls, or tax letters about stuff you never did. At 18, check your free reports at **AnnualCreditReport.com**. Before that, a parent can ask each bureau if a report even exists (it usually shouldn't).",
        },
        {
          type: 'tf',
          id: 't2-u7-l2-e4',
          statement: "Teens can't be victims of identity theft because they don't have credit cards yet.",
          answer: false,
          explain: "False! A clean credit history is exactly what thieves want. A stolen teen SSN can be misused for years before anyone checks.",
        },
        {
          type: 'sort',
          id: 't2-u7-l2-e5',
          prompt: 'Red flag or totally normal?',
          buckets: ['Red flag', 'Normal'],
          items: [
            { text: 'Bill for a mystery card', bucket: 0 },
            { text: 'Collection call, unknown debt', bucket: 0 },
            { text: 'IRS says you already filed', bucket: 0 },
            { text: 'Your paycheck hits on payday', bucket: 1 },
            { text: 'Bank app shows your purchases', bucket: 1 },
            { text: 'Your W-2 arrives from work', bucket: 1 },
          ],
          explain: "Bills, debts, or tax filings you don't recognize mean someone may be using your info. Stuff you actually did? That's just life.",
        },
        {
          type: 'teach',
          id: 't2-u7-l2-e6',
          emoji: '🧊',
          title: "Freeze it like it's hot",
          body: "A **credit freeze** locks your credit report so new lenders can't look at it. No report, no new account. Thieves get stuck.\n\n- It's free at Equifax, Experian, and TransUnion.\n- It doesn't hurt your credit score.\n- You can thaw it when you need to apply for credit, then freeze it again.\n\nA parent can set one up for a kid, too.",
        },
        {
          type: 'mc',
          id: 't2-u7-l2-e7',
          prompt: 'What does a credit freeze actually stop?',
          choices: [
            { text: 'New accounts being opened in your name', correct: true },
            {
              text: 'You from using your debit card',
              why: 'Your existing cards and accounts work like normal. The freeze only blocks new credit.',
            },
            {
              text: 'Your credit score from ever changing',
              why: 'Your score keeps doing its thing. A freeze just keeps new lenders from peeking at your report.',
            },
            {
              text: 'Every scam text, forever',
              why: "If only. A freeze doesn't touch your phone, so you still need your scam radar.",
            },
          ],
          explain: "A freeze blocks new credit in your name. It won't stop someone from using a card number they already stole, so keep checking your accounts too.",
        },
        {
          type: 'match',
          id: 't2-u7-l2-e8',
          prompt: 'Match each protection to its job.',
          pairs: [
            { left: 'Credit freeze', right: 'Blocks new accounts in your name' },
            { left: 'Two-factor login', right: 'A second check beyond your password' },
            { left: 'Password manager', right: 'Keeps a unique password for everything' },
            { left: 'Shredder', right: 'Destroys old papers with personal info' },
            { left: 'AnnualCreditReport.com', right: 'Free look at your credit reports' },
          ],
          explain: 'Layers win. Stack a few of these and you become a really annoying target, which is exactly the goal.',
        },
        {
          type: 'fill',
          id: 't2-u7-l2-e9',
          sentence: "Never share your ___ or the ___ code a site texts you, even with someone who says they're from support.",
          answers: ['password', '2-factor'],
          bank: ['password', '2-factor', 'playlist', 'promo', 'Wi-Fi name'],
          explain: 'Real companies never ask for your password or 2-factor code. Anyone who does is trying to stroll right into your account.',
        },
        {
          type: 'teach',
          id: 't2-u7-l2-e10',
          emoji: '🎲',
          funFact: true,
          title: 'Your SSN got a makeover',
          body: 'Before 2011, the first three digits of a Social Security number were tied to the state on your application. That made numbers a bit easier to guess.\n\nNow they are assigned randomly. Thieves hate this one weird trick.',
        },
        {
          type: 'tf',
          id: 't2-u7-l2-e11',
          statement: "A credit freeze doesn't hurt your credit score.",
          answer: true,
          explain: 'True! A freeze has zero effect on your score. It just keeps new lenders out until you thaw it.',
        },
        {
          type: 'scenario',
          id: 't2-u7-l2-e12',
          emoji: '😳',
          setup: "You're 18 and just applied for your first credit card. Denied. The letter says your credit report shows missed car loan payments. You have never owned a car. You can barely parallel park.",
          question: "What's your first move?",
          choices: [
            {
              text: 'Ignore it. Probably a computer glitch.',
              outcome: "The \"glitch\" keeps missing payments in your name, and your credit takes the hit for months.",
            },
            {
              text: 'Check your credit reports and report it at IdentityTheft.gov',
              best: true,
              outcome: 'You find the fake loan, get a step-by-step recovery plan, and start fixing it. Then you freeze your credit so nobody can open new stuff in your name.',
            },
            {
              text: 'Apply for five more cards to see if one works',
              outcome: 'Five more denials, five more inquiries on your report, and the mystery car loan is still sitting there.',
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 3: Scams aimed at teens ---------------- */
    {
      id: 't2-u7-l3',
      title: 'Scams Aimed at You',
      description: 'Fake jobs, fake checks, money mules, and crypto giveaways built to trick teens.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u7-l3-e1',
          emoji: '🎣',
          title: 'Scammers want teens',
          body: "Scammers aim at teens on purpose. You're online a lot, you're hunting for jobs and side money, and you might not have seen these tricks yet.\n\nAlmost every scam has the same DNA:\n- **Pressure** to act right now\n- A request to keep it secret\n- Payment by gift card, crypto, or wire transfer",
        },
        {
          type: 'mc',
          id: 't2-u7-l3-e2',
          prompt: 'Which request is the biggest scam red flag?',
          choices: [
            { text: '"Pay this fee with gift cards"', correct: true },
            {
              text: "Paying your phone bill in the carrier's own app",
              why: "That's a normal bill paid through the real company. No red flag here.",
            },
            {
              text: 'Paying back a friend for pizza you shared',
              why: 'Paying a friend you know for pizza you both ate? Wholesome. Not a scam.',
            },
          ],
          explain: "Real companies and government agencies never ask you to pay with gift cards. Once you share the numbers on the back, the money's gone.",
        },
        {
          type: 'teach',
          id: 't2-u7-l3-e3',
          emoji: '📬',
          title: 'Fake jobs and fake checks',
          body: "A \"job\" pops up: work from home, $40 an hour, no interview. Then:\n\n- They want you to pay for training or a starter kit. (Real jobs pay **you**.)\n- Or they mail you a check for too much and ask you to send back the extra.\n\nThe check turns out to be fake, sometimes weeks later, and you owe the bank all of it.",
          example: 'Fake boss mails a $2,000 check for a $300 job. "Oops, overpaid! Send back $1,700 in gift cards." Weeks later, the check bounces and the bank wants its money back.',
        },
        {
          type: 'number',
          id: 't2-u7-l3-e4',
          prompt: 'A "boss" sends you a $1,000 check and asks you to send $900 back in gift cards. The check is fake. How much of your own money is gone (not counting fees)?',
          answer: 900,
          prefix: '$',
          explain: 'The bank takes back the whole $1,000 because it was never real. The $900 you sent came out of your actual money, so that is what you lose.',
        },
        {
          type: 'tf',
          id: 't2-u7-l3-e5',
          statement: 'If a check "clears" and the money shows up in your account, it is definitely real.',
          answer: false,
          explain: 'False! Banks have to make deposits available fast, but spotting a fake check can take weeks. If it bounces, you owe the bank.',
        },
        {
          type: 'teach',
          id: 't2-u7-l3-e6',
          emoji: '🐴',
          title: 'Do not become a mule',
          body: "Someone online offers easy cash: \"Just receive money in your account and send it on. Keep 10% for your trouble.\"\n\nThat's a **money mule** setup. You'd be moving stolen money for criminals. It can get your bank account shut down and get you in real legal trouble.\n\nNo legit job needs to borrow your bank account.",
        },
        {
          type: 'mc',
          id: 't2-u7-l3-e7',
          prompt: 'A gamer you met online wants to "borrow" your bank account to receive his payments. Why is this a problem?',
          choices: [
            { text: 'You could be moving stolen money as a mule', correct: true },
            {
              text: "It's fine, he seems really nice",
              why: "Scammers are extremely nice. That's kind of their whole job.",
            },
            {
              text: "It's only bad if he asks for your password",
              why: 'Even without your password, moving his money through your account makes you the mule.',
            },
          ],
          explain: 'Letting someone run money through your account is a classic money mule setup. "No" is a complete sentence here.',
        },
        {
          type: 'teach',
          id: 't2-u7-l3-e8',
          emoji: '🐟',
          funFact: true,
          title: 'Why phishing has a "ph"',
          body: "Fake messages that try to hook your info are called **phishing**. The weird spelling is usually traced to \"phone phreaks,\" early hackers who messed around with phone systems.\n\nSo scammers named their trick after fishing, then misspelled it on purpose. Bold choice, honestly.",
        },
        {
          type: 'sort',
          id: 't2-u7-l3-e9',
          prompt: 'Scam or legit?',
          buckets: ['Scam', 'Legit'],
          items: [
            { text: 'Send crypto, get double back', bucket: 0 },
            { text: 'Log in for free coins', bucket: 0 },
            { text: 'Keep this job secret', bucket: 0 },
            { text: 'Pay $50 to get hired', bucket: 0 },
            { text: 'Job interview before you start', bucket: 1 },
            { text: 'Paycheck by direct deposit', bucket: 1 },
            { text: 'Friend repays you for pizza', bucket: 1 },
          ],
          explain: 'Doubling crypto, coins for logins, secret jobs, and paying to work are all scams. Real jobs interview you, then pay you.',
        },
        {
          type: 'match',
          id: 't2-u7-l3-e10',
          prompt: 'Match each scam to its giveaway move.',
          pairs: [
            { left: 'Fake job', right: 'Makes you pay to start working' },
            { left: 'Fake check', right: 'Overpays you, wants the extra back' },
            { left: 'Money mule', right: 'Moves stolen money through your account' },
            { left: 'Crypto giveaway', right: 'Promises to double what you send' },
          ],
          explain: 'Different costumes, same trick: they need your money or your account. Spot the move and walk away.',
        },
        {
          type: 'fill',
          id: 't2-u7-l3-e11',
          sentence: 'Real prizes never make you ___ to claim them, and real companies never demand payment in ___.',
          answers: ['pay', 'gift cards'],
          bank: ['pay', 'gift cards', 'smile', 'dollars', 'checks'],
          explain: "Paying to claim a \"prize\" and paying in gift cards are both scam signatures. If one gets you anyway, report it at ReportFraud.ftc.gov. Staying quiet only helps the scammer.",
        },
        {
          type: 'scenario',
          id: 't2-u7-l3-e12',
          emoji: '🎁',
          setup: 'A DM from an account using a famous creator\'s name and photo: "Giveaway! Send $25 in crypto and I\'ll send back $250. Only 10 spots left!"',
          question: 'What do you do?',
          choices: [
            {
              text: "Send $25. Worst case, I'm only out $25.",
              outcome: 'You lose $25, and now you are on a list of people who fall for it. Expect round two very soon.',
            },
            {
              text: 'Ignore it, block it, and report the account',
              best: true,
              outcome: 'Scam blocked. The real creator never needed your $25 and was never doubling anything.',
            },
            {
              text: 'Ask them to prove it first',
              outcome: 'They send a screenshot of fake "winners." Proof from a scammer is just more scam.',
            },
          ],
        },
      ],
    },

    /* ---------------- Lesson 4: Net worth, giving back & your money plan ---------------- */
    {
      id: 't2-u7-l4',
      title: 'Your Money Plan',
      description: 'Net worth, giving back, and putting the whole money game together.',
      exercises: [
        {
          type: 'teach',
          id: 't2-u7-l4-e1',
          emoji: '📊',
          title: 'Net worth: own minus owe',
          body: "Your **net worth** is a snapshot of your money life: **assets** (what you own) minus **liabilities** (what you owe).\n\nAssets: cash, savings, investments, a car. Liabilities: loans, credit card balances, and the $20 you still owe your sister.",
          example: 'You have $800 in savings and a bike worth $200. You owe a friend $100. Net worth: $800 + $200 - $100 = $900.',
        },
        {
          type: 'number',
          id: 't2-u7-l4-e2',
          prompt: 'You have $1,500 in savings and a car worth $3,000. You still owe $2,000 on the car loan. What is your net worth?',
          answer: 2500,
          prefix: '$',
          explain: '$1,500 + $3,000 = $4,500 in assets. Minus the $2,000 you owe = $2,500. Look at you, in the green.',
        },
        {
          type: 'sort',
          id: 't2-u7-l4-e3',
          prompt: 'Asset or liability?',
          buckets: ['Asset', 'Liability'],
          items: [
            { text: 'Money in savings', bucket: 0 },
            { text: 'A paid-off used car', bucket: 0 },
            { text: 'Roth IRA balance', bucket: 0 },
            { text: 'Student loan balance', bucket: 1 },
            { text: 'Credit card balance', bucket: 1 },
            { text: '$20 you owe a friend', bucket: 1 },
          ],
          explain: 'Assets are things you own that have value. Liabilities are money you owe someone. Your net worth is the gap between them.',
        },
        {
          type: 'tf',
          id: 't2-u7-l4-e4',
          statement: "A negative net worth means you're bad with money.",
          answer: false,
          explain: "False! Lots of people start negative because of student loans or a car loan. Net worth is a snapshot, not a report card. What matters is which way it's heading.",
        },
        {
          type: 'teach',
          id: 't2-u7-l4-e5',
          emoji: '💛',
          title: 'Giving back counts too',
          body: "Money isn't only for spending and saving. **Giving** belongs in a solid plan, too.\n\nYou can give money, time (volunteering), or skills (tutoring, fixing your neighbor's Wi-Fi). Before donating, make sure the charity is real: look it up yourself and give through its official website. Scammers love fake charities, especially after disasters.",
        },
        {
          type: 'mc',
          id: 't2-u7-l4-e6',
          prompt: 'After a big hurricane, a text says: "Donate now to help victims! Pay by gift card." What\'s the move?',
          choices: [
            { text: "Look up a known charity and give on its own site", correct: true },
            {
              text: 'Send the gift card fast, people need help',
              why: 'Your heart is in the right place, but gift card "donations" go straight to scammers.',
            },
            {
              text: 'Never donate to anything, ever again',
              why: "That's overcorrecting. Real charities do great work. You just have to find them yourself.",
            },
          ],
          explain: "Real charities don't ask for gift cards. Go to them directly instead of tapping a random link.",
        },
        {
          type: 'teach',
          id: 't2-u7-l4-e7',
          emoji: '🧭',
          title: 'The whole plan, one card',
          body: "Everything you've learned fits in one loop:\n\n- Earn it (jobs, gigs, skills)\n- Plan it (a budget that gives every dollar a job)\n- Save it (start with an emergency fund)\n- Grow it (long-term investing)\n- **Protect** it (insurance, credit freezes, scam radar)\n\nThen repeat for, like, the rest of your life.",
        },
        {
          type: 'match',
          id: 't2-u7-l4-e8',
          prompt: 'Match each money tool to its job.',
          pairs: [
            { left: 'Budget', right: 'A plan for every dollar' },
            { left: 'Emergency fund', right: 'Cash for surprise costs' },
            { left: 'Insurance', right: "Covers big losses you couldn't afford" },
            { left: 'Credit freeze', right: 'Blocks fake accounts in your name' },
            { left: 'Index fund', right: 'Long-term growth across many companies' },
          ],
          explain: 'Each tool has one job. Put them together and your money gets a full security team plus a growth plan.',
        },
        {
          type: 'fill',
          id: 't2-u7-l4-e9',
          sentence: 'Net worth = ___ minus ___.',
          answers: ['assets', 'liabilities'],
          bank: ['assets', 'liabilities', 'dreams', 'income', 'followers'],
          explain: 'What you own minus what you owe. Followers, sadly, are not an asset class.',
        },
        {
          type: 'tf',
          id: 't2-u7-l4-e10',
          statement: "Volunteering your time counts as giving back, even if you never donate a dollar.",
          answer: true,
          explain: 'True! Time and skills are real gifts. Tutoring, park cleanups, and food bank shifts all count.',
        },
        {
          type: 'scenario',
          id: 't2-u7-l4-e11',
          emoji: '🥤',
          setup: 'Your first smoothie shop paycheck is $300. You want $150 headphones, you have no emergency fund yet, and a DM promises $500 a week for "moving funds" through your account.',
          question: 'Which plan is the most solid?',
          choices: [
            {
              text: 'Take the DM job, it pays way more',
              outcome: "That's a money mule gig. Your bank shuts down your account, and now you have bigger problems than headphones.",
            },
            {
              text: 'Start an emergency fund, budget for headphones, ignore the DM',
              best: true,
              outcome: 'Savings started, headphones arrive in a couple of paychecks, scammer ignored. Textbook money move.',
            },
            {
              text: 'Spend it all on headphones and snacks today',
              outcome: "Great day. Then your phone screen cracks and there's $0 to fix it.",
            },
          ],
        },
      ],
    },
  ],

  quiz: {
    passPercent: 70,
    exercises: [
      {
        type: 'mc',
        id: 't2-u7-q-e1',
        prompt: 'What is a deductible?',
        choices: [
          { text: 'What you pay before insurance starts paying', correct: true },
          {
            text: 'Your monthly insurance bill',
            why: "That's the premium. The deductible is your share when you actually use the coverage.",
          },
          {
            text: 'A discount for being a good driver',
            why: 'Discounts exist, but that is not this. A deductible is money you pay out of pocket first.',
          },
          {
            text: 'A refund for years with no claims',
            why: 'A quiet year usually just means you paid for peace of mind. The deductible is your share when you file a claim.',
          },
        ],
        explain: 'Your deductible comes first, then insurance kicks in. Higher deductible, lower premium, and the other way around.',
      },
      {
        type: 'number',
        id: 't2-u7-q-e2',
        prompt: 'Your renters insurance deductible is $250. A kitchen fire ruins $900 of your stuff. How much does insurance pay?',
        answer: 650,
        prefix: '$',
        explain: '$900 minus your $250 deductible = $650. Renters insurance to the rescue (and maybe a cooking class).',
      },
      {
        type: 'tf',
        id: 't2-u7-q-e3',
        statement: 'If a parent has health insurance, you can usually stay on their plan until age 26.',
        answer: true,
        explain: "True! Thanks to the Affordable Care Act, you can usually stay on a parent's health plan until 26, even if you move out or get married.",
      },
      {
        type: 'mc',
        id: 't2-u7-q-e4',
        prompt: 'Your info leaked in a data breach. Which move blocks thieves from opening new credit in your name?',
        choices: [
          { text: 'Freeze your credit at all three bureaus', correct: true },
          {
            text: 'Change your profile picture',
            why: 'A fresh selfie is nice, but thieves already have your data. A freeze stops them from using it for new credit.',
          },
          {
            text: 'Delete all your social media',
            why: 'Might be relaxing, but the leaked info is already out there. A freeze is what blocks new accounts.',
          },
          {
            text: 'Close your savings account',
            why: 'Your savings is not the problem here. New accounts in your name are, and a freeze blocks those.',
          },
        ],
        explain: 'A credit freeze at Equifax, Experian, and TransUnion is free and stops new lenders from pulling your report. Thieves hit a wall.',
      },
      {
        type: 'fill',
        id: 't2-u7-q-e5',
        sentence: "A credit freeze is ___ and doesn't hurt your credit ___.",
        answers: ['free', 'score'],
        bank: ['free', 'score', 'expensive', 'feelings', '$99'],
        explain: 'Free at all three bureaus, zero effect on your score. Easiest win in this whole unit.',
      },
      {
        type: 'sort',
        id: 't2-u7-q-e6',
        prompt: 'Red flag or green flag?',
        buckets: ['Red flag', 'Green flag'],
        items: [
          { text: 'Pay with gift cards', bucket: 0 },
          { text: 'Keep it secret from parents', bucket: 0 },
          { text: 'Send money through your account', bucket: 0 },
          { text: 'Act in 10 minutes!', bucket: 0 },
          { text: 'Interview before hiring', bucket: 1 },
          { text: 'Time to think it over', bucket: 1 },
        ],
        explain: 'Weird payments, secrecy, using your account, and fake deadlines are scam classics. Legit people are fine with you taking your time.',
      },
      {
        type: 'scenario',
        id: 't2-u7-q-e7',
        emoji: '🎮',
        setup: 'You sell your old game console online for $150. The buyer mails you a check for $450 and asks you to send the extra $300 back through a payment app.',
        question: 'What do you do?',
        choices: [
          {
            text: 'Deposit it and send the $300 back',
            outcome: 'The check bounces. The bank takes back $450, and your $300 is gone for good.',
          },
          {
            text: 'Refuse the overpayment and cancel the sale',
            best: true,
            outcome: 'The "buyer" vanishes, because they never wanted the console. You keep your console and your $300.',
          },
          {
            text: 'Wait until it clears, then send the $300',
            outcome: 'It "clears," you send $300, then it gets flagged as fake weeks later. Same scam, just slower.',
          },
        ],
      },
      {
        type: 'tf',
        id: 't2-u7-q-e8',
        statement: 'A legit job might ask you to buy a starter kit with gift cards before your first shift.',
        answer: false,
        explain: 'False! Real jobs pay you, not the other way around. Gift card payments are a scam signature.',
      },
      {
        type: 'number',
        id: 't2-u7-q-e9',
        prompt: 'You have $600 in savings and owe your cousin $250. That is all your money stuff. What is your net worth?',
        answer: 350,
        prefix: '$',
        explain: '$600 owned minus $250 owed = $350. Pay your cousin back and you keep the $350 with zero debt.',
      },
      {
        type: 'match',
        id: 't2-u7-q-e10',
        prompt: 'Match each term to its meaning.',
        pairs: [
          { left: 'Asset', right: 'Something you own with value' },
          { left: 'Liability', right: 'Money you owe someone' },
          { left: 'Net worth', right: 'What you own minus what you owe' },
          { left: 'Premium', right: 'What you pay to stay insured' },
          { left: 'Phishing', right: 'Fake messages fishing for your info' },
        ],
        explain: 'Own, owe, insure, and dodge the phish. That is the whole protect-your-money toolkit.',
      },
    ],
  },
}

export default unit
