/*
  Shared playful lines used across the app. Rotating these keeps feedback
  from feeling robotic. Keep them short, dry, and kind. No slang, no em
  dashes, and go easy on the exclamation marks.
*/
import { pick } from './random'

export const CORRECT_LINES = [
  'Nailed it!',
  'Cha-ching.',
  'Correctamundo.',
  "That's the one.",
  'Your future self says thanks.',
  'Smart cookie.',
  'You make this look easy.',
  'Yep. Extremely yep.',
  'Textbook.',
  'Your piggy bank is applauding.',
  'Look at you go.',
  'Right on the money.',
]

export const WRONG_LINES = [
  'Not quite.',
  'Oof, close.',
  'Plot twist: nope.',
  'Swing and a miss.',
  'That one was sneaky.',
  'Close, but no.',
  'Not this time.',
  'Nope. Good guess, though.',
]

/** For when you get a question right after missing it earlier in the lesson. */
export const COMEBACK_LINES = ['Comeback complete.', 'Second time is the charm.', 'Got it this time.', 'Look who figured it out.']

export const LESSON_DONE_LINES = [
  'Lesson complete!',
  'Done and dusted.',
  'Another one in the bank.',
  'Your brain just got a raise.',
  "You're on a roll.",
]

export const PERFECT_LINES = ['Perfect lesson!', 'Zero mistakes. Show-off.', 'Not a single slip.']

export const QUIT_LINES = [
  "Leave now and this lesson's progress leaves with you.",
  'Your progress will vanish like birthday money at the mall.',
  "Quit now and you'll start this lesson over next time.",
]

export const OUT_OF_HEARTS_LINES = [
  'Even money experts need a breather.',
  'Zero hearts. Your brain is buffering.',
  'Hearts: zero. Wisdom: still growing.',
]

export const randomLine = (lines: readonly string[]) => pick(lines)
