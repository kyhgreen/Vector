/*
  Every word the League screen says, plus the little helpers that turn
  numbers into friendly text. Kept in one place so it's easy to tweak the
  jokes (and so a test can check there's no em dash hiding anywhere).
*/
import { addDays, dayKey, parseDay, weekStart } from '../../lib/dates'
import { hashString } from '../../lib/random'
import { number, plural } from '../../lib/format'
import { XP } from '../../state/constants'
import { DIVISIONS, DEMOTE_COUNT, PROMOTE_COUNT } from '../../state/league'
import type { LeagueOutcome } from '../../state/league'

/* ---------- Small safe helpers ---------- */

/** Any number in, a finite number out. Keeps NaN far away from the UI. */
export const safe = (n: unknown, fallback = 0): number => (typeof n === 'number' && Number.isFinite(n) ? n : fallback)

/** Clamps a stored division index into the real range. */
export const clampDivision = (d: unknown): number => Math.max(0, Math.min(DIVISIONS.length - 1, Math.floor(safe(d))))

export const divisionName = (d: number): string => DIVISIONS[clampDivision(d)].name

export const leagueName = (d: number): string => `${divisionName(d)} League`

/** Deterministic pick: same seed, same line. So text doesn't reshuffle every render. */
export function pickBy<T>(items: readonly T[], seed: string): T {
  return items[hashString(seed) % items.length]
}

/** 1 -> "1st", 2 -> "2nd", 11 -> "11th", 23 -> "23rd". */
export function ordinal(n: number): string {
  const v = Math.max(0, Math.floor(safe(n)))
  const mod100 = v % 100
  if (mod100 >= 11 && mod100 <= 13) return `${v}th`
  switch (v % 10) {
    case 1:
      return `${v}st`
    case 2:
      return `${v}nd`
    case 3:
      return `${v}rd`
    default:
      return `${v}th`
  }
}

/** Milliseconds until next Monday 00:00 local time (when the league resets). */
export function msUntilReset(now: Date): number {
  const nextMonday = parseDay(addDays(weekStart(dayKey(now)), 7)).getTime()
  return Math.max(0, nextMonday - now.getTime())
}

/** "3d 4h", "5h 12m", "12m" plus a screen-reader version. */
export function timeLeft(ms: number): { short: string; long: string } {
  const t = Math.max(0, safe(ms))
  const days = Math.floor(t / 86_400_000)
  const hours = Math.floor((t % 86_400_000) / 3_600_000)
  const mins = Math.floor((t % 3_600_000) / 60_000)
  if (days >= 1) return { short: `${days}d ${hours}h`, long: `${plural(days, 'day')} ${plural(hours, 'hour')}` }
  if (hours >= 1) return { short: `${hours}h ${mins}m`, long: `${plural(hours, 'hour')} ${plural(mins, 'minute')}` }
  if (mins >= 1) return { short: `${mins}m`, long: plural(mins, 'minute') }
  return { short: 'under 1m', long: 'less than a minute' }
}

/** Rough "that's about 2 lessons" so XP gaps feel doable. */
export function lessonsFor(xp: number): string {
  const n = Math.max(1, Math.ceil(Math.max(0, safe(xp)) / XP.lesson))
  return n === 1 ? 'about one lesson' : `about ${plural(n, 'lesson')}`
}

export const xpText = (xp: number) => `${number(Math.max(0, Math.round(safe(xp))))} XP`

/* ---------- Divisions ---------- */

/** Face value printed on each division's coin or bill. */
const GLYPHS: Record<string, string> = {
  Penny: '1¢',
  Nickel: '5¢',
  Dime: '10¢',
  Quarter: '25¢',
  'Half-Dollar': '50¢',
  Dollar: '$1',
  Fiver: '$5',
  Tenner: '$10',
  Twenty: '$20',
  Benjamin: '$100',
}

export function divisionGlyph(d: number): string {
  const name = divisionName(d)
  return GLYPHS[name] ?? name.charAt(0)
}

/** Cents divisions are coins. Dollar divisions are bills. Climbing literally makes you worth more. */
export function divisionShape(d: number): 'coin' | 'bill' {
  return divisionGlyph(d).endsWith('¢') ? 'coin' : 'bill'
}

const QUIPS: Record<string, string> = {
  Penny: 'Everyone starts somewhere. This is somewhere.',
  Nickel: 'Five cents of pure ambition.',
  Dime: 'Small coin, big opinions.',
  Quarter: 'Laundry money, but competitive.',
  'Half-Dollar': "Most people have never held one. You're in one.",
  Dollar: 'A whole bill. Very fancy.',
  Fiver: 'Five times fancier than a Dollar.',
  Tenner: 'Double digits. Double the drama.',
  Twenty: "The ATM's favorite.",
  Benjamin: 'The top of the money pile.',
}

export const divisionQuip = (d: number) => QUIPS[divisionName(d)] ?? 'One coin at a time.'

const FACTS: Record<string, string> = {
  Penny: 'A penny cost almost 4 cents to make. Not a great deal.',
  Nickel: 'A nickel is only 25% nickel. The rest is copper. Misleading, if you ask us.',
  Dime: "The dime is the smallest U.S. coin, but it's worth more than a penny or a nickel.",
  Quarter: 'A quarter has 119 ridges around its edge. Go ahead and count. We can wait.',
  'Half-Dollar': 'Half-dollars are still made, but mostly for collectors.',
  Dollar: "Dollar bills are mostly cotton, not paper. That's why they survive the wash.",
  Fiver: 'Abraham Lincoln is on the $5 bill. Honest Abe, honest five.',
  Tenner: 'Alexander Hamilton, the first Treasury Secretary, is on the $10. Money guy on the money.',
  Twenty: 'Most U.S. ATMs only hand out twenties.',
  Benjamin: 'Benjamin Franklin is on the $100 bill. He was never president.',
}

export const divisionFact = (d: number) => FACTS[divisionName(d)] ?? 'Every coin has a story. This one is still writing it.'

export const isTopDivision = (d: number) => clampDivision(d) === DIVISIONS.length - 1
export const isBottomDivision = (d: number) => clampDivision(d) === 0

/** The rules line under the league title, adjusted for the top and bottom leagues. */
export function rulesLine(d: number): string {
  if (isTopDivision(d)) return `You're at the top. Bottom ${DEMOTE_COUNT} drop a league.`
  if (isBottomDivision(d)) return `Top ${PROMOTE_COUNT} move up. Nobody falls out of Penny.`
  return `Top ${PROMOTE_COUNT} move up. Bottom ${DEMOTE_COUNT} drop.`
}

/** Status text for a division on the ladder sheet. */
export function ladderStatus(d: number, current: number): string {
  if (d < current) return 'Already climbed past this one.'
  if (d === current) {
    if (isTopDivision(d)) return `You made it. Now stay out of the bottom ${DEMOTE_COUNT}.`
    return `You're here. Top ${PROMOTE_COUNT} this week moves up.`
  }
  const steps = d - current
  return steps === 1 ? `Next stop. Finish in the top ${PROMOTE_COUNT} to get here.` : `${steps} leagues up. Pack a lunch.`
}

/* ---------- Rivals ---------- */

const BIOS = [
  'Has a spreadsheet for their spreadsheets.',
  'Saves every birthday dollar. Every. Single. One.',
  'Thinks free samples count as a food group.',
  'Once haggled at a lemonade stand. Lost. Bought two.',
  'Keeps a piggy bank named Gerald.',
  'Reads receipts like mystery novels.',
  'Will walk 20 minutes to save 50 cents.',
  'Dreams in compound interest.',
  'Has never once paid for shipping.',
  'Treats allowance day like a national holiday.',
  'Rolls their own pennies. For fun.',
  'Asked for an emergency fund for their birthday.',
  'Knows the price of everything in the vending machine.',
  'Runs a dog-walking empire. Two dogs so far.',
  'Has a rainy day jar and a sunny day jar.',
  'Checks the clearance rack before saying hello.',
  'Calls their savings goal "Operation Hoverboard."',
  'Can split a pizza bill five ways in their head.',
]

export const rivalBio = (name: string) => pickBy(BIOS, `bio|${name}`)

const STATUSES = [
  'Studying with snacks',
  'Clipping coupons',
  'Counting quarters',
  'Running a lemonade stand',
  'Saving for a hoverboard',
  'Reading the fine print',
  'Rolling pennies',
  'Doing math for fun',
  'Budgeting their snacks',
  'Hiding from the ice cream truck',
  'Guarding the piggy bank',
  'Comparing price tags',
  'Stretching before a quiz',
]

const NAP_STATUSES = ['Taking a nap', 'Snack break', 'Away from keyboard', 'Probably at practice']

/** One short line under a rival's name. Changes each day so the board feels alive. */
export function rivalStatus(id: string, weekKey: string, dayIndex: number, recentGain: number): string {
  if (recentGain >= 25) return 'On a roll'
  if (recentGain <= 0) return pickBy(NAP_STATUSES, `nap|${weekKey}|${id}|${dayIndex}`)
  return pickBy(STATUSES, `st|${weekKey}|${id}|${dayIndex}`)
}

/** How a rival plays the week, from the shape of their XP curve. */
export function rivalStyle(curve: number): { label: string } {
  const c = safe(curve, 1)
  if (c < 0.9) return { label: 'Early bird' }
  if (c > 1.35) return { label: 'Last-minute crammer' }
  return { label: 'Slow and steady' }
}

/** One line of gossip above the leaderboard. */
export function rivalReport(opts: { hotName?: string; hotGain: number; everyoneZero: boolean; seed: string }): string {
  if (opts.everyoneZero) {
    return pickBy(["Fresh week. Everyone's at 0 XP.", 'Nobody has started yet. Suspicious.'], opts.seed)
  }
  if (opts.hotName && opts.hotGain >= 10) {
    const g = number(opts.hotGain)
    return pickBy(
      [
        `${opts.hotName} earned ${g} XP in the last 12 hours.`,
        `${opts.hotName} has been busy. ${g} XP in 12 hours busy.`,
        `${opts.hotName} picked up ${g} XP in 12 hours. Rude.`,
      ],
      opts.seed,
    )
  }
  return pickBy(['Quiet out there. Good time to sneak ahead.', "Everyone's on a snack break."], opts.seed)
}

/* ---------- Your week ---------- */

export type YouMessage = {
  tone: 'promote' | 'safe' | 'demote'
  title: string
  body: string
  /** Progress toward the next line to cross (promotion zone or safety). */
  goal?: { current: number; target: number; label: string }
}

/**
  The "here's where you stand" message. `rows` must be sorted by rank.
  Ties go to you, so to pass someone you need to match their XP.
*/
export function youMessage(rows: { name: string; xp: number; isYou: boolean; rank: number }[], division: number): YouMessage | null {
  const total = rows.length
  const youIdx = rows.findIndex((r) => r.isYou)
  if (youIdx < 0 || total === 0) return null
  const you = rows[youIdx]
  const above = rows[youIdx - 1]
  const below = rows[youIdx + 1]
  const canPromote = !isTopDivision(division)
  const canDemote = !isBottomDivision(division)
  const promoteLine = Math.min(PROMOTE_COUNT, total)
  const safeLine = total - DEMOTE_COUNT

  if (you.rank === 1) {
    const leadBy = below ? Math.max(0, you.xp - below.xp) : 0
    if (!canPromote) {
      return {
        tone: 'promote',
        title: 'Top of the money pile',
        body: below && leadBy > 0 ? `${xpText(leadBy)} ahead of ${below.name}. Nice view up here.` : 'Nice view up here.',
      }
    }
    return {
      tone: 'promote',
      title: "You're in first",
      body:
        below && leadBy > 0
          ? `${xpText(leadBy)} ahead of ${below.name}. Hold on until Monday.`
          : below
            ? `Hold on until Monday. ${below.name} is right behind you.`
            : 'Hold on until Monday.',
    }
  }

  if (canPromote && you.rank <= promoteLine) {
    const gap = above ? above.xp - you.xp : 0
    return {
      tone: 'promote',
      title: 'Promotion zone',
      body: above ? `Stay in the top ${PROMOTE_COUNT} to move up. ${xpText(gap)} more passes ${above.name}.` : `Stay in the top ${PROMOTE_COUNT} to move up.`,
    }
  }

  if (canDemote && you.rank > safeLine && safeLine >= 1) {
    const target = rows[safeLine - 1]
    const need = Math.max(1, target.xp - you.xp)
    return {
      tone: 'demote',
      title: 'Danger zone',
      body: `${xpText(need)} gets you out of the bottom ${DEMOTE_COUNT}. That's ${lessonsFor(need)}.`,
      goal: { current: you.xp, target: target.xp, label: 'Climb to safety' },
    }
  }

  if (canPromote) {
    const target = rows[promoteLine - 1]
    const need = Math.max(1, target.xp - you.xp)
    return {
      tone: 'safe',
      title: `${ordinal(you.rank)} place. Not bad.`,
      body: `${xpText(need)} more puts you in the top ${PROMOTE_COUNT}. That's ${lessonsFor(need)}.`,
      goal: { current: you.xp, target: target.xp, label: `Progress to the top ${PROMOTE_COUNT}` },
    }
  }

  const gap = above ? above.xp - you.xp : 0
  return {
    tone: 'safe',
    title: `${ordinal(you.rank)} place. Nice and safe.`,
    body: above ? `${xpText(Math.max(1, gap))} more passes ${above.name}.` : 'Nobody is catching you today.',
  }
}

/* ---------- Last week's result ---------- */

export function resultCopy(r: { outcome: LeagueOutcome; rank: number; from: number; to: number; weekKey: string }): {
  title: string
  body: string
  button: string
} {
  const place = ordinal(r.rank)
  const seed = `result|${r.weekKey}`
  if (r.outcome === 'promoted') {
    return {
      title: `Promoted to ${leagueName(r.to)}!`,
      body: pickBy(
        [
          `${place} place last week. The ${divisionName(r.from)} League will miss you. Probably.`,
          `${place} place last week. Pack your bags.`,
          `${place} place last week. Your coin just got an upgrade.`,
        ],
        seed,
      ),
      button: 'Continue',
    }
  }
  if (r.outcome === 'demoted') {
    return {
      title: `Back to ${leagueName(r.to)}`,
      body: pickBy(
        [
          `${place} place last week. Call it a strategic retreat.`,
          `${place} place last week. Even the stock market has bad weeks.`,
          `${place} place last week. One good week and you're back.`,
        ],
        seed,
      ),
      button: 'Got it',
    }
  }
  if (isTopDivision(r.to) && r.rank <= PROMOTE_COUNT) {
    return {
      title: `Still on top in ${leagueName(r.to)}`,
      body: `${place} place last week. There's nowhere higher, so enjoy the view.`,
      button: 'Got it',
    }
  }
  if (isTopDivision(r.to)) {
    return {
      title: `Still in ${leagueName(r.to)}`,
      body: `${place} place last week. Just stay out of the bottom ${DEMOTE_COUNT}.`,
      button: 'Got it',
    }
  }
  if (isBottomDivision(r.to) && r.rank > PROMOTE_COUNT) {
    return {
      title: `Still in ${leagueName(r.to)}`,
      body: `${place} place last week. Top ${PROMOTE_COUNT} this week gets you out.`,
      button: 'Got it',
    }
  }
  return {
    title: `Still in ${leagueName(r.to)}`,
    body: `${place} place last week. Aim for the top ${PROMOTE_COUNT} this time.`,
    button: 'Got it',
  }
}

/** Every string pool above, for the no-em-dash test. */
export const ALL_COPY_POOLS: readonly (readonly string[])[] = [
  Object.values(QUIPS),
  Object.values(FACTS),
  BIOS,
  STATUSES,
  NAP_STATUSES,
]
