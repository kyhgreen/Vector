/*
  Every line the lesson player says. Short, dry, a little silly. No slang,
  no em dashes, at most one exclamation mark per screen.
*/
import type { Mode } from './session'

export const CORRECT_LINES = ['Nice!', 'Correct.', "That's the one.", 'Nailed it.', 'Cha-ching.', 'Smart cookie.', 'Your wallet approves.', 'Exactly right.']

export const WRONG_LINES = ['Not quite.', 'Close, but no.', 'Nope.', 'That one was sneaky.', 'Not this time.', 'Swing and a miss.']

export const COMEBACK_LINES = ['Got it this time.', 'Second time lucky.', 'Much better.', 'There we go.']

export const COMBO_TAILS = ['Show-off.', 'On fire.', 'Who taught you this?', 'Calm down, genius.', 'Unstoppable.']

export const RETRY_LABEL = 'Rematch'

export const QUIT_TITLES: Record<Mode, string> = {
  lesson: 'Quit this lesson?',
  quiz: 'Quit the quiz?',
  practice: 'Quit practice?',
}

export const LESSON_QUIT_LINES = [
  "You'll lose your progress on this one.",
  'Leave now and you start over next time.',
  'Your progress will vanish like birthday money.',
]

export const QUIZ_QUIT_LINES = ["Your answers so far won't count.", 'No score, no coins. Just saying.']

export const PRACTICE_QUIT_LINES = ["You'll miss the bonus heart.", 'Your mistakes will wait. Patiently.']

export const MATCH_MESSY_LINES = ['Got there in the end.', 'All paired up. Eventually.', 'Matched, with a few detours.']
export const MATCH_MESSY_NOTE = "No hearts lost. It'll come back in Practice."
/** Quizzes score honestly: 2+ wrong taps means this one doesn't count as right. */
export const MATCH_MESSY_NOTE_QUIZ = "A few wrong taps, so this one doesn't count."

export const LESSON_DONE_LINES = ['Lesson complete!', 'Done and dusted.', 'Another one in the bank.', 'Lesson done!']
export const LESSON_SUBS = ['Your future self says thanks.', 'Plenty of adults never learned that.', 'Brain: bigger. Wallet: safer.']

export const PERFECT_LINES = ['Perfect lesson!', 'Flawless!', 'Not one slip!']
export const PERFECT_SUBS = ['Are you secretly a banker?', 'Somebody frame this.', 'Zero mistakes. Show-off.']

export const QUIZ_PASS_LINES = ['Quiz passed!', 'You passed!', 'Unit done!']
export const QUIZ_FAIL_TITLE = 'So close!'

export const PRACTICE_DONE_LINES = ['Practice done!', 'Mistakes handled.', 'Workout done.']
export const PRACTICE_SUBS = ['Old mistakes, meet your match.', 'It sticks better every time.', 'No sweatband needed.']

export const STREAK_SUBS = ['Keep the fire fed.', 'Your streak is looking toasty.', 'See you tomorrow.']
export const STREAK_FIRST_SUB = 'Come back tomorrow and make it 2.'

export const EMPTY_PRACTICE = {
  title: 'Nothing to practice yet.',
  body: 'Mistakes from lessons end up here. So far, none. Impressive.',
}
