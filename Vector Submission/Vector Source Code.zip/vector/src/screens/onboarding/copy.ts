/*
  The onboarding lines that are just for fun, kept in one spot so they're
  easy to tweak. House rule: no em dashes.
*/

/** What the splash screen's dollar bill says when you poke it. */
export const BILL_LINES = [
  'Hey, that tickles.',
  "I'm worth 100 pennies. No pressure.",
  'Spend me on purpose, okay?',
  'I want to be a savings account when I grow up.',
  "I'm not wrinkly. I'm well traveled.",
  "Poke me again and I'm charging interest.",
] as const

/** Random nickname ideas for the dice button. All 20 characters or less. */
export const NICKNAME_IDEAS = [
  'Penny Pincher',
  'Captain Coupon',
  'Sir Saves-a-Lot',
  'Budget Boss',
  'Nickel Ninja',
  'Dollar Dynamo',
  'Frugal Falcon',
  'Savings Sloth',
  'Budget Raccoon',
  'Compound Kid',
  'Money Moose',
  'Thrifty Wizard',
  'Quarterback',
  'Coin Goblin',
  'Dime Dragon',
  'Cash Cactus',
  'The Coin Collector',
  'Interest Panda',
  'Receipt Keeper',
  'Sock Drawer Bank',
] as const

export const NAME_MAX = 20

/** Rough minutes per day for each daily goal (keyed by XP). */
const GOAL_MINUTES: Record<number, number> = { 10: 5, 20: 10, 30: 15, 50: 25 }

export function goalMinutes(xp: number) {
  return GOAL_MINUTES[xp] ?? Math.max(5, Math.round(xp / 2))
}
