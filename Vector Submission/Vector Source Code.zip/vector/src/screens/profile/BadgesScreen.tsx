/* Badges (/profile/badges): the full trophy case as a list. Tap any badge for details. */
import { useState } from 'react'
import { useNavigate } from 'react-router'
import { motion, useReducedMotion } from 'motion/react'
import { PageHeader } from '../../components/PageHeader'
import { Button } from '../../components/Button'
import { Empty, Ring, Segmented } from '../../components/ui'
import { useGame } from '../../state/store'
import { BADGES, type Badge } from '../../state/badges'
import { number } from '../../lib/format'
import { BadgeSheet, BadgeTile } from './Badges'
import { earnedBadges, earnedCount, lockedBadges } from './profileUtils'
import styles from './BadgesScreen.module.css'

type Filter = 'all' | 'earned' | 'locked'

function cheer(earned: number, total: number): string {
  if (total <= 0) return 'Badges are stuck in traffic.'
  const r = earned / total
  if (earned === 0) return 'The trophy case is echoing.'
  if (earned === total) return 'Every last one. The shelf is full.'
  if (r < 0.2) return 'A good start. The shelf is warming up.'
  if (r < 0.5) return 'Growing slowly, like interest.'
  if (r < 0.85) return 'Over halfway. Basically a museum.'
  return 'So close to the full set.'
}

function FilterLabel({ text, n }: { text: string; n: number }) {
  return (
    <span className={styles.filterLabel}>
      {text} <span className={styles.count}>{number(n)}</span>
    </span>
  )
}

export default function BadgesScreen() {
  const navigate = useNavigate()
  const reduce = !!useReducedMotion()
  const data = useGame()
  const [filter, setFilter] = useState<Filter>('all')
  const [openBadge, setOpenBadge] = useState<Badge | null>(null)

  const total = BADGES.length
  const earned = earnedCount(data)
  const locked = total - earned
  const list: Badge[] = filter === 'earned' ? earnedBadges(data) : filter === 'locked' ? lockedBadges(data) : BADGES

  return (
    <div className={styles.page}>
      <PageHeader title="Badges" back="/profile" />

      <section className={styles.summary} aria-label="Badge progress">
        <Ring value={total ? earned / total : 0} size={72} stroke={9} color="purple">
          <span className={styles.ringNum}>{total ? Math.round((earned / total) * 100) : 0}%</span>
        </Ring>
        <div className={styles.summaryText}>
          <p className={styles.summaryTitle}>
            {number(earned)} of {number(total)}
          </p>
          <p className={styles.summaryLine}>{cheer(earned, total)}</p>
        </div>
      </section>

      <Segmented
        className={styles.filter}
        value={filter}
        onChange={setFilter}
        options={[
          { value: 'all', label: <FilterLabel text="All" n={total} /> },
          { value: 'earned', label: <FilterLabel text="Earned" n={earned} /> },
          { value: 'locked', label: <FilterLabel text="Locked" n={locked} /> },
        ]}
      />

      {list.length === 0 ? (
        filter === 'earned' ? (
          <Empty emoji="🕸️" title="No badges yet">
            <p>Finish a lesson and the first one's yours.</p>
            <div className={styles.emptyBtn}>
              <Button color="green" size="md" block={false} onClick={() => navigate('/learn')}>
                Start a lesson
              </Button>
            </div>
          </Empty>
        ) : (
          <Empty emoji="🏆" title="Nothing left to get">
            <p>You got every one. Somewhere, a piggy bank is proud.</p>
          </Empty>
        )
      ) : (
        <motion.ul
          key={filter}
          className={styles.list}
          initial={reduce ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.18 }}
        >
          {list.map((b) => (
            <li key={b.id} className={styles.cell}>
              <BadgeTile badge={b} data={data} onOpen={setOpenBadge} />
            </li>
          ))}
        </motion.ul>
      )}

      <BadgeSheet badge={openBadge} data={data} onClose={() => setOpenBadge(null)} />
    </div>
  )
}
