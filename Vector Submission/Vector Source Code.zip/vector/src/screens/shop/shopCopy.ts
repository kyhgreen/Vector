/*
  Every playful line in the shop lives here, so the jokes are easy to tweak.
  House rules: short, dry, no slang, no em dashes.
*/
import type { ShopItem } from '../../state/constants'

/** Shop-card descriptions (shorter than the ones in constants). */
export const ITEM_DESC: Record<ShopItem['id'], string> = {
  'streak-freeze': 'Miss a day, keep your streak. Insurance, basically.',
  'heart-refill': 'All your hearts back, right now.',
  'double-xp': 'Twice the XP for 15 minutes.',
}

/** Shown in the confirm sheet. One is picked at random each time it opens. */
export const ITEM_LINES: Record<ShopItem['id'], string[]> = {
  'streak-freeze': [
    "A small cost now so one bad day doesn't wreck everything. That's insurance.",
    'Pay a little now, get covered later. Your streak says thanks.',
    'Grown-ups pay for insurance and hope they never use it. Same idea.',
  ],
  'heart-refill': [
    "Paying to skip the wait is a convenience fee. Sometimes it's worth it.",
    'Hearts come back free if you wait. This just buys speed.',
    'Need or want? Want. Patience is free, but so is wanting things.',
  ],
  'double-xp': [
    'Need or want? A want. A good one, though.',
    'Only worth it if you use all 15 minutes. Timing matters.',
    'Buying this and then going to make a sandwich is a classic mistake.',
  ],
}

export const AVATAR_LINES = [
  'Need or want? A want. Nobody needs a dragon, but a budget can have some fun in it.',
  "In a budget, this goes under Wants. That's allowed.",
  'Gut check: will you still love it next week?',
  "It won't make you faster. It will make you fabulous.",
]

/** Each power-up's accent color. */
export const ITEM_COLOR: Record<ShopItem['id'], 'blue' | 'red' | 'orange'> = {
  'streak-freeze': 'blue',
  'heart-refill': 'red',
  'double-xp': 'orange',
}

export const REASON_TITLE = {
  coins: 'Not enough coins.',
  maxed: "You're maxed out.",
  full: 'Hearts are already full.',
  owned: 'You already own that.',
} as const

/** Toast after a successful buy. `freezes` is how many you own after buying. */
export function boughtToast(id: ShopItem['id'], freezes: number, max: number): { title: string; body: string } {
  switch (id) {
    case 'streak-freeze':
      return { title: 'Streak Freeze ready', body: `${freezes} of ${max}. Your streak can take a sick day.` }
    case 'heart-refill':
      return { title: 'Hearts refilled', body: 'Good as new.' }
    case 'double-xp':
      return { title: 'Double XP is on', body: '15 minutes, starting now.' }
  }
}

export const VAULT_EMPTY_LINES = ['Echo... echo...', 'Just dust bunnies in here.', 'Zero coins. Plenty of room, though.']
