/* Every game number in one place, so balancing the game means editing one file. */

export const MAX_HEARTS = 5
/** One heart comes back every 30 minutes. */
export const HEART_REFILL_MS = 30 * 60 * 1000

export const XP = {
  lesson: 10,
  lessonPerfectBonus: 5,
  quizPass: 20,
  quizPerfectBonus: 10,
  quizFail: 5,
  practice: 8,
} as const

export const COINS = {
  lessonFirstTime: 6,
  lessonRepeat: 2,
  lessonPerfectBonus: 4,
  quizPass: 15,
  quizPerfectBonus: 10,
  practice: 3,
  dailyGoal: 10,
  badge: 20,
  startingBalance: 25,
} as const

export const DAILY_GOALS = [
  { xp: 10, label: 'Casual', blurb: '1 lesson a day. Nice and easy.' },
  { xp: 20, label: 'Regular', blurb: '2 lessons a day. A good habit.' },
  { xp: 30, label: 'Serious', blurb: '3 lessons a day. Someone means business.' },
  { xp: 50, label: 'Intense', blurb: '5 lessons a day. Bold. We respect it.' },
] as const

export interface ShopItem {
  id: 'streak-freeze' | 'heart-refill' | 'double-xp'
  name: string
  description: string
  price: number
  emoji: string
  /** Max you can own at once (for stackable items). */
  maxOwned?: number
}

export const SHOP_ITEMS: ShopItem[] = [
  {
    id: 'streak-freeze',
    name: 'Streak Freeze',
    description: 'Miss a day and your streak survives. Insurance, basically.',
    price: 40,
    emoji: '🧊',
    maxOwned: 2,
  },
  {
    id: 'heart-refill',
    name: 'Heart Refill',
    description: 'All your hearts back, right now.',
    price: 30,
    emoji: '❤️',
  },
  {
    id: 'double-xp',
    name: 'Double XP (15 min)',
    description: 'Twice the XP on everything for 15 minutes.',
    price: 50,
    emoji: '⚡',
  },
]

export const DOUBLE_XP_MS = 15 * 60 * 1000

export interface AvatarItem {
  emoji: string
  name: string
  price: number
}

/** Profile pictures. The free ones are available from the start. */
export const AVATARS: AvatarItem[] = [
  { emoji: '😎', name: 'Cool Cat', price: 0 },
  { emoji: '🙂', name: 'Sunny Side Up', price: 0 },
  { emoji: '🤓', name: 'Know-It-All', price: 0 },
  { emoji: '🦊', name: 'Fox', price: 30 },
  { emoji: '🐸', name: 'Frugal Frog', price: 30 },
  { emoji: '🐼', name: 'Panda', price: 40 },
  { emoji: '🐙', name: 'Octopus', price: 50 },
  { emoji: '🦄', name: 'Unicorn (the startup kind)', price: 75 },
  { emoji: '🤖', name: 'Robo-Advisor', price: 75 },
  { emoji: '👽', name: 'Alien Investor', price: 100 },
  { emoji: '🐉', name: 'Dragon Hoarder', price: 150 },
  { emoji: '👑', name: 'Royalty', price: 250 },
]

/**
  Coin Vault: stash coins and watch them earn interest. It teaches compound
  interest with something the player actually cares about. The rate is
  wildly generous on purpose (real banks pay a few percent per YEAR), and
  the app says so.
*/
export const VAULT = {
  dailyRatePct: 2,
  /** Only this much of the balance earns interest, so the economy doesn't explode. */
  interestCap: 1000,
} as const
