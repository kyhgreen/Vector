import type { ToolMeta } from '../registry'

export const meta: ToolMeta = {
  id: 'budget',
  title: 'Budget Builder',
  tagline: 'Tell your money where to go, for once.',
  emoji: '📊',
  color: 'green',
  order: 1,
}
