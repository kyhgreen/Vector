import type { ToolMeta } from '../registry'

export const meta: ToolMeta = {
  id: 'debt',
  title: 'Debt Payoff Lab',
  tagline: 'Find the fastest, cheapest way out of debt.',
  emoji: '🔍',
  color: 'red',
  order: 6,
}
