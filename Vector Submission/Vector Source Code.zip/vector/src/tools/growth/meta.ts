import type { ToolMeta } from '../registry'

export const meta: ToolMeta = {
  id: 'growth',
  title: 'Growth Calculator',
  tagline: 'Watch interest grow your money while you do nothing.',
  emoji: '🌱',
  color: 'teal',
  order: 3,
}
