import type { ToolMeta } from '../registry'

export const meta: ToolMeta = {
  id: 'habit',
  title: 'Habit Cost Calculator',
  tagline: 'What your favorite treat really costs. No judgment.',
  emoji: '🧋',
  color: 'pink',
  order: 8,
}
