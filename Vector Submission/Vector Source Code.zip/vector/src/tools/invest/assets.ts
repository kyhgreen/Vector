/*
  The pretend market: eight made-up investments in the made-up country of
  Fakeland, plus the news that pushes their prices around.

  drift = long-run average growth per year (0.08 = 8%)
  vol   = how wildly the price swings in a year (0.16 = a typical year lands
          within about 16% of the average)
  corr  = how much it moves together with the whole market (0 = does its own thing)
  beta  = how hard market-wide news and slides hit it
*/
import type { UnitColor } from '../../content/types'

export type Ticker = 'SAVE' | 'BNDY' | 'KNIT' | 'TMIX' | 'SNAK' | 'MEOW' | 'HOVR' | 'DMOON'

/** 0 = never goes down ... 5 = hold onto your hat. */
export type Risk = 0 | 1 | 2 | 3 | 4 | 5

export interface Asset {
  ticker: Ticker
  name: string
  /** Short name for tight spots and sentences ("If Snack Attack has a bad week..."). */
  short: string
  emoji: string
  color: UnitColor
  kind: string
  risk: Risk
  drift: number
  vol: number
  corr: number
  beta: number
  /** Price on day 1. */
  start: number
  /** Chance per day of company news. */
  newsOdds: number
  /** The one-liner on the market list. */
  blurb: string
  /** A little more teaching, shown in the detail sheet. */
  detail: string
  /** Plain-words growth and swing descriptions for the detail sheet. */
  growthText: string
  swingText: string
}

export const ASSETS: readonly Asset[] = [
  {
    ticker: 'SAVE',
    name: 'Savings Account',
    short: 'Savings',
    emoji: '🏦',
    color: 'green',
    kind: 'Savings',
    risk: 0,
    drift: 0.04,
    vol: 0,
    corr: 0,
    beta: 0,
    start: 10,
    newsOdds: 0,
    blurb: 'Grows 4% a year and never goes down.',
    detail: 'It never drops, but safe money grows slowly.',
    growthText: '4% a year',
    swingText: 'None',
  },
  {
    ticker: 'BNDY',
    name: 'Bondy Bond Fund',
    short: 'Bondy',
    emoji: '📜',
    color: 'teal',
    kind: 'Bond fund',
    risk: 1,
    drift: 0.04,
    vol: 0.05,
    corr: -0.15,
    beta: -0.25,
    start: 50,
    newsOdds: 1 / 150,
    blurb: 'Lends money out and earns interest. Calm and steady.',
    detail: 'A bond is a loan that pays interest. Bonds swing less than stocks and often hold up when stocks fall.',
    growthText: 'About 4% a year',
    swingText: 'Small',
  },
  {
    ticker: 'KNIT',
    name: "Grandma's Sweaters",
    short: "Grandma's Sweaters",
    emoji: '🧶',
    color: 'red',
    kind: 'Stock',
    risk: 1,
    drift: 0.035,
    vol: 0.09,
    corr: 0.35,
    beta: 0.5,
    start: 18,
    newsOdds: 1 / 110,
    blurb: 'An old, steady company. Sells the most in winter.',
    detail: 'A stock is a tiny slice of a company. Old, steady companies grow slowly and swing less.',
    growthText: 'About 3.5% a year',
    swingText: 'Mild',
  },
  {
    ticker: 'TMIX',
    name: 'Total Market Index',
    short: 'the Total Market Index',
    emoji: '🌎',
    color: 'blue',
    kind: 'Index fund',
    risk: 2,
    drift: 0.08,
    vol: 0.16,
    corr: 0.97,
    beta: 1,
    start: 100,
    newsOdds: 0,
    blurb: 'A slice of every company in Fakeland.',
    detail: 'Owns hundreds of companies, so one bad one can\'t sink it. It still moves with the market.',
    growthText: 'About 8% a year, with some bad years',
    swingText: 'Medium',
  },
  {
    ticker: 'SNAK',
    name: 'Snack Attack Inc.',
    short: 'Snack Attack',
    emoji: '🍿',
    color: 'orange',
    kind: 'Stock',
    risk: 3,
    drift: 0.1,
    vol: 0.26,
    corr: 0.6,
    beta: 1.1,
    start: 42,
    newsOdds: 1 / 70,
    blurb: 'One company that makes very spicy chips.',
    detail: 'One company, one product. When it has a bad week, nothing softens the hit.',
    growthText: 'About 10% a year',
    swingText: 'Big, on big news',
  },
  {
    ticker: 'MEOW',
    name: 'CloudKitty Games',
    short: 'CloudKitty',
    emoji: '🐱',
    color: 'purple',
    kind: 'Stock',
    risk: 4,
    drift: 0.12,
    vol: 0.38,
    corr: 0.5,
    beta: 1.3,
    start: 63,
    newsOdds: 1 / 60,
    blurb: 'Makes video games about cats. One flop can sink it.',
    detail: 'Game companies depend on their next hit, so the price can drop fast.',
    growthText: 'About 12% a year',
    swingText: 'Large',
  },
  {
    ticker: 'HOVR',
    name: 'Hoverboard Co.',
    short: 'Hoverboard Co.',
    emoji: '🛹',
    color: 'pink',
    kind: 'Stock',
    risk: 4,
    drift: 0.13,
    vol: 0.48,
    corr: 0.45,
    beta: 1.5,
    start: 87,
    newsOdds: 1 / 55,
    blurb: 'Promises flying skateboards soon. It has said that for six years.',
    detail: 'You\'re betting on future sales, not today\'s. If the future doesn\'t show up, the price falls hard.',
    growthText: 'About 13% a year, if the hype holds',
    swingText: 'Very large',
  },
  {
    ticker: 'DMOON',
    name: 'DogeMoon Coin',
    short: 'DogeMoon',
    emoji: '🐶',
    color: 'yellow',
    kind: 'Meme coin',
    risk: 5,
    drift: -0.2,
    vol: 1.1,
    corr: 0.2,
    beta: 1.5,
    start: 0.42,
    newsOdds: 1 / 26,
    blurb: 'No company or product behind it, just a cartoon dog.',
    detail: 'Nothing backs a meme coin, so the price follows the hype. Most sink over time.',
    growthText: 'Usually down',
    swingText: 'Can double or halve in a week',
  },
]

export const TICKERS: readonly Ticker[] = ASSETS.map((a) => a.ticker)
export const ASSET_BY_TICKER = Object.fromEntries(ASSETS.map((a) => [a.ticker, a])) as Record<Ticker, Asset>
export const assetIndex = (t: Ticker) => TICKERS.indexOf(t)
export const isTicker = (t: unknown): t is Ticker => typeof t === 'string' && (TICKERS as readonly string[]).includes(t)

export const RISK_LABELS: Record<Risk, string> = {
  0: 'No swings',
  1: 'Low risk',
  2: 'Medium risk',
  3: 'Medium-high risk',
  4: 'High risk',
  5: 'Very high risk',
}

export const RISK_COLORS: Record<Risk, UnitColor | 'gray'> = {
  0: 'green',
  1: 'teal',
  2: 'blue',
  3: 'orange',
  4: 'red',
  5: 'purple',
}

/* ---------- News ---------- */

export interface NewsTemplate {
  emoji: string
  text: string
  /** Price jump it causes (0.12 = up 12%). The real jump wobbles around this. */
  move: number
}

export const COMPANY_NEWS: Partial<Record<Ticker, NewsTemplate[]>> = {
  SNAK: [
    { emoji: '🌶️', text: 'Snack Attack recalls its ghost-pepper chips.', move: -0.15 },
    { emoji: '🥒', text: "SNAK's pickle-flavored bubble gum becomes a surprise hit.", move: 0.12 },
    { emoji: '📦', text: 'Snack Attack wins a deal to stock every school vending machine.', move: 0.1 },
    { emoji: '😬', text: "A food critic trashes SNAK's new chips.", move: -0.08 },
    { emoji: '💨', text: 'SNAK ships 2 million bags that are mostly air. Customers complain.', move: -0.11 },
    { emoji: '🏆', text: 'Snack Attack wins Snack of the Year again.', move: 0.07 },
    { emoji: '🚚', text: 'Delivery delays leave SNAK shelves empty all week.', move: -0.06 },
  ],
  MEOW: [
    { emoji: '🎮', text: "CloudKitty's new game becomes the #1 game in Fakeland.", move: 0.18 },
    { emoji: '⏳', text: 'MEOW delays its big game again.', move: -0.16 },
    { emoji: '🐾', text: 'A small MEOW side project turns into a hit game.', move: 0.12 },
    { emoji: '💥', text: "MEOW's servers crash on launch day.", move: -0.12 },
    { emoji: '📺', text: 'CloudKitty announces a cartoon series.', move: 0.09 },
    { emoji: '🥔', text: "A bug in MEOW's top game annoys players.", move: -0.07 },
  ],
  HOVR: [
    { emoji: '🚀', text: 'Hoverboard Co. finally hovers higher than 3 inches.', move: 0.25 },
    { emoji: '🔙', text: 'HOVR recalls 40,000 boards that only hover backwards.', move: -0.22 },
    { emoji: '📣', text: "HOVR's boss promises flying skateboards by next Tuesday.", move: 0.08 },
    { emoji: '🚫', text: 'Schools ban hoverboards in the hallways.', move: -0.13 },
    { emoji: '🔋', text: 'HOVR shows off a battery it says lasts a whole week.', move: 0.15 },
    { emoji: '🌧️', text: 'Hoverboards turn out to break in the rain, and HOVR sales drop.', move: -0.1 },
  ],
  KNIT: [
    { emoji: '❄️', text: "A surprise cold snap sends Grandma's Sweaters sales up.", move: 0.08 },
    { emoji: '🦔', text: "Grandma's Sweaters launches an extra-itchy line. Customers hate it.", move: -0.06 },
    { emoji: '🎄', text: "KNIT's ugly holiday sweater sells out in 4 minutes.", move: 0.06 },
    { emoji: '☀️', text: 'A record-warm winter means nobody is buying sweaters.', move: -0.07 },
    { emoji: '🦙', text: 'Grandma goes viral for knitting a sweater for a llama.', move: 0.05 },
  ],
  BNDY: [
    { emoji: '📈', text: 'Interest rates rise, so bond prices dip. The two move in opposite directions.', move: -0.03 },
    { emoji: '📉', text: 'Interest rates drop, so older bonds look better and bond prices rise.', move: 0.03 },
    { emoji: '🏛️', text: "Fakeland's government pays every bill on time, so bonds look safer.", move: 0.015 },
  ],
  DMOON: [
    { emoji: '🌕', text: 'A famous dog posts a moon emoji, and DMOON jumps.', move: 0.45 },
    { emoji: '🕳️', text: 'The DogeMoon creators disappear, and the price crashes.', move: -0.45 },
    { emoji: '🍕', text: 'A pizza place refuses to take DMOON as payment.', move: -0.18 },
    { emoji: '📢', text: 'A celebrity mentions DMOON for no clear reason, and the price jumps.', move: 0.35 },
    { emoji: '🖨️', text: 'A glitch lets anyone make free DMOON, so each coin is worth less.', move: -0.32 },
    { emoji: '🗣️', text: 'Fans hype DMOON online, and the price jumps for no real reason.', move: 0.25 },
    { emoji: '😴', text: 'Everyone loses interest in DogeMoon at the same time.', move: -0.25 },
  ],
}

/** News that hits the whole market. Stocks feel it by their beta; bonds often wiggle the other way. */
export const MARKET_NEWS: NewsTemplate[] = [
  { emoji: '🌧️', text: "Fakeland's economy hits a rough patch. Almost everything drops.", move: -0.06 },
  { emoji: '📰', text: 'Gloomy headlines make investors nervous, so they sell.', move: -0.045 },
  { emoji: '💼', text: 'A strong jobs report lifts the market.', move: 0.045 },
  { emoji: '🎉', text: "Fakeland's economy is booming, and stocks rise.", move: 0.05 },
  { emoji: '🤷', text: 'Everything is down today and nobody can agree why.', move: -0.03 },
  { emoji: '🏭', text: 'Factories in Fakeland are busier than ever. Stocks climb.', move: 0.04 },
]

export const SLIDE_START: Omit<NewsTemplate, 'move'> = {
  emoji: '🐻',
  text: "Fakeland's market starts a long slide, called a correction.",
}

export const SLIDE_END: Omit<NewsTemplate, 'move'> = {
  emoji: '🌤️',
  text: 'The slide looks over, and prices are steadying.',
}
