import type { ToolMeta } from '../registry'

export const meta: ToolMeta = {
  id: 'invest',
  title: 'Practice Investing',
  tagline: 'Practice investing with pretend money, so mistakes cost nothing.',
  emoji: '📈',
  color: 'blue',
  order: 4,
}
