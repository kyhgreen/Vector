import type { ToolMeta } from '../registry'

export const meta: ToolMeta = {
  id: 'paycheck',
  title: 'Paycheck Calculator',
  tagline: 'See what you keep after taxes. Usually most of it.',
  emoji: '💵',
  color: 'green',
  order: 7,
}
