import type { ToolMeta } from '../registry'

export const meta: ToolMeta = {
  id: 'savings',
  title: 'Savings Goals',
  tagline: 'See when you can actually afford that thing you want.',
  emoji: '🎯',
  color: 'orange',
  order: 2,
}
